#!/usr/bin/env python3
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""MolmoAct2 closed loop on a real Franka using USB cameras + motion_server.cpp.

Requires:
  - ``motion_server`` running (libfranka HTTP API on :34568)
  - MolmoAct2 inference server (see start_molmoact2_3090.md)
  - USB cameras configured in ``usb_cameras.json`` or env vars (see README)

Example:
  python3 hardware_molmoact2_runner.py \\
    --motion-url http://127.0.0.1:34568 \\
    --molmoact2-url http://localhost:8101 \\
    --instruction "Pick up the apple and place it on the plate"
"""

from __future__ import annotations

import argparse
import signal
import sys
import time
from pathlib import Path

_PROJECT_DIR = Path(__file__).resolve().parent
if str(_PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(_PROJECT_DIR))

from motion_server_http_robot import MotionServerHttpRobot
from motion_server_molmoact2 import MolmoAct2Controller
from motion_server_action_offset import (
    DEFAULT_EE_FLOOR_Z_M,
    DEFAULT_OFFSET_REFERENCE,
    VALID_OFFSET_REFERENCES,
)
from motion_server_usb_cameras import UsbCameraStreamManager, load_usb_camera_config


def main() -> int:
    parser = argparse.ArgumentParser(description="MolmoAct2 hardware runner (USB cameras + motion_server)")
    parser.add_argument("--motion-url", default="http://127.0.0.1:34568", help="motion_server.cpp base URL")
    parser.add_argument("--molmoact2-url", default="http://localhost:8101", help="MolmoAct2 inference URL")
    parser.add_argument("--instruction", required=True, help="Natural-language task string")
    parser.add_argument(
        "--external-camera-mode",
        default="duplicate",
        choices=["single", "dual", "duplicate"],
        help="MolmoAct2 exterior layout (default: duplicate — PnP-safer on hardware)",
    )
    parser.add_argument(
        "--external-slot",
        default="external_1",
        choices=["external_1", "external_2"],
        help="Primary exterior camera when mode=single (default: external_1)",
    )
    parser.add_argument("--usb-config", default=None, help="Path to usb_cameras.json (overrides default)")
    parser.add_argument("--hz", type=float, default=60.0, help="Main loop rate (default: 60)")
    parser.add_argument(
        "--execution-mode",
        default="auto",
        choices=["async", "sync", "auto"],
        help=(
            "async: open-loop chunk — observe, infer, execute full chunk with settle between steps, "
            "then re-observe; "
            "sync: horizon-1 step-by-step — observe, apply only the first action, wait "
            "for arm + gripper to settle, then observe again; auto: open-loop async while the "
            "gripper tip is high, switch to sync at/below --sync-below-z (default: auto — "
            "PnP-safer on hardware)"
        ),
    )
    parser.add_argument(
        "--sync-below-z",
        type=float,
        default=0.18,
        help="auto mode: gripper-tip base-frame Z (m) at/below which to run step-by-step (default: 0.18)",
    )
    parser.add_argument(
        "--chunk-horizon",
        type=int,
        default=4,
        help="Action chunk horizon (steps per inference response, default: 4 — PnP-safer on hardware)",
    )
    parser.add_argument("--offset-x", type=float, default=0.0, help="Base-frame fingertip X offset (m)")
    parser.add_argument("--offset-y", type=float, default=0.0, help="Base-frame fingertip Y offset (m)")
    parser.add_argument("--offset-z", type=float, default=0.0, help="Base-frame fingertip Z offset (m)")
    parser.add_argument(
        "--offset-mode",
        default="continuous",
        choices=["continuous", "final"],
        help=(
            "continuous: shift every action step; "
            "final: apply offset once to the final pose on stop (gripper orientation held)"
        ),
    )
    parser.add_argument(
        "--offset-reference",
        default=DEFAULT_OFFSET_REFERENCE,
        choices=list(VALID_OFFSET_REFERENCES),
        help=(
            "tip_flange: XYZ in flange frame applied to fingertip (legacy); "
            "flange_base: XYZ in base frame applied to flange position"
        ),
    )
    parser.add_argument(
        "--grasp-integration",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Replace the policy's open->close action with the poke-and-grab macro near a grasp "
            "(default: off — validate pure policy behavior first)"
        ),
    )
    parser.add_argument(
        "--ee-floor-z",
        type=float,
        default=None,
        help=(
            "Enable the EE floor guard at this measured table-surface Z (m, base frame). "
            "Required to use the floor guard; leave unset to keep it disabled until calibrated."
        ),
    )
    parser.add_argument(
        "--no-ee-floor",
        action="store_true",
        help="Force-disable the EE floor clip entirely (overrides --ee-floor-z).",
    )
    args = parser.parse_args()

    usb_config = load_usb_camera_config(args.usb_config)
    cameras = UsbCameraStreamManager(usb_config)
    robot = MotionServerHttpRobot(args.motion_url)
    molmo = MolmoAct2Controller(robot, cameras)

    stop = False

    def _handle_sigint(_signum, _frame) -> None:
        nonlocal stop
        stop = True

    signal.signal(signal.SIGINT, _handle_sigint)
    signal.signal(signal.SIGTERM, _handle_sigint)

    print("Opening USB cameras...")
    cameras.initialize()
    # EE floor guard: disabled unless --ee-floor-z is given; --no-ee-floor forces it off.
    if args.no_ee_floor:
        ee_floor_enabled: bool | None = False
        ee_floor_z: float | None = None
    elif args.ee_floor_z is not None:
        ee_floor_enabled = True
        ee_floor_z = args.ee_floor_z
    else:
        ee_floor_enabled = None  # leave controller default (disabled until calibrated)
        ee_floor_z = None
    status = molmo.configure(
        server_url=args.molmoact2_url,
        instruction=args.instruction,
        external_slot=args.external_slot,
        external_camera_mode=args.external_camera_mode,
        execution_mode=args.execution_mode,
        sync_below_z=args.sync_below_z,
        chunk_horizon=args.chunk_horizon,
        offset_x=args.offset_x,
        offset_y=args.offset_y,
        offset_z=args.offset_z,
        offset_mode=args.offset_mode,
        offset_reference=args.offset_reference,
        grasp_integration_enabled=args.grasp_integration,
        ee_floor_enabled=ee_floor_enabled,
        ee_floor_z=ee_floor_z,
    )
    if status.ee_floor_enabled and abs(status.ee_floor_z - DEFAULT_EE_FLOOR_Z_M) < 1e-9:
        print(
            "Warning: EE floor guard is ENABLED but ee_floor_z is still the default "
            f"{DEFAULT_EE_FLOOR_Z_M:.3f} m (a guess). Set --ee-floor-z to the measured "
            "table-surface Z in the robot base frame, or pass --no-ee-floor. An uncalibrated "
            "floor can hover the arm above the object and block picks."
        )
    health = molmo.refresh_health(async_ok=False)
    if not health.get("ok"):
        print(f"Warning: MolmoAct2 health check failed: {health}")
    else:
        print("MolmoAct2 inference server: ok")

    print("Starting MolmoAct2 control loop (Ctrl+C to stop)...")
    molmo.start()

    dt = 1.0 / max(args.hz, 1.0)
    try:
        while not stop:
            t0 = time.monotonic()
            molmo.tick(dt)
            elapsed = time.monotonic() - t0
            time.sleep(max(0.0, dt - elapsed))
    finally:
        molmo.stop()
        cameras.shutdown()
        print("Stopped.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
