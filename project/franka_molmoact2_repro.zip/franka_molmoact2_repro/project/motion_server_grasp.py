# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Shared poke-and-grab grasp macro built on libfranka-grounded handler primitives.

A single source of truth for the grasp sequence used by both the manual UI grasp button
(``motion_server_api``) and the MolmoAct2 policy loop (``motion_server_molmoact2``). The
DROID-trained policy assumes a Robotiq 2F-85; on a stock Franka Hand the binarized close
command alone under-grasps, so when the policy decides to close we instead advance the
fingertip a small distance along the real gripper-pointing axis, force-grasp, and snap
back to the pose the policy would have closed at.

All kinematics come from the robot's real reported EE pose (``readState`` -> libfranka
``O_T_EE``) and ``moveToCartesian`` (libfranka IK, orientation held) so the advance follows
the true gripper-pointing axis rather than any Python kinematic model.
"""

from __future__ import annotations

import math
from typing import Any

from motion_server_timing_log import log_event

DEFAULT_GRASP_ADVANCE_M = 0.05
DEFAULT_GRASP_FORWARD_TIME_S = 1.5
DEFAULT_GRASP_RETRACT_TIME_S = 3.0


def tool_axis_from_euler(alpha_deg: float, beta_deg: float, gamma_deg: float) -> list[float]:
    """Tool pointing axis (+EE Z) in base frame from motion_server.cpp ZYX Euler angles.

    ``readState`` returns the libfranka ``O_T_EE`` orientation as (alpha=Z, beta=Y, gamma=X)
    with R = Rz(alpha)·Ry(beta)·Rx(gamma); this returns the third column of R.
    """
    a = math.radians(float(alpha_deg))
    b = math.radians(float(beta_deg))
    g = math.radians(float(gamma_deg))
    ca, sa = math.cos(a), math.sin(a)
    cb, sb = math.cos(b), math.sin(b)
    cg, sg = math.cos(g), math.sin(g)
    return [
        ca * sb * cg + sa * sg,
        sa * sb * cg - ca * sg,
        cb * cg,
    ]


def run_grasp_sequence(
    handler: Any,
    *,
    distance_m: float = DEFAULT_GRASP_ADVANCE_M,
    forward_time_s: float = DEFAULT_GRASP_FORWARD_TIME_S,
    retract_time_s: float = DEFAULT_GRASP_RETRACT_TIME_S,
    approach_q7: list[float] | None = None,
    approach_time_s: float | None = None,
    log_channel: str = "motion_api",
) -> dict[str, Any]:
    """Open, optionally drive the arm to ``approach_q7``, advance the fingertip along the
    gripper's pointing axis by ``distance_m``, force-grasp, then retract to the anchor pose.

    When ``approach_q7`` is given the arm is first moved (gripper open) to that joint pose; the
    anchor (snap-back) pose is then read there so the macro ends exactly where the policy's
    close action would have placed the arm. Blocks for roughly
    ``approach + forward_time + grasp + retract_time`` seconds.
    """
    distance = float(distance_m)
    forward_time = float(forward_time_s)
    retract_time = float(retract_time_s)
    if distance <= 0.0:
        raise ValueError("grasp sequence: advance distance must be > 0.")

    # 1. Open the fingers fully before approaching/grasping.
    log_event(log_channel, "grasp sequence step: open_gripper")
    open_msg = handler.open_gripper([])
    log_event(log_channel, f"grasp sequence open result: {open_msg}")

    # 2. Optionally drive the arm to the grasp anchor pose (gripper open).
    if approach_q7 is not None:
        q7 = [float(x) for x in list(approach_q7)[:7]]
        if len(q7) < 7:
            raise ValueError("grasp sequence: approach_q7 needs 7 joint angles.")
        move_time = float(approach_time_s) if approach_time_s is not None else forward_time
        handler.move_to_joint_pose(q7 + [move_time])

    # Anchor = the robot's real reported EE pose we want to snap back to.
    state = handler.read_state()
    if not isinstance(state, list) or len(state) < 6:
        raise RuntimeError("grasp sequence: could not read current EE pose.")
    x0, y0, z0 = float(state[0]), float(state[1]), float(state[2])
    ez = tool_axis_from_euler(state[3], state[4], state[5])
    target = [x0 + distance * ez[0], y0 + distance * ez[1], z0 + distance * ez[2]]

    # 3. Advance the fingertip along the true tool axis (orientation held).
    log_event(log_channel, "grasp sequence step: move_to_cartesian forward")
    handler.move_to_cartesian([target[0], target[1], target[2], forward_time])
    # 4. Force-grasp at the advanced pose.
    log_event(log_channel, "grasp sequence step: close_gripper")
    grasp_msg = handler.close_gripper([])
    log_event(log_channel, f"grasp sequence close result: {grasp_msg}")
    # 5. Slowly retract to the anchor pose with the object held.
    log_event(log_channel, "grasp sequence step: move_to_cartesian retract")
    handler.move_to_cartesian([x0, y0, z0, retract_time])

    log_event(
        log_channel,
        "grasp sequence done (advance=%.3f m along tool axis %.3f,%.3f,%.3f)"
        % (distance, ez[0], ez[1], ez[2]),
    )
    return {
        "distance_m": distance,
        "forward_time_s": forward_time,
        "retract_time_s": retract_time,
        "tool_axis": ez,
        "anchor": [x0, y0, z0],
        "open": open_msg,
        "grasp": grasp_msg,
    }
