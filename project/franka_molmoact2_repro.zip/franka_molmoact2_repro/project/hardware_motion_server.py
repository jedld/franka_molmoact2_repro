#!/usr/bin/env python3
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Hardware Franka motion server with web UI, USB cameras, and MolmoAct2 control.

Proxies robot commands to ``motion_server.cpp`` (libfranka) and serves the browser UI
on port 34568 by default. Run ``launch_hardware_stack.sh`` to start both processes.
"""

from __future__ import annotations

import argparse
import signal
import sys
import threading
import time
from pathlib import Path

_PROJECT_DIR = Path(__file__).resolve().parent
if str(_PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(_PROJECT_DIR))

from motion_server_api import MotionRestServer
from motion_server_camera_common import POLICY_CAPTURE_HZ
from motion_server_cpp_proxy import CppMotionServerHandler
from motion_server_molmoact2 import MolmoAct2Controller, TASK_INSTRUCTIONS
from motion_server_usb_cameras import UsbCameraStreamManager, load_usb_camera_config
from motion_server_timing_log import log_event


def main() -> int:
    parser = argparse.ArgumentParser(description="Hardware Franka HTTP motion server + web UI")
    parser.add_argument("--host", default="0.0.0.0", help="HTTP bind address (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=34568, help="Web UI / API port (default: 34568)")
    parser.add_argument(
        "--motion-backend",
        default="http://127.0.0.1:34569",
        help="motion_server.cpp base URL (default: http://127.0.0.1:34569)",
    )
    parser.add_argument(
        "--molmoact2-url",
        default="http://localhost:8101",
        help="MolmoAct2 inference server base URL (default: http://localhost:8101)",
    )
    parser.add_argument(
        "--task",
        default="apple_on_plate",
        choices=list(TASK_INSTRUCTIONS),
        help="Default MolmoAct2 Table 6 instruction preset",
    )
    parser.add_argument("--usb-config", default=None, help="Path to usb_cameras.json")
    parser.add_argument("--no-cameras", action="store_true", help="Disable USB camera capture")
    parser.add_argument("--no-ui", action="store_true", help="Disable web UI (motion API only)")
    parser.add_argument("--hz", type=float, default=60.0, help="Main loop rate (default: 60)")
    args = parser.parse_args()

    handler = CppMotionServerHandler(args.motion_backend)
    camera_manager: UsbCameraStreamManager | None = None
    molmoact2: MolmoAct2Controller | None = None

    if not args.no_cameras:
        usb_config = load_usb_camera_config(args.usb_config)
        camera_manager = UsbCameraStreamManager(usb_config)

    api = MotionRestServer(
        handler,
        host=args.host,
        port=args.port,
        camera_manager=camera_manager,
        enable_ui=not args.no_ui,
        molmoact2=molmoact2,
    )
    api.start()

    camera_init_error: list[str] = []

    def _init_cameras_and_molmo() -> None:
        nonlocal molmoact2
        if args.no_cameras or camera_manager is None:
            return
        print("Opening USB cameras...")
        try:
            camera_manager.initialize()
            print(
                f"USB cameras: {', '.join(s.camera_id for s in camera_manager.specs)} "
                f"(policy @ {POLICY_CAPTURE_HZ} Hz)"
            )
            molmoact2 = MolmoAct2Controller(handler, camera_manager)
            molmoact2.configure(
                server_url=args.molmoact2_url,
                instruction=TASK_INSTRUCTIONS[args.task],
                external_camera_mode="dual",
            )
            api.attach_molmoact2(molmoact2)
            print(f"MolmoAct2 inference: {args.molmoact2_url}")
        except Exception as exc:
            import traceback

            msg = f"USB camera / MolmoAct2 setup failed (web UI still available): {exc}"
            camera_init_error.append(msg)
            print(msg)
            traceback.print_exc()

    if not args.no_cameras and camera_manager is not None:
        threading.Thread(
            target=_init_cameras_and_molmo,
            name="usb-camera-init",
            daemon=True,
        ).start()

    stop = False

    def _handle_stop(_signum, _frame) -> None:
        nonlocal stop
        stop = True

    signal.signal(signal.SIGINT, _handle_stop)
    signal.signal(signal.SIGTERM, _handle_stop)

    print("Press Ctrl+C to stop the web UI.")
    if not args.no_ui:
        print(f"Web UI: http://127.0.0.1:{args.port}/")
        print(f"  MolmoAct2 panel: http://127.0.0.1:{args.port}/#molmoact2-panel")
        if molmoact2 is None and not args.no_cameras:
            print("  (MolmoAct2 panel inactive until USB cameras finish initializing.)")

    dt = 1.0 / args.hz if args.hz > 0 else 0.0
    molmo_stop = threading.Event()

    def _molmo_tick_loop() -> None:
        while not molmo_stop.is_set():
            controller = molmoact2
            if controller is not None:
                try:
                    controller.tick(dt)
                except Exception as exc:
                    print(f"MolmoAct2 tick error (continuing): {exc}")
            if dt > 0:
                molmo_stop.wait(dt)

    pending_dt = 1.0 / 120.0
    molmo_thread = threading.Thread(target=_molmo_tick_loop, name="molmoact2-tick", daemon=True)
    molmo_thread.start()
    log_event(
        "hw_motion",
        f"main loop: process_pending @ {1.0 / pending_dt:.0f}Hz | "
        f"MolmoAct2 tick on molmoact2-tick thread @ {args.hz:.0f}Hz | "
        f"backend={args.motion_backend}",
    )

    try:
        while not stop:
            api.process_pending()
            if pending_dt > 0:
                time.sleep(pending_dt)
    finally:
        molmo_stop.set()
        molmo_thread.join(timeout=1.0)
        api.stop()
        if isinstance(camera_manager, UsbCameraStreamManager):
            camera_manager.shutdown()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
