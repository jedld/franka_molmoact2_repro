# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Binary gripper gating for MolmoAct2 policy steps.

Policy gripper commands are binarized (>0.5 DROID = closed, otherwise open). Two apply paths
are provided:

  - :func:`apply_policy_joint_targets_coordinated` (preferred on hardware): always streams the
    arm and publishes a binary gripper command only when the binarized target changes. The arm
    is never blocked, so coordinated arm+gripper timing near a grasp is preserved.
  - :func:`apply_policy_joint_targets_binary` (legacy / sim): applies the arm target only once
    the gripper has reached open, fully closed, or grasping.

Gripper commands are published without blocking the main control loop (no sleep/poll loops here).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

import numpy as np

from motion_server_droid_units import (
    FRANKA_GRIPPER_MAX_WIDTH_M,
    GRIPPER_CLOSE_THRESHOLD,
    droid_gripper_binary_value,
    q9_width_m,
)
from motion_server_timing_log import log_event

GRIPPER_OPEN_TOL_M = 0.004
# Franka Hand often reports/open-settles around ~0.06-0.07 m in streaming operation; requiring
# near-max aperture (>= 0.076 m) made async settle wait hit the 5 s timeout repeatedly even when
# arm tracking error was already ~0. Relax open settle to a practical "open enough" band.
GRIPPER_OPEN_SETTLED_MIN_RATIO = 0.75
# Policy ticks (~15 Hz) to wait for a close command before assuming an object is grasped.
GRIPPER_GRASP_ASSUME_TICKS = 45


def droid_gripper_is_closed_command(droid_g: float) -> bool:
    return float(droid_g) > GRIPPER_CLOSE_THRESHOLD


def desired_closed_from_q9(
    q9: np.ndarray, *, max_width_m: float = FRANKA_GRIPPER_MAX_WIDTH_M
) -> bool:
    """Infer the binarized close/open *command* from a 9-DOF target vector.

    This is the ONLY classifier that decides what open/close command the hardware actually
    receives (via :func:`apply_policy_joint_targets_coordinated`), so it MUST agree with the
    intent/grasp/state classifiers (``droid_gripper_is_closed_command`` /
    ``droid_gripper_binary_value`` / grasp-edge detection), which all use
    ``GRIPPER_CLOSE_THRESHOLD``. It previously hard-coded a droid>=0.5 (width<=max/2) boundary
    that disagreed with the configured threshold: a policy gripper value in the dead band
    ``(GRIPPER_CLOSE_THRESHOLD, 0.5]`` (e.g. 0.277) was logged/treated as "close" everywhere but
    published to the robot as "open", releasing a freshly grasped object. Use the shared
    threshold so every path agrees and lowering ``GRIPPER_CLOSE_THRESHOLD`` actually biases the
    real command toward holding.
    """
    if max_width_m <= 0.0:
        return True
    width_m = q9_width_m(q9, max_width_m=max_width_m)
    closed_ratio = 1.0 - float(np.clip(width_m / max_width_m, 0.0, 1.0))
    return closed_ratio > GRIPPER_CLOSE_THRESHOLD


def physical_gripper_is_closed(
    width_m: float, *, max_width_m: float = FRANKA_GRIPPER_MAX_WIDTH_M
) -> bool:
    """Infer whether the physical gripper is in the closed/grasping regime."""
    return width_m < max_width_m * 0.5


def physical_gripper_is_settled(
    width_m: float,
    desired_closed: bool,
    *,
    max_width_m: float = FRANKA_GRIPPER_MAX_WIDTH_M,
) -> bool:
    """True when the jaw width matches the binarized open/closed target (grasping counts as closed)."""
    if desired_closed:
        return width_m < max_width_m - GRIPPER_OPEN_TOL_M
    return width_m >= max_width_m * GRIPPER_OPEN_SETTLED_MIN_RATIO


class PolicyGripperHandler(Protocol):
    def get_joint_positions_q9(self) -> np.ndarray: ...

    def set_joint_pose(self, numbers: list[float]) -> list[float]: ...

    def read_gripper_state(self) -> list[float]: ...


@dataclass
class PolicyGripperTracker:
    last_commanded_closed: bool | None = field(default=None)
    unsettled_ticks: int = 0


def _read_gripper_width_m(handler: Any) -> float:
    read = getattr(handler, "read_gripper_state", None)
    if callable(read):
        state = read()
        if state:
            return float(state[0])
    return q9_width_m(handler.get_joint_positions_q9())


def _binary_gripper_width_m(
    desired_closed: bool, *, max_width_m: float = FRANKA_GRIPPER_MAX_WIDTH_M
) -> float:
    return 0.0 if desired_closed else max_width_m


def _publish_binary_gripper(handler: Any, desired_closed: bool, arm_q7: np.ndarray) -> None:
    """Publish an open/close gripper target without blocking the control loop."""
    publish = getattr(handler, "publish_binary_gripper", None)
    if callable(publish):
        publish(desired_closed)
        return
    width_m = _binary_gripper_width_m(desired_closed)
    q7 = np.asarray(arm_q7, dtype=np.float64).reshape(7)
    handler.set_joint_pose(q7.tolist() + [width_m])


def gripper_ready_for_arm_step(
    handler: Any,
    q9: np.ndarray,
    tracker: PolicyGripperTracker,
) -> bool:
    """Return True when the gripper is settled for this step's binarized target."""
    desired_closed = desired_closed_from_q9(q9)
    width_m = _read_gripper_width_m(handler)

    if tracker.last_commanded_closed is None:
        tracker.last_commanded_closed = physical_gripper_is_closed(width_m)

    if physical_gripper_is_settled(width_m, desired_closed):
        tracker.last_commanded_closed = desired_closed
        tracker.unsettled_ticks = 0
        return True

    if tracker.last_commanded_closed != desired_closed:
        _publish_binary_gripper(handler, desired_closed, q9[:7])
        tracker.last_commanded_closed = desired_closed
        tracker.unsettled_ticks = 0
        return False

    tracker.unsettled_ticks += 1
    if desired_closed and tracker.unsettled_ticks >= GRIPPER_GRASP_ASSUME_TICKS:
        log_event(
            "molmoact2",
            f"gripper grasp assumed after {tracker.unsettled_ticks} ticks "
            f"(width={width_m:.4f} m) — continuing arm",
        )
        tracker.unsettled_ticks = 0
        return True

    return False


def apply_policy_arm_targets(handler: Any, q9: np.ndarray) -> None:
    """Send arm joint targets only (no gripper width in setJointPose)."""
    q = np.asarray(q9, dtype=np.float64).reshape(9)
    handler.set_joint_pose(q[:7].tolist())


def reset_policy_gripper_tracker(handler: Any) -> None:
    tracker = getattr(handler, "_policy_gripper", None)
    if isinstance(tracker, PolicyGripperTracker):
        tracker.last_commanded_closed = None
        tracker.unsettled_ticks = 0


def apply_policy_joint_targets_binary(
    handler: Any,
    q9: np.ndarray,
    tracker: PolicyGripperTracker,
) -> bool:
    """Gate arm motion on binary gripper settle. Returns True if arm targets were applied."""
    if not gripper_ready_for_arm_step(handler, q9, tracker):
        return False
    apply_policy_arm_targets(handler, q9)
    return True


def apply_policy_joint_targets_coordinated(
    handler: Any,
    q9: np.ndarray,
    tracker: PolicyGripperTracker,
) -> bool:
    """Always stream the arm; publish a binary gripper command only when the target changes.

    Unlike :func:`apply_policy_joint_targets_binary` this never blocks arm motion waiting for the
    gripper to settle, so coordinated arm+gripper timing (e.g. descending while the fingers close)
    is preserved. Deciding *when to advance the chunk* is left to the settle checks in the
    controller (``_sync_step_settled``); this function only decides *what to command this tick*.

    Always returns ``True`` (the arm target is applied every tick).
    """
    q = np.asarray(q9, dtype=np.float64).reshape(9)
    desired_closed = desired_closed_from_q9(q)
    width_m = _read_gripper_width_m(handler)
    if tracker.last_commanded_closed is None:
        tracker.last_commanded_closed = physical_gripper_is_closed(width_m)
        # First tick after stream start can have jaws at an arbitrary width (often ~0.04 m).
        # If the physical gripper is not yet in the desired settled regime, publish one explicit
        # open/close command even when the inferred binary state matches, otherwise settle checks
        # can wait until timeout every step (arm settled, gripper never reaches open threshold).
        if not physical_gripper_is_settled(width_m, desired_closed):
            cmd_width_m = q9_width_m(q)
            _publish_binary_gripper(handler, desired_closed, q[:7])
            log_event(
                "molmoact2",
                "gripper publish resync init=%s desired=%s width=%.4f cmd_width_m=%.4f"
                % (
                    "close" if tracker.last_commanded_closed else "open",
                    "close" if desired_closed else "open",
                    width_m,
                    cmd_width_m,
                ),
            )
            tracker.last_commanded_closed = desired_closed
            tracker.unsettled_ticks = 0
    if tracker.last_commanded_closed != desired_closed:
        prev_closed = tracker.last_commanded_closed
        cmd_width_m = q9_width_m(q)
        _publish_binary_gripper(handler, desired_closed, q[:7])
        log_event(
            "molmoact2",
            "gripper publish edge prev=%s next=%s cmd_width_m=%.4f"
            % (
                "close" if prev_closed else "open",
                "close" if desired_closed else "open",
                cmd_width_m,
            ),
        )
        tracker.last_commanded_closed = desired_closed
        tracker.unsettled_ticks = 0
    apply_policy_arm_targets(handler, q)
    return True
