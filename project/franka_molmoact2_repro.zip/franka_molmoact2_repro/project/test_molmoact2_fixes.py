#!/usr/bin/env python3
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Regression tests for the MolmoAct2 control-layer fixes (see ``fixes.md``).

Run with the project interpreter (no pytest required):

    python3 test_molmoact2_fixes.py
"""

from __future__ import annotations

import sys
import threading
import unittest
from pathlib import Path

_PROJECT_DIR = Path(__file__).resolve().parent
if str(_PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(_PROJECT_DIR))

import numpy as np

import motion_server_action_offset as ao
import motion_server_cpp_proxy as cp
import motion_server_droid_units as du
import motion_server_molmoact2 as mm
import motion_server_policy_gripper as pg


class _FakeHandler:
    """Minimal policy handler used to exercise the coordinated gripper apply path."""

    def __init__(self, width: float = du.FRANKA_GRIPPER_MAX_WIDTH_M) -> None:
        self.width = width
        self.arm_calls = 0
        self.last_arm_q7: list[float] | None = None
        self.gripper_pub: list[bool] = []

    def get_joint_positions_q9(self) -> np.ndarray:
        half = self.width / 2.0
        return np.array([0, 0, 0, 0, 0, 0, 0, half, half], dtype=np.float64)

    def set_joint_pose(self, numbers: list[float]) -> list[float]:
        if len(numbers) == 7:
            self.arm_calls += 1
            self.last_arm_q7 = list(numbers)
        return list(numbers)

    def read_gripper_state(self) -> list[float]:
        return [self.width]

    def publish_binary_gripper(self, closed: bool) -> None:
        self.gripper_pub.append(bool(closed))


class _StubController(mm.MolmoAct2Controller):
    """Controller with just enough state to call ``configure`` without hardware."""

    def __init__(self) -> None:  # noqa: D401 - intentionally skips base __init__
        self._lock = threading.Lock()
        self._status = mm.MolmoAct2Status()

    def _sync_debug_status(self) -> None:
        pass

    def _sync_handler_floor_config(self) -> None:
        pass

    def _sync_wrist_perception_tuner(self) -> None:
        pass


class Fix2Threshold(unittest.TestCase):
    def test_threshold_single_source(self) -> None:
        # Both modules must share one close/open boundary (value is operator-tunable).
        self.assertEqual(du.GRIPPER_CLOSE_THRESHOLD, pg.GRIPPER_CLOSE_THRESHOLD)
        self.assertTrue(0.0 < du.GRIPPER_CLOSE_THRESHOLD < 1.0)

    def test_binary_value_single_source(self) -> None:
        # policy_gripper re-exports the droid_units implementation (no duplicate).
        self.assertIs(pg.droid_gripper_binary_value, du.droid_gripper_binary_value)

    def test_decision_boundary(self) -> None:
        thr = du.GRIPPER_CLOSE_THRESHOLD
        self.assertEqual(du.droid_gripper_binary_value(thr - 0.01), 0.0)
        self.assertEqual(du.droid_gripper_binary_value(thr + 0.01), 1.0)


class Fix3ContinuousWidth(unittest.TestCase):
    def test_intermediate_command_preserved(self) -> None:
        q9 = du.actions8_to_q9(np.array([0, 0, 0, 0, 0, 0, 0, 0.5], dtype=np.float64))
        self.assertAlmostEqual(du.q9_width_m(q9), 0.04, places=6)

    def test_open_and_closed_extremes(self) -> None:
        open_q9 = du.actions8_to_q9(np.array([0, 0, 0, 0, 0, 0, 0, 0.0], dtype=np.float64))
        closed_q9 = du.actions8_to_q9(np.array([0, 0, 0, 0, 0, 0, 0, 1.0], dtype=np.float64))
        self.assertAlmostEqual(du.q9_width_m(open_q9), du.FRANKA_GRIPPER_MAX_WIDTH_M, places=6)
        self.assertAlmostEqual(du.q9_width_m(closed_q9), 0.0, places=6)


class Fix1CoordinatedApply(unittest.TestCase):
    def test_arm_never_blocked_gripper_edge_published(self) -> None:
        handler = _FakeHandler(width=du.FRANKA_GRIPPER_MAX_WIDTH_M)
        tracker = pg.PolicyGripperTracker()

        open_q9 = np.array([0.1, 0, 0, 0, 0, 0, 0, 0.04, 0.04], dtype=np.float64)
        self.assertTrue(pg.apply_policy_joint_targets_coordinated(handler, open_q9, tracker))
        self.assertEqual(handler.arm_calls, 1)

        close_q9 = np.array([0.2, 0, 0, 0, 0, 0, 0, 0.0, 0.0], dtype=np.float64)
        self.assertTrue(pg.apply_policy_joint_targets_coordinated(handler, close_q9, tracker))
        self.assertEqual(handler.arm_calls, 2)  # arm streamed, not blocked
        self.assertEqual(handler.gripper_pub, [True])  # published once on edge

        # Repeat close: no duplicate gripper publish, arm keeps streaming.
        self.assertTrue(pg.apply_policy_joint_targets_coordinated(handler, close_q9, tracker))
        self.assertEqual(handler.arm_calls, 3)
        self.assertEqual(handler.gripper_pub, [True])

    def test_initial_open_resync_published_when_not_settled(self) -> None:
        # Startup aperture can be ~0.04 m: binary says "open" already, but open-settle requires
        # >= ~0.076 m. Coordinated mode must publish one explicit open command to avoid 5 s waits.
        handler = _FakeHandler(width=0.04)
        tracker = pg.PolicyGripperTracker()
        open_q9 = np.array([0.1, 0, 0, 0, 0, 0, 0, 0.04, 0.04], dtype=np.float64)

        self.assertTrue(pg.apply_policy_joint_targets_coordinated(handler, open_q9, tracker))
        self.assertEqual(handler.arm_calls, 1)
        self.assertEqual(handler.gripper_pub, [False])

    def test_open_settle_threshold_relaxed_for_franka(self) -> None:
        # Open-settle no longer requires near-max aperture (0.076 m); 0.065 m is open enough.
        self.assertTrue(pg.physical_gripper_is_settled(0.065, desired_closed=False))
        self.assertFalse(pg.physical_gripper_is_settled(0.055, desired_closed=False))


class GripperCommandThresholdConsistency(unittest.TestCase):
    """Regression: the hardware command path must use the SAME close threshold as every classifier.

    Field bug: ``desired_closed_from_q9`` (the only function that decides the open/close command
    actually sent to the gripper) hard-coded a droid>=0.5 boundary while the intent log, grasp
    detector and policy-state hint used ``GRIPPER_CLOSE_THRESHOLD`` (0.2). A policy value in the
    dead band ``(0.2, 0.5]`` (logged 0.277) was therefore treated as "close" everywhere but
    physically commanded "open", releasing a freshly grasped object.
    """

    def test_command_path_matches_intent_classifier(self) -> None:
        for droid_g in (0.0, 0.05, 0.1, 0.15, 0.19, 0.21, 0.25, 0.277, 0.3, 0.5, 0.7, 1.0):
            q9 = du.actions8_to_q9(np.array([0, 0, 0, 0, 0, 0, 0, droid_g], dtype=np.float64))
            self.assertEqual(
                pg.desired_closed_from_q9(q9),
                pg.droid_gripper_is_closed_command(droid_g),
                msg=f"command/intent disagree at droid_g={droid_g}",
            )

    def test_logged_dropbug_value_commands_close(self) -> None:
        # The exact gripper value from the field log that released a held object.
        q9 = du.actions8_to_q9(np.array([0, 0, 0, 0, 0, 0, 0, 0.277], dtype=np.float64))
        self.assertTrue(pg.desired_closed_from_q9(q9))

    def test_holding_gripper_not_reopened_by_deadband_value(self) -> None:
        # Object held (~5 cm jaw width) and gripper already commanded closed: a policy step of
        # droid_g=0.277 must NOT publish an open command, so the object is not dropped mid-air.
        handler = _FakeHandler(width=0.0516)  # held-object width from the log
        tracker = pg.PolicyGripperTracker(last_commanded_closed=True)
        q9 = du.actions8_to_q9(
            np.array([0.1, 0, 0, 0, 0, 0, 0, 0.277], dtype=np.float64),
            handler.get_joint_positions_q9(),
        )
        self.assertTrue(pg.apply_policy_joint_targets_coordinated(handler, q9, tracker))
        self.assertEqual(handler.gripper_pub, [])  # never opened
        self.assertEqual(handler.arm_calls, 1)  # arm still streamed


class Fix6FloorOptIn(unittest.TestCase):
    def test_floor_disabled_by_default(self) -> None:
        self.assertFalse(ao.DEFAULT_EE_FLOOR_ENABLED)
        self.assertFalse(mm.MolmoAct2Status().ee_floor_enabled)


class Fix7GraspGate(unittest.TestCase):
    def test_grasp_off_by_default_with_height_gate(self) -> None:
        status = mm.MolmoAct2Status()
        self.assertFalse(status.grasp_integration_enabled)
        self.assertAlmostEqual(
            status.grasp_integration_max_z, mm.DEFAULT_GRASP_INTEGRATION_MAX_Z_M
        )


class Fix9RateLimit(unittest.TestCase):
    def test_step_matches_servo_velocity(self) -> None:
        self.assertAlmostEqual(cp._MAX_JOINT_STEP_RAD, 0.5 / 15.0, places=9)


class Fix11Staleness(unittest.TestCase):
    def test_status_exposes_freshness_fields(self) -> None:
        status = mm.MolmoAct2Status()
        for field in (
            "last_obs_frame_age_ms",
            "last_obs_state_skew_ms",
            "last_max_joint_tracking_err_rad",
        ):
            self.assertTrue(hasattr(status, field), field)


class Fix12Preset(unittest.TestCase):
    def test_hardware_pnp_preset(self) -> None:
        controller = _StubController()
        status = controller.configure(preset="hardware_pnp")
        self.assertEqual(status.execution_mode, "auto")
        self.assertEqual(status.chunk_horizon, 4)
        self.assertFalse(status.grasp_integration_enabled)

    def test_explicit_kwarg_overrides_preset(self) -> None:
        controller = _StubController()
        status = controller.configure(preset="hardware_pnp", chunk_horizon=6)
        self.assertEqual(status.chunk_horizon, 6)

    def test_unknown_preset_rejected(self) -> None:
        controller = _StubController()
        with self.assertRaises(ValueError):
            controller.configure(preset="nope")


class FixGraspHeightGate(unittest.TestCase):
    def test_macro_blocked_above_height(self) -> None:
        controller = _StubController()
        controller.configure(grasp_integration_max_z=0.12, gripper_tip_offset_m=0.1034)
        # Home-ish pose with the tip well above the table → macro must be blocked.
        q9_high = np.array([0, -0.5, 0, -2.0, 0, 1.9, 0.7, 0.0, 0.0], dtype=np.float64)
        self.assertFalse(controller._grasp_macro_allowed_here(q9_high))


class AsyncNoMidChunkPrefetch(unittest.TestCase):
    """Regression: never start inference mid-chunk (would bob the arm back to an older pose).

    MolmoAct2 returns ABSOLUTE joint targets tied to the observation instant. Fetching while a
    chunk is still executing (the reverted "prefetch") computes the next chunk from a position the
    arm has already moved past; applying it later snaps the arm back to that older pose. Inference
    must only start once the current chunk has fully completed.
    """

    def _make_controller(self) -> mm.MolmoAct2Controller:
        controller = mm.MolmoAct2Controller.__new__(mm.MolmoAct2Controller)
        controller._lock = threading.Lock()
        controller._status = mm.MolmoAct2Status(running=True)
        controller._fetch_worker_active = False
        controller._fetch_cooldown_until = 0.0
        controller._fetch_thread = None
        controller._fetch_seq = 0
        controller._pending_chunk = None
        controller._effective_execution_mode = mm.EXECUTION_MODE_ASYNC
        controller._exec_step = 0
        controller._diag_await_chunk_ticks = 0
        return controller

    def test_fetch_refused_while_chunk_in_progress(self) -> None:
        controller = self._make_controller()
        controller._action_chunk = np.zeros((4, 8), dtype=np.float32)
        controller._action_idx = 2  # 2 of 4 steps applied, 2 remaining

        img = np.zeros((180, 320, 3), dtype=np.uint8)
        state8 = np.zeros(8, dtype=np.float32)
        controller._maybe_start_fetch(
            img, img, state8, "pick", "http://localhost:8101", ext2_rgb=None
        )
        # No background worker may be started mid-chunk.
        self.assertFalse(controller._fetch_worker_active)
        self.assertIsNone(controller._fetch_thread)

    def test_fetch_refused_on_final_step(self) -> None:
        controller = self._make_controller()
        controller._action_chunk = np.zeros((4, 8), dtype=np.float32)
        controller._action_idx = 3  # last step still in progress (remaining 1)

        img = np.zeros((180, 320, 3), dtype=np.uint8)
        state8 = np.zeros(8, dtype=np.float32)
        controller._maybe_start_fetch(
            img, img, state8, "pick", "http://localhost:8101", ext2_rgb=None
        )
        self.assertFalse(controller._fetch_worker_active)
        self.assertIsNone(controller._fetch_thread)

    def test_no_prefetch_symbols_remain(self) -> None:
        # The prefetch helper/constant were removed; guard against accidental re-introduction.
        self.assertFalse(hasattr(mm, "ASYNC_PREFETCH_REMAINING_STEPS"))
        self.assertFalse(hasattr(mm.MolmoAct2Controller, "_maybe_prefetch_next_chunk"))


class GraspNoReopenWhileHolding(unittest.TestCase):
    """Regression: a force-grasped *big* object must not re-trigger poke-and-grab (drop bug).

    The Franka Hand reports the object width while grasping, so a large object (> ~4 cm) reads as
    "not closed" by jaw width alone. ``_compute_grasp_index`` must use the ``_grasp_holding`` latch
    so a chunk that keeps commanding close on a held big object yields no new open->close edge —
    otherwise the macro re-runs and its approach re-opens the gripper and drops the object. Small
    objects close past the 4 cm width threshold so they were never affected.
    """

    @staticmethod
    def _controller(width_m: float, holding: bool) -> mm.MolmoAct2Controller:
        controller = _StubController()
        controller._handler = _FakeHandler(width=width_m)
        controller._grasp_holding = holding
        controller._action_chunk = None
        controller._action_idx = 0
        controller._grasp_at_idx = None
        controller._async_awaiting_settle = False
        controller._async_target_q9 = None
        controller._sync_awaiting_settle = False
        controller._sync_target_q9 = None
        controller._exec_step = 0
        return controller

    @staticmethod
    def _closed_chunk(steps: int = 2) -> np.ndarray:
        row = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0]  # gripper command fully closed
        return np.array([row] * steps, dtype=np.float64)

    def test_first_grasp_detected_when_open(self) -> None:
        # Jaws open, not holding → the first close command is a real grasp edge at index 0.
        controller = self._controller(du.FRANKA_GRIPPER_MAX_WIDTH_M, holding=False)
        self.assertEqual(controller._compute_grasp_index(self._closed_chunk()), 0)

    def test_big_held_object_does_not_refire(self) -> None:
        # 5 cm jaw width (> 4 cm "closed" threshold) but we are holding → no spurious edge.
        controller = self._controller(0.05, holding=True)
        self.assertIsNone(controller._compute_grasp_index(self._closed_chunk()))

    def test_small_held_object_does_not_refire(self) -> None:
        # 1 cm jaw width reads as closed by width alone → no edge regardless of the latch.
        controller = self._controller(0.01, holding=False)
        self.assertIsNone(controller._compute_grasp_index(self._closed_chunk()))

    def test_latch_clears_when_fully_open(self) -> None:
        # A stale holding latch must clear once jaws are fully open so a later grasp still fires.
        controller = self._controller(du.FRANKA_GRIPPER_MAX_WIDTH_M, holding=True)
        self.assertEqual(controller._compute_grasp_index(self._closed_chunk()), 0)
        self.assertFalse(controller._grasp_holding)

    def test_finish_chunk_grasp_sets_latch(self) -> None:
        # Completing a grasp macro must record that we are now holding the object.
        controller = self._controller(0.05, holding=False)
        controller._finish_chunk_grasp()
        self.assertTrue(controller._grasp_holding)

    def test_finish_chunk_grasp_can_continue_chunk(self) -> None:
        # Async mode: after grasp macro, continue succeeding actions (no forced truncation).
        controller = self._controller(0.05, holding=False)
        controller._action_chunk = np.zeros((5, 8), dtype=np.float64)
        controller._action_idx = 2
        controller._grasp_at_idx = 2
        controller._finish_chunk_grasp(truncate_chunk=False)
        self.assertIsNotNone(controller._action_chunk)
        self.assertEqual(controller._action_idx, 3)
        self.assertIsNone(controller._grasp_at_idx)


class PolicyGripperStateSaturation(unittest.TestCase):
    """A large held object must be reported to the policy as closed, not open (drop bug).

    The Franka Hand reports a force-grasped object's width. With binary width-to-state conversion,
    widths on one side of the threshold report 1 and the other side report 0; ``closed_hint`` still
    forces a clear closed report when needed.
    """

    def test_open_gripper_reports_open(self) -> None:
        self.assertLessEqual(
            du.policy_gripper_state(du.FRANKA_GRIPPER_MAX_WIDTH_M), du.GRIPPER_OPEN_STATE_EPS
        )

    def test_medium_object_saturates_by_width(self) -> None:
        # 5 cm ball: binary width mapping crosses threshold => reports closed.
        self.assertEqual(du.gripper_width_m_to_droid(0.05), 1.0)
        self.assertGreaterEqual(du.policy_gripper_state(0.05), du.GRIPPER_CLOSED_STATE_REPORT)

    def test_wide_object_needs_hint(self) -> None:
        # 6.8 cm object: binary width mapping falls below threshold => reads open by width alone...
        self.assertEqual(du.policy_gripper_state(0.068), 0.0)
        # ...but with the holding hint it reports closed.
        self.assertGreaterEqual(
            du.policy_gripper_state(0.068, closed_hint=True), du.GRIPPER_CLOSED_STATE_REPORT
        )

    def test_stale_hint_cannot_close_open_jaws(self) -> None:
        # Fully open jaws + a stale hint must still report open (release at place still works).
        self.assertLessEqual(
            du.policy_gripper_state(du.FRANKA_GRIPPER_MAX_WIDTH_M, closed_hint=True),
            du.GRIPPER_OPEN_STATE_EPS,
        )

    def test_state8_gripper_dim_uses_hint(self) -> None:
        q9 = np.array([0, 0, 0, 0, 0, 0, 0, 0.034, 0.034], dtype=np.float64)  # ~6.8 cm width
        raw = du.state8_from_q9(q9)
        hinted = du.state8_from_q9(q9, gripper_closed_hint=True)
        self.assertEqual(float(raw[7]), 0.0)
        self.assertGreaterEqual(float(hinted[7]), du.GRIPPER_CLOSED_STATE_REPORT)
        # The arm joints must be untouched by the gripper saturation.
        np.testing.assert_allclose(raw[:7], hinted[:7])


class PolicyGripperClosedHint(unittest.TestCase):
    """The controller reports "holding" from the macro latch or the last binary close command."""

    @staticmethod
    def _controller() -> mm.MolmoAct2Controller:
        controller = mm.MolmoAct2Controller.__new__(mm.MolmoAct2Controller)
        controller._grasp_holding = False
        controller._handler = _FakeHandler()
        return controller

    def test_default_is_open(self) -> None:
        self.assertFalse(self._controller()._policy_gripper_closed_hint())

    def test_holding_latch_reports_closed(self) -> None:
        controller = self._controller()
        controller._grasp_holding = True
        self.assertTrue(controller._policy_gripper_closed_hint())

    def test_last_commanded_close_reports_closed(self) -> None:
        controller = self._controller()
        tracker = pg.PolicyGripperTracker()
        tracker.last_commanded_closed = True
        controller._handler._policy_gripper = tracker
        self.assertTrue(controller._policy_gripper_closed_hint())


if __name__ == "__main__":
    unittest.main(verbosity=2)
