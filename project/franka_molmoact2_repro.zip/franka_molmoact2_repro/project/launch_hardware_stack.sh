#!/usr/bin/env bash
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Launch libfranka motion_server.cpp (if needed) and the hardware web UI.
#
# Usage:
#   ./launch_hardware_stack.sh
#   ./launch_hardware_stack.sh --robot-ip 192.168.2.100
#   MOLMOACT2_URL=http://gpu-host:8101 ./launch_hardware_stack.sh
#
# Environment:
#   MOLMO_ROBOT_IP          Franka FCI IP (default: 192.168.2.100)
#   MOLMO_CPP_MOTION_PORT   libfranka HTTP port (default: 34569)
#   MOLMO_UI_PORT           Web UI port (default: 34568)
#   MOLMO_MOTION_BACKEND    Override backend URL (auto-detected if unset)
#   MOLMOACT2_URL           MolmoAct2 inference URL (default: http://localhost:8101)
#   MOLMO_KILL_EXISTING     Kill stale stack processes before launch (default: 1)
#   MOLMO_SKIP_HOME         Skip arm/gripper homing on motion_server startup (default: 1)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

ROBOT_IP="${MOLMO_ROBOT_IP:-192.168.2.100}"
BACKEND_PORT="${MOLMO_CPP_MOTION_PORT:-34569}"
UI_PORT="${MOLMO_UI_PORT:-34568}"
MOLMOACT2_URL="${MOLMOACT2_URL:-http://localhost:8101}"
MOLMO_KILL_EXISTING="${MOLMO_KILL_EXISTING:-1}"
MOLMO_SKIP_HOME="${MOLMO_SKIP_HOME:-1}"
LOG_DIR="${MOLMO_LOG_DIR:-/tmp/franka_molmoact2}"
BACKEND_PID_FILE="${LOG_DIR}/motion_server_${BACKEND_PORT}.pid"
BACKEND_LOG="${LOG_DIR}/motion_server_${BACKEND_PORT}.log"

EXTRA_UI_ARGS=()

usage() {
  sed -n '2,18p' "$0" | sed 's/^# \{0,1\}//'
  exit "${1:-0}"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help) usage 0 ;;
    --robot-ip) ROBOT_IP="${2:?}"; shift 2 ;;
    --backend-port) BACKEND_PORT="${2:?}"; shift 2 ;;
    --ui-port) UI_PORT="${2:?}"; shift 2 ;;
    --molmoact2-url) MOLMOACT2_URL="${2:?}"; shift 2 ;;
    --no-cameras) EXTRA_UI_ARGS+=(--no-cameras); shift ;;
    --no-ui) EXTRA_UI_ARGS+=(--no-ui); shift ;;
    *) echo "Unknown argument: $1" >&2; usage 1 ;;
  esac
done

mkdir -p "${LOG_DIR}"

probe_motion_port() {
  local port="$1"
  curl -sf -m 3 -X POST "http://127.0.0.1:${port}/" \
    -H "Content-Type: application/json" \
    -d '{"readState":[]}' 2>/dev/null | grep -q '"readState"'
}

probe_web_ui() {
  local port="$1"
  curl -sf -m 3 "http://127.0.0.1:${port}/" 2>/dev/null | grep -qi '<title>'
}

pid_alive() {
  local pid="$1"
  [[ -n "${pid}" ]] && kill -0 "${pid}" 2>/dev/null
}

port_in_use() {
  local port="$1"
  ss -tln 2>/dev/null | grep -q ":${port} "
}

port_listener_pids() {
  local port="$1"
  local -a pids=()
  mapfile -t pids < <(
    ss -tlnp 2>/dev/null | awk -v port=":${port}" '
      $0 ~ port && /pid=/ {
        while (match($0, /pid=[0-9]+/)) {
          print substr($0, RSTART + 4, RLENGTH - 4)
          $0 = substr($0, RSTART + RLENGTH)
        }
      }
    ' | sort -u
  )
  if [[ ${#pids[@]} -eq 0 ]] && command -v lsof >/dev/null 2>&1; then
    mapfile -t pids < <(lsof -ti "TCP:${port}" -sTCP:LISTEN 2>/dev/null | sort -u)
  fi
  if [[ ${#pids[@]} -eq 0 ]] && command -v fuser >/dev/null 2>&1; then
    mapfile -t pids < <(fuser "${port}/tcp" 2>/dev/null | tr ' ' '\n' | grep -E '^[0-9]+$' | sort -u)
  fi
  if [[ ${#pids[@]} -gt 0 ]]; then
    printf '%s\n' "${pids[@]}"
  fi
}

stop_pid_gracefully() {
  local pid="$1"
  [[ -n "${pid}" ]] || return 0
  if ! pid_alive "${pid}"; then
    return 0
  fi
  kill "${pid}" 2>/dev/null || true
  for _ in $(seq 1 10); do
    if ! pid_alive "${pid}"; then
      return 0
    fi
    sleep 0.2
  done
  kill -9 "${pid}" 2>/dev/null || true
}

stop_port_listeners() {
  local port="$1"
  local pid
  mapfile -t pids < <(port_listener_pids "${port}")
  if [[ ${#pids[@]} -eq 0 ]]; then
    return 0
  fi
  echo "Stopping listener(s) on port ${port}: ${pids[*]}"
  for pid in "${pids[@]}"; do
    stop_pid_gracefully "${pid}"
  done
}

wait_port_free() {
  local port="$1"
  local max_wait="${2:-15}"
  local attempt
  for attempt in $(seq 1 "${max_wait}"); do
    if ! port_in_use "${port}"; then
      return 0
    fi
    if [[ "${attempt}" -le 3 ]]; then
      stop_port_listeners "${port}"
      if command -v fuser >/dev/null 2>&1; then
        fuser -k "${port}/tcp" 2>/dev/null || true
      fi
    fi
    sleep 0.5
  done
  echo "ERROR: port ${port} is still in use after cleanup." >&2
  if command -v lsof >/dev/null 2>&1; then
    lsof -nP -i "TCP:${port}" >&2 || true
  elif command -v ss >/dev/null 2>&1; then
    ss -tlnp 2>/dev/null | grep ":${port} " >&2 || true
  fi
  return 1
}

kill_existing_stack() {
  echo "Stopping any existing hardware stack processes..."

  if [[ -f "${BACKEND_PID_FILE}" ]]; then
    local recorded_pid
    recorded_pid="$(cat "${BACKEND_PID_FILE}" 2>/dev/null || true)"
    if [[ -n "${recorded_pid}" ]]; then
      stop_pid_gracefully "${recorded_pid}"
    fi
    rm -f "${BACKEND_PID_FILE}"
  fi

  # Wrapper shells from prior launches: (echo; tail -f /dev/null) | ./motion_server ...
  pkill -f "${SCRIPT_DIR}/motion_server ${ROBOT_IP} ${BACKEND_PORT}" 2>/dev/null || true
  pkill -f "${SCRIPT_DIR}/motion_server ${ROBOT_IP}" 2>/dev/null || true
  pkill -f "hardware_motion_server.py" 2>/dev/null || true
  pkill -f "hardware_motion_server.py --port ${UI_PORT}" 2>/dev/null || true

  stop_port_listeners "${BACKEND_PORT}"
  stop_port_listeners "${UI_PORT}"

  if command -v fuser >/dev/null 2>&1; then
    fuser -k "${BACKEND_PORT}/tcp" 2>/dev/null || true
    fuser -k "${UI_PORT}/tcp" 2>/dev/null || true
  fi

  wait_port_free "${BACKEND_PORT}" 10 || true
  wait_port_free "${UI_PORT}" 10 || true
}

ensure_motion_server_binary() {
  local bin="${SCRIPT_DIR}/motion_server"
  local -a srcs=(
    "${SCRIPT_DIR}/motion_server.cpp"
    "${SCRIPT_DIR}/common.cpp"
    "${SCRIPT_DIR}/common.h"
  )

  if [[ ! -f "${SCRIPT_DIR}/common.cpp" || ! -f "${SCRIPT_DIR}/common.h" ]]; then
    local fallback="/home/researcher/franka/franka/cpp"
    if [[ -f "${fallback}/common.cpp" && -f "${fallback}/common.h" ]]; then
      cp "${fallback}/common.cpp" "${fallback}/common.h" "${SCRIPT_DIR}/"
      echo "Copied common.cpp/common.h from ${fallback}"
    else
      echo "ERROR: motion_server binary missing and common.cpp not found." >&2
      echo "Build manually: cd project && g++ -std=c++11 motion_server.cpp common.cpp -o motion_server \\" >&2
      echo "  -I/usr/include/eigen3 -lfranka -lcpprest -lssl -lcrypto -lboost_system -pthread" >&2
      exit 1
    fi
  fi

  # Skip rebuild only when the binary exists and is newer than all build inputs.
  if [[ -x "${bin}" ]]; then
    local src
    local stale=0
    for src in "${srcs[@]}"; do
      if [[ "${src}" -nt "${bin}" ]]; then
        stale=1
        break
      fi
    done
    if [[ "${stale}" -eq 0 ]]; then
      return 0
    fi
    echo "motion_server sources changed; rebuilding..."
  fi

  echo "Building motion_server..."
  g++ -std=c++11 motion_server.cpp common.cpp -o motion_server \
    -I/usr/include/eigen3 \
    -lfranka -lcpprest -lssl -lcrypto -lboost_system -pthread
}

resolve_backend_url() {
  if [[ -n "${MOLMO_MOTION_BACKEND:-}" ]]; then
    echo "${MOLMO_MOTION_BACKEND%/}"
    return 0
  fi
  if probe_motion_port "${BACKEND_PORT}"; then
    echo "http://127.0.0.1:${BACKEND_PORT}"
    return 0
  fi
  if probe_motion_port "${UI_PORT}"; then
    echo "http://127.0.0.1:${UI_PORT}"
    return 0
  fi
  return 1
}

start_motion_backend() {
  if [[ "${MOLMO_KILL_EXISTING}" == "0" ]]; then
    if probe_motion_port "${BACKEND_PORT}"; then
      echo "motion_server.cpp already responding on port ${BACKEND_PORT}"
      return 0
    fi
    if probe_motion_port "${UI_PORT}"; then
      echo "motion_server.cpp already responding on port ${UI_PORT} (legacy single-port setup)"
      return 0
    fi
  elif port_listener_pids "${BACKEND_PORT}" | grep -q .; then
    echo "Port ${BACKEND_PORT} is occupied but not responding — restarting motion_server.cpp"
    kill_existing_stack
  fi

  ensure_motion_server_binary

  echo "Starting motion_server.cpp (robot ${ROBOT_IP}, port ${BACKEND_PORT})..."
  echo "  log: ${BACKEND_LOG}"
  export MOLMO_SKIP_HOME
  if [[ "${MOLMO_SKIP_HOME}" == "1" ]]; then
    # No leading echo — a newline on stdin makes motion_server exit immediately in skip-home mode.
    bash -c "tail -f /dev/null | ./motion_server '${ROBOT_IP}' '${BACKEND_PORT}' --skip-home" \
      >"${BACKEND_LOG}" 2>&1 &
  else
    # Leading echo satisfies goHome() "Press Enter to continue" during interactive homing.
    bash -c "(echo; tail -f /dev/null) | ./motion_server '${ROBOT_IP}' '${BACKEND_PORT}'" \
      >"${BACKEND_LOG}" 2>&1 &
  fi
  local pid=$!
  echo "${pid}" >"${BACKEND_PID_FILE}"

  for _ in $(seq 1 90); do
    if probe_motion_port "${BACKEND_PORT}"; then
      echo "motion_server.cpp ready on port ${BACKEND_PORT} (pid ${pid})"
      return 0
    fi
    if ! pid_alive "${pid}"; then
      echo "ERROR: motion_server exited during startup. Last log lines:" >&2
      tail -30 "${BACKEND_LOG}" >&2 || true
      exit 1
    fi
    sleep 1
  done

  echo "ERROR: motion_server did not become ready on port ${BACKEND_PORT}." >&2
  tail -30 "${BACKEND_LOG}" >&2 || true
  exit 1
}

main() {
  echo
  echo "=== Hardware Franka stack launcher ==="
  echo "  robot IP      = ${ROBOT_IP}"
  echo "  backend port  = ${BACKEND_PORT}"
  echo "  web UI port   = ${UI_PORT}"
  echo "  MolmoAct2 URL = ${MOLMOACT2_URL}"
  echo "  kill existing = ${MOLMO_KILL_EXISTING}"
  echo "  skip home     = ${MOLMO_SKIP_HOME}"
  echo

  if [[ "${MOLMO_KILL_EXISTING}" != "0" ]]; then
    kill_existing_stack
  fi

  start_motion_backend

  local backend_url
  backend_url="$(resolve_backend_url)"
  echo "Motion backend: ${backend_url}"

  if [[ "${MOLMO_KILL_EXISTING}" == "0" ]] && probe_web_ui "${UI_PORT}"; then
    echo "Web UI already running: http://127.0.0.1:${UI_PORT}/"
    exit 0
  fi

  if port_listener_pids "${UI_PORT}" | grep -q . || port_in_use "${UI_PORT}"; then
    echo "Port ${UI_PORT} still in use — stopping remaining listener(s)"
    stop_port_listeners "${UI_PORT}"
    if command -v fuser >/dev/null 2>&1; then
      fuser -k "${UI_PORT}/tcp" 2>/dev/null || true
    fi
  fi
  wait_port_free "${UI_PORT}" 15

  if ! python3 -c "import cv2, pyrealsense2" 2>/dev/null; then
    echo "Installing USB camera dependencies..."
    pip install -q -r "${SCRIPT_DIR}/requirements-usb.txt"
  fi

  echo "Starting hardware web UI on port ${UI_PORT}..."
  exec python3 "${SCRIPT_DIR}/hardware_motion_server.py" \
    --port "${UI_PORT}" \
    --motion-backend "${backend_url}" \
    --molmoact2-url "${MOLMOACT2_URL}" \
    "${EXTRA_UI_ARGS[@]}"
}

main "$@"
