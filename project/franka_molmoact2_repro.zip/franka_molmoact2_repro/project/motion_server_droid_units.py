# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""DROID / MolmoAct2-DROID unit conventions for Franka Panda hardware.

MolmoAct2-DROID ``state`` and ``actions`` use:
  - joints 0–6: absolute Franka joint angles in radians (same order as libfranka q1–q7)
  - gripper (dim 7): normalized position, 0 = fully open, 1 = fully closed

Hardware ``motion_server.cpp`` gripper commands use finger aperture width in meters.
"""

from __future__ import annotations

import numpy as np

# Franka Hand max jaw width (m); matches motion_server_handler.GRIPPER_MAX_WIDTH.
FRANKA_GRIPPER_MAX_WIDTH_M = 0.08

# Single close/open decision boundary for the DROID gripper command (0=open, 1=closed). Shared by
# EVERY open/close decision so they cannot disagree: the policy STATE classifier
# (``droid_gripper_binary_value`` / ``gripper_width_m_to_droid``), the grasp-edge detector, the
# intent log (``droid_gripper_is_closed_command``), AND the actual hardware command path
# (``desired_closed_from_q9`` -> ``apply_policy_joint_targets_coordinated``). It does NOT control
# whether the hardware applies a *force grasp*: the C++ force grasp triggers on the commanded jaw
# width (<= kGraspCloseWidthM, 0.02 m) inside ``gripperStreamWorker`` — the ``syncPolicyGripper``
# endpoint is not on the policy path, so its threshold is irrelevant here. Lowering this value
# biases the policy toward holding (a smaller commanded close still counts as "closed").
GRIPPER_CLOSE_THRESHOLD = 0.2

# Gripper STATE value (0=open, 1=closed) reported to the policy when the gripper is closed/holding.
# The Franka Hand reports a force-grasped object's *width*, so a large held object reads as only
# partly closed (e.g. a 5 cm ball -> 0.375, a 6.8 cm box -> 0.15). MolmoAct2-DROID trained on a
# force-adaptive Robotiq that read near fully closed while holding, so without saturation the
# policy treats a big grasp as "not grasped" and commands a release (drops the object). Saturating
# the reported state into the closed regime gives the policy a clear "holding" signal.
GRIPPER_CLOSED_STATE_REPORT = 0.8
# At/below this reported closure the jaws are effectively fully open (width >= ~95% of max), so a
# stale "holding" hint can never make an open/empty gripper look closed to the policy.
GRIPPER_OPEN_STATE_EPS = 0.05

JOINT_NAMES = ("q1", "q2", "q3", "q4", "q5", "q6", "q7")


def gripper_width_m_to_droid(width_m: float, *, max_width_m: float = FRANKA_GRIPPER_MAX_WIDTH_M) -> float:
    """Convert libfranka width to a binary DROID gripper state using close/open threshold.

    Requested simplification: treat gripper state as strictly binary for policy input.
    If the inferred closed ratio is above ``GRIPPER_CLOSE_THRESHOLD`` report 1.0 (closed),
    otherwise 0.0 (open).
    """
    if max_width_m <= 0.0:
        return 0.0
    open_ratio = float(np.clip(width_m / max_width_m, 0.0, 1.0))
    closed_ratio = float(1.0 - open_ratio)
    return 1.0 if closed_ratio > GRIPPER_CLOSE_THRESHOLD else 0.0


def droid_gripper_to_width_m(droid_g: float, *, max_width_m: float = FRANKA_GRIPPER_MAX_WIDTH_M) -> float:
    """Convert DROID gripper command to Franka jaw width in meters."""
    closed_ratio = float(np.clip(droid_g, 0.0, 1.0))
    return float((1.0 - closed_ratio) * max_width_m)


def policy_gripper_state(
    width_m: float,
    *,
    closed_hint: bool = False,
    max_width_m: float = FRANKA_GRIPPER_MAX_WIDTH_M,
    closed_report: float = GRIPPER_CLOSED_STATE_REPORT,
) -> float:
    """DROID gripper STATE (0=open, 1=closed) for the policy, with optional holding hint.

    With binary ``gripper_width_m_to_droid`` this already returns 0/1 by width threshold; when
    ``closed_hint`` is set, force at least ``closed_report`` so grasped objects remain clearly
    closed in policy state.
    """
    droid = gripper_width_m_to_droid(width_m, max_width_m=max_width_m)
    # "Fully open" needs continuous width evidence; with binary mapping droid may be 0.0 for both
    # open jaws and wide held objects, so use the geometric ratio here.
    if max_width_m <= 0.0:
        return 0.0
    open_ratio = float(np.clip(width_m / max_width_m, 0.0, 1.0))
    continuous_closed = float(1.0 - open_ratio)
    if continuous_closed <= GRIPPER_OPEN_STATE_EPS:
        return 0.0  # jaws ~fully open: never report as holding, even with a stale hint
    if closed_hint or droid > GRIPPER_CLOSE_THRESHOLD:
        return float(max(droid, closed_report))
    return droid


def q9_width_m(q9: np.ndarray, *, max_width_m: float = FRANKA_GRIPPER_MAX_WIDTH_M) -> float:
    """Full gripper width (m) from 9-DOF q (finger joints store half-width each)."""
    q = np.asarray(q9, dtype=np.float64).reshape(9)
    return float(np.clip(float(q[7]) + float(q[8]), 0.0, max_width_m))


def state8_from_q9(
    q9: np.ndarray,
    *,
    max_width_m: float = FRANKA_GRIPPER_MAX_WIDTH_M,
    gripper_closed_hint: bool = False,
) -> np.ndarray:
    """Build MolmoAct2 8-D state from 9-DOF Franka observation.

    ``gripper_closed_hint`` saturates the reported gripper state into the closed regime when the
    gripper is known to be holding (see :func:`policy_gripper_state`) so a large grasped object is
    not presented to the policy as an open gripper.
    """
    q = np.asarray(q9, dtype=np.float64).reshape(9)
    width_m = q9_width_m(q, max_width_m=max_width_m)
    gripper = policy_gripper_state(
        width_m, closed_hint=gripper_closed_hint, max_width_m=max_width_m
    )
    return np.concatenate([q[:7], [gripper]]).astype(np.float32)


def droid_gripper_binary_value(droid_g: float) -> float:
    """Binarize DROID gripper command: >GRIPPER_CLOSE_THRESHOLD → closed (1), else open (0)."""
    return 1.0 if float(droid_g) > GRIPPER_CLOSE_THRESHOLD else 0.0


def actions8_to_q9(action8: np.ndarray, current_q9: np.ndarray | None = None) -> np.ndarray:
    """Expand denormalized 8-D MolmoAct2 action to 9-DOF Franka command vector.

    The gripper command is kept continuous here (no binarization): the policy's intermediate
    gripper gradations are preserved in the finger-width fields. Open/close binarization happens
    only in the settle/grasp classification (``desired_closed_from_q9`` /
    ``GRIPPER_CLOSE_THRESHOLD``), not in the action-to-q9 conversion.
    """
    a = np.asarray(action8, dtype=np.float64).reshape(8)
    if current_q9 is None:
        q = np.zeros(9, dtype=np.float64)
    else:
        q = np.asarray(current_q9, dtype=np.float64).reshape(9).copy()
    q[:7] = a[:7]
    width_m = droid_gripper_to_width_m(float(a[7]))
    half = width_m / 2.0
    q[7] = half
    q[8] = half
    return q


def gripper_width_for_set_joint_pose(q9: np.ndarray, *, max_width_m: float = FRANKA_GRIPPER_MAX_WIDTH_M) -> float:
    """Width (m) for ``setJointPose`` optional 8th argument."""
    return q9_width_m(q9, max_width_m=max_width_m)
