# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""RGB camera capture for the Isaac Sim motion server web UI."""

from __future__ import annotations

import threading

import numpy as np
import omni
from isaacsim.sensors.camera import Camera
from pxr import UsdGeom

from motion_server_camera_common import (
    CAMERA_HEIGHT,
    CAMERA_WIDTH,
    MOLMOACT2_POLICY_SHAPE,
    POLICY_CAPTURE_HZ,
    PREVIEW_JPEG_QUALITY,
    CameraSpec,
    WristTuneFn,
    _encode_jpeg,
    ensure_uint8_rgb,
    pack_policy_images,
    policy_camera_ids,
    prepare_molmoact2_image,
    resolve_wrist_policy_rgb,
)


def discover_stage_cameras() -> list[CameraSpec]:
    """Return MolmoAct2-style cameras on the stage (external_1, external_2, wrist)."""
    stage = omni.usd.get_context().get_stage()
    preferred = [
        ("external_1", "Exterior 1 (left, ZED 2)", "/World/Cameras/external_1"),
        ("external_2", "Exterior 2 (front, ZED 2)", "/World/Cameras/external_2"),
    ]
    specs: list[CameraSpec] = []
    for camera_id, label, path in preferred:
        if stage.GetPrimAtPath(path).IsValid():
            specs.append(CameraSpec(camera_id, label, path))

    for prim in stage.Traverse():
        if not prim.IsA(UsdGeom.Camera):
            continue
        path = str(prim.GetPath())
        if path.endswith("/wrist_camera"):
            specs.append(CameraSpec("wrist", "Wrist (RealSense D435)", path))
            break

    if specs:
        return specs

    for prim in stage.Traverse():
        if not prim.IsA(UsdGeom.Camera):
            continue
        path = str(prim.GetPath())
        if path.startswith("/OmniverseKit_"):
            continue
        camera_id = path.rstrip("/").split("/")[-1]
        label = camera_id.replace("_", " ").title()
        specs.append(CameraSpec(camera_id, label, path))
    return specs


class CameraStreamManager:
    """Policy RGB on the sim thread @ 15 Hz; web preview JPEGs encoded lazily on HTTP threads."""

    def __init__(
        self,
        specs: list[CameraSpec],
        resolution: tuple[int, int] = (CAMERA_WIDTH, CAMERA_HEIGHT),
        *,
        policy_hz: float = POLICY_CAPTURE_HZ,
    ) -> None:
        self._specs = specs
        self._resolution = resolution
        self._policy_hz = policy_hz
        self._policy_accum = 0.0
        self._cameras: dict[str, Camera] = {}
        self._jpeg_cache: dict[str, bytes] = {}
        self._rgb_cache: dict[str, np.ndarray] = {}
        self._rgb_seq: dict[str, int] = {}
        self._jpeg_seq: dict[str, int] = {}
        self._policy_batch_id = 0
        self._rgb_batch: dict[str, int] = {}
        self._lock = threading.Lock()
        self._encode_locks: dict[str, threading.Lock] = {s.camera_id: threading.Lock() for s in specs}
        self._placeholder = _encode_jpeg(np.zeros((resolution[1], resolution[0], 3), dtype=np.uint8))
        self._wrist_source: np.ndarray | None = None
        self._wrist_tune_fn: WristTuneFn = None

    def set_wrist_perception_tuner(self, tune_fn: WristTuneFn) -> None:
        """Register live wrist crop/zoom (called from MolmoAct2 configure)."""
        with self._lock:
            self._wrist_tune_fn = tune_fn
            self._jpeg_cache.pop("wrist", None)
            self._jpeg_seq.pop("wrist", None)

    @property
    def specs(self) -> list[CameraSpec]:
        return list(self._specs)

    def initialize(self) -> None:
        for spec in self._specs:
            if spec.camera_id in self._cameras:
                continue
            self._cameras[spec.camera_id] = Camera(
                prim_path=spec.prim_path,
                name=spec.camera_id,
                resolution=self._resolution,
                annotator_device="cpu",
            )
        for camera in self._cameras.values():
            camera.initialize()

    def tick_policy(self, sim_dt: float) -> None:
        """Capture RGB for MolmoAct2 at ``policy_hz``; JPEG encoding is not performed here."""
        if self._policy_hz <= 0.0:
            return
        self._policy_accum += sim_dt
        period = 1.0 / self._policy_hz
        if self._policy_accum < period:
            return
        self._policy_accum -= period
        self._capture_rgb_all()

    def capture(self) -> None:
        """Legacy alias: capture RGB immediately (prefer ``tick_policy`` in the main loop)."""
        self._capture_rgb_all()

    def _capture_rgb_all(self) -> int | None:
        batch_id = self._policy_batch_id + 1
        captured: dict[str, np.ndarray] = {}
        wrist_source: np.ndarray | None = None
        for spec in self._specs:
            camera = self._cameras.get(spec.camera_id)
            if camera is None:
                continue
            try:
                frame = camera.get_rgb()
                if frame is None:
                    frame = camera.get_rgba()
                if frame is None:
                    continue
                rgb = ensure_uint8_rgb(frame)
                if spec.camera_id == "wrist":
                    wrist_source = rgb.copy()
                    if self._wrist_tune_fn is not None:
                        rgb = self._wrist_tune_fn(rgb)
                    else:
                        rgb = prepare_molmoact2_image(rgb)
                else:
                    rgb = prepare_molmoact2_image(rgb)
                captured[spec.camera_id] = rgb
            except Exception:
                continue
        if not captured:
            return None
        with self._lock:
            if wrist_source is not None:
                self._wrist_source = wrist_source
            self._policy_batch_id = batch_id
            for camera_id, rgb in captured.items():
                self._rgb_cache[camera_id] = rgb
                self._rgb_seq[camera_id] = self._rgb_seq.get(camera_id, 0) + 1
                self._rgb_batch[camera_id] = batch_id
        return batch_id

    def capture_policy_observation(
        self, external_slot: str = "external_1", external_camera_mode: str = "single"
    ) -> tuple[np.ndarray | None, np.ndarray | None, np.ndarray | None] | None:
        """Capture all sim cameras on the current physics frame, then return policy views."""
        batch_id = self._capture_rgb_all()
        if batch_id is None:
            return None
        required = policy_camera_ids(external_slot, external_camera_mode)
        with self._lock:
            for camera_id in required:
                if camera_id not in self._rgb_cache:
                    return None
                if self._rgb_batch.get(camera_id) != batch_id:
                    return None
            frames = {}
            for camera_id in required:
                if camera_id == "wrist":
                    # Caller already holds _lock — do not call get_rgb (would deadlock).
                    tuned = resolve_wrist_policy_rgb(
                        wrist_source=self._wrist_source,
                        wrist_cache=self._rgb_cache.get("wrist"),
                        tune_fn=self._wrist_tune_fn,
                    )
                    if tuned is None:
                        return None
                    frames[camera_id] = tuned
                else:
                    frames[camera_id] = self._rgb_cache[camera_id].copy()
        ext_rgb, ext2_rgb, wrist_rgb = pack_policy_images(frames, external_slot, external_camera_mode)
        if ext_rgb is None or wrist_rgb is None:
            return None
        if external_camera_mode == "dual" and ext2_rgb is None:
            return None
        return ext_rgb, ext2_rgb, wrist_rgb

    def get_jpeg(self, camera_id: str) -> bytes:
        """Return cached JPEG, encoding on this (HTTP) thread only if RGB has updated."""
        if camera_id == "wrist":
            rgb_copy = self.get_rgb("wrist")
            if rgb_copy is None:
                return self._placeholder
            with self._lock:
                seq = self._rgb_seq.get(camera_id, 0)
                if self._jpeg_seq.get(camera_id) == seq and camera_id in self._jpeg_cache:
                    return self._jpeg_cache[camera_id]
        else:
            with self._lock:
                rgb = self._rgb_cache.get(camera_id)
                seq = self._rgb_seq.get(camera_id, 0)
                if rgb is None:
                    return self._placeholder
                if self._jpeg_seq.get(camera_id) == seq and camera_id in self._jpeg_cache:
                    return self._jpeg_cache[camera_id]
                rgb_copy = rgb.copy()

        encode_lock = self._encode_locks.get(camera_id)
        if encode_lock is None:
            return _encode_jpeg(rgb_copy)
        with encode_lock:
            with self._lock:
                if self._jpeg_seq.get(camera_id) == seq and camera_id in self._jpeg_cache:
                    return self._jpeg_cache[camera_id]
            jpeg = _encode_jpeg(rgb_copy)
            with self._lock:
                if self._rgb_seq.get(camera_id) == seq:
                    self._jpeg_cache[camera_id] = jpeg
                    self._jpeg_seq[camera_id] = seq
                    return jpeg
                return self._jpeg_cache.get(camera_id, jpeg)

    def get_rgb(self, camera_id: str) -> np.ndarray | None:
        with self._lock:
            if camera_id == "wrist":
                return resolve_wrist_policy_rgb(
                    wrist_source=self._wrist_source,
                    wrist_cache=self._rgb_cache.get("wrist"),
                    tune_fn=self._wrist_tune_fn,
                )
            rgb = self._rgb_cache.get(camera_id)
            return None if rgb is None else rgb.copy()

    def observations_ready(
        self,
        external_slot: str = "external_1",
        external_camera_mode: str = "single",
    ) -> bool:
        with self._lock:
            if "wrist" not in self._rgb_cache:
                return False
            if external_camera_mode == "dual":
                return "external_1" in self._rgb_cache and "external_2" in self._rgb_cache
            return external_slot in self._rgb_cache

    def list_cameras(self) -> list[dict[str, str]]:
        return [{"id": s.camera_id, "label": s.label, "path": s.prim_path} for s in self._specs]
