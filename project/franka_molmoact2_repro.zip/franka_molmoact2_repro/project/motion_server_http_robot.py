# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""HTTP client for ``motion_server.cpp`` — used by the hardware MolmoAct2 runner."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any

import numpy as np

from motion_server_cpp_proxy import is_collision_recovery_error
from motion_server_policy_gripper import (
    PolicyGripperTracker,
    apply_policy_joint_targets_coordinated,
)


class MotionServerHttpRobot:
    """Drive a real Franka via the motion_server REST API (port 34568 by default)."""

    def __init__(self, base_url: str = "http://127.0.0.1:34568", timeout_s: float = 30.0) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout_s = timeout_s
        self._last_gripper_width = 0.04
        self._policy_gripper = PolicyGripperTracker()

    def _post(self, payload: dict[str, list[float]]) -> dict:
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self._base_url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout_s) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace").strip().strip('"')
            if is_collision_recovery_error(detail):
                raise RuntimeError(detail) from exc
            raise RuntimeError(f"motion_server HTTP {exc.code}: {detail}") from exc

    def get_joint_positions_q9(self) -> np.ndarray:
        payload = self._post({"readJointState": [], "readGripperState": []})
        q7 = payload.get("readJointState")
        if not q7 or len(q7) < 7:
            raise RuntimeError(f"readJointState failed: {payload}")
        grip = payload.get("readGripperState")
        if grip and len(grip) >= 1:
            width = float(grip[0])
            self._last_gripper_width = width
        else:
            width = self._last_gripper_width
        half = width / 2.0
        return np.array(list(q7[:7]) + [half, half], dtype=np.float64)

    def publish_binary_gripper(self, closed: bool) -> None:
        width = 0.0 if closed else 0.08
        if self._last_q9 is None:
            self._last_q9 = self.get_joint_positions_q9()
        cmd = self._last_q9[:7].tolist() + [width]
        self.set_joint_pose(cmd)
        self._last_gripper_width = width

    def sync_policy_gripper(self, closed: bool) -> None:
        self.publish_binary_gripper(closed)

    def apply_policy_joint_targets(
        self, q9: np.ndarray, current_q9: np.ndarray | None = None
    ) -> bool:
        q = np.asarray(q9, dtype=np.float64).reshape(9)
        if self._last_q9 is None:
            self._last_q9 = self.get_joint_positions_q9()
        current = self._last_q9
        max_joint_step = 0.08
        cmd_q = current[:7].copy()
        delta = q[:7] - current[:7]
        delta = np.clip(delta, -max_joint_step, max_joint_step)
        cmd_q = cmd_q + delta
        # Anti-windup: bound how far the ramped command leads the actual measured joints.
        if current_q9 is not None:
            actual_q7 = np.asarray(current_q9, dtype=np.float64).reshape(9)[:7]
            cmd_q = np.clip(cmd_q, actual_q7 - 0.6, actual_q7 + 0.6)
        arm_q9 = np.concatenate([cmd_q, q[7:]])
        applied = apply_policy_joint_targets_coordinated(self, arm_q9, self._policy_gripper)
        if applied:
            half = self._last_gripper_width / 2.0
            self._last_q9 = np.array(list(cmd_q) + [half, half], dtype=np.float64)
        return applied

    def move_to_joint_pose(self, numbers: list[float]) -> list[float]:
        """Cubic joint trajectory via the motion server (used by final-pose offset move)."""
        payload = self._post({"moveToJointPose": numbers})
        result = payload.get("moveToJointPose")
        if not isinstance(result, list):
            raise RuntimeError(f"moveToJointPose failed: {payload}")
        return [float(x) for x in result]

    def stop_policy_stream(self) -> None:
        self._post({"stopPolicyStream": []})
        self._policy_gripper = PolicyGripperTracker()

    def get_policy_stream_status(self) -> dict[str, Any]:
        payload = self._post({"getPolicyStreamStatus": []})
        raw = payload.get("getPolicyStreamStatus")
        if not isinstance(raw, str):
            raise RuntimeError(f"getPolicyStreamStatus failed: {payload}")
        return json.loads(raw)

    def clear_policy_fault(self) -> None:
        self._post({"clearPolicyFault": []})

    def recover_policy_stream(self) -> None:
        payload = self._post({"recoverPolicyStream": []})
        result = payload.get("recoverPolicyStream")
        if result != "ok":
            raise RuntimeError(f"recoverPolicyStream failed: {payload}")
        self._policy_gripper = PolicyGripperTracker()

    def tip_clearance_z(self, q7: np.ndarray) -> float:
        """Fingertip height (m) via libfranka FK (motion_server ``fkClearance``)."""
        from motion_server_action_offset import (
            DEFAULT_GRIPPER_TIP_OFFSET_M,
            effective_ee_tip_z,
        )

        q = np.asarray(q7, dtype=np.float64).reshape(7)
        payload_in = list(q.tolist()) + [DEFAULT_GRIPPER_TIP_OFFSET_M]
        try:
            result = self._post({"fkClearance": payload_in})
            tip_z = result.get("fkClearance")
            if isinstance(tip_z, list) and len(tip_z) >= 2:
                return float(tip_z[1])
        except RuntimeError:
            pass
        return effective_ee_tip_z(q, gripper_tip_offset_m=DEFAULT_GRIPPER_TIP_OFFSET_M)
