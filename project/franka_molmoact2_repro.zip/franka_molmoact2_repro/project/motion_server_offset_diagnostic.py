# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""FK preview for MolmoAct2 action fine-tuning offsets (diagnostic / web UI)."""

from __future__ import annotations

from typing import Any

import numpy as np

from motion_server_action_offset import (
    DEFAULT_OFFSET_REFERENCE,
    OFFSET_REFERENCE_FLANGE_BASE,
    DEFAULT_GRIPPER_TIP_OFFSET_M,
    apply_cartesian_offset_to_joints,
    flange_frame_vector_to_base,
    fk_ee_position,
    fk_tip_position,
    parse_offset_reference,
    parse_offset_xyz,
)

# DROID / Isaac Sim default ready pose (7 arm joints, rad).
DROID_READY_JOINTS: tuple[float, ...] = (0.0, -1.3, 0.0, -2.87, 0.0, 2.0, 0.75)

KNOWN_POSES: dict[str, tuple[float, ...]] = {
    "droid_ready": DROID_READY_JOINTS,
}


def _vec3(arr: np.ndarray) -> list[float]:
    return [float(x) for x in np.asarray(arr, dtype=np.float64).reshape(3)]


def compute_offset_preview(
    joints7: list[float] | tuple[float, ...],
    *,
    offset_x: float | None = None,
    offset_y: float | None = None,
    offset_z: float | None = None,
    offset_reference: str | None = DEFAULT_OFFSET_REFERENCE,
    gripper_tip_offset_m: float = DEFAULT_GRIPPER_TIP_OFFSET_M,
    pose_name: str = "custom",
) -> dict[str, Any]:
    """Predict flange/tip motion after applying MolmoAct2 action offsets."""
    q = np.asarray(joints7, dtype=np.float64).reshape(7)
    ox, oy, oz = parse_offset_xyz(offset_x, offset_y, offset_z)
    reference = parse_offset_reference(offset_reference)
    offset = np.array([ox, oy, oz], dtype=np.float64)
    tip_m = max(0.0, float(gripper_tip_offset_m))

    flange_before = fk_ee_position(q)
    tip_before = fk_tip_position(q, gripper_tip_offset_m=tip_m)

    if np.allclose(offset, 0.0):
        q_adj = q.copy()
    else:
        q_adj = apply_cartesian_offset_to_joints(
            q,
            offset,
            gripper_tip_offset_m=tip_m,
            offset_reference=reference,
        )

    flange_after = fk_ee_position(q_adj)
    tip_after = fk_tip_position(q_adj, gripper_tip_offset_m=tip_m)
    flange_delta = flange_after - flange_before
    tip_delta = tip_after - tip_before

    return {
        "pose_name": pose_name,
        "source_joints": [float(v) for v in q],
        "adjusted_joints": [float(v) for v in q_adj],
        "offset_xyz": [ox, oy, oz],
    "offset_reference": reference,
        "gripper_tip_offset_m": tip_m,
        "before": {
            "flange_xyz": _vec3(flange_before),
            "tip_xyz": _vec3(tip_before),
        },
        "after": {
            "flange_xyz": _vec3(flange_after),
            "tip_xyz": _vec3(tip_after),
        },
        "delta": {
            "flange_xyz": _vec3(flange_delta),
            "tip_xyz": _vec3(tip_delta),
        },
        "notes": {
            "offset_frame": (
                "base (XYZ applied to flange position)"
                if reference == OFFSET_REFERENCE_FLANGE_BASE
                else "flange (gripper XYZ; +Z along fingers, applied to fingertip)"
            ),
            "offset_base_xyz": _vec3(offset if reference == OFFSET_REFERENCE_FLANGE_BASE else flange_frame_vector_to_base(q, offset)),
        },
    }


def compute_pose_offset_preview(
    pose_name: str,
    *,
    offset_x: float | None = None,
    offset_y: float | None = None,
    offset_z: float | None = None,
    offset_reference: str | None = DEFAULT_OFFSET_REFERENCE,
    gripper_tip_offset_m: float = DEFAULT_GRIPPER_TIP_OFFSET_M,
) -> dict[str, Any]:
    key = pose_name.strip().lower()
    if key not in KNOWN_POSES:
        raise ValueError(f"Unknown pose {pose_name!r}; use one of: {', '.join(KNOWN_POSES)}")
    return compute_offset_preview(
        KNOWN_POSES[key],
        offset_x=offset_x,
        offset_y=offset_y,
        offset_z=offset_z,
        offset_reference=offset_reference,
        gripper_tip_offset_m=gripper_tip_offset_m,
        pose_name=key,
    )
