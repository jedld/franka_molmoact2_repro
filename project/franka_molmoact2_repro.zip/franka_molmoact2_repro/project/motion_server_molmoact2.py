# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""MolmoAct2-DROID inference loop for the Isaac Sim motion server.

Mirrors the control pattern in molmoact2_droid_remote_client.py: capture cameras +
joint state at 15 Hz, POST to the MolmoAct2 HTTP API (see start_molmoact2_3090.md),
apply absolute joint targets from the returned action chunk.

Endpoints:
  - single exterior → POST /act on port 8012
  - dual / duplicate exterior → POST /act_dual on port 8101 (MOLMOACT2_DUAL_EXTERIOR=1)
"""

from __future__ import annotations

import base64
import json
import threading
import time
from dataclasses import dataclass
from typing import Any, Protocol

import numpy as np
from numpy.lib.format import descr_to_dtype, dtype_to_descr

from motion_server_camera_common import (
    DEFAULT_WRIST_PAN_X,
    DEFAULT_WRIST_PAN_Y,
    DEFAULT_WRIST_ZOOM,
    MOLMOACT2_POLICY_SHAPE,
    WristPerceptionConfig,
    apply_wrist_perception_tune,
    pack_policy_images,
    parse_wrist_perception_config,
    prepare_molmoact2_image,
)
from motion_server_action_offset import (
    DEFAULT_ACTION_OFFSET_XYZ,
    DEFAULT_EE_FLOOR_ENABLED,
    DEFAULT_EE_FLOOR_Z_M,
    DEFAULT_FINAL_OFFSET_MOVE_TIME_S,
    DEFAULT_GRIPPER_TIP_OFFSET_M,
    DEFAULT_OFFSET_MODE,
    DEFAULT_OFFSET_REFERENCE,
    OFFSET_MODE_FINAL,
    VALID_OFFSET_MODES,
    apply_cartesian_offset_to_joints,
    clip_joints_to_ee_floor,
    effective_ee_tip_z,
    parse_offset_reference,
)
from motion_server_droid_units import (
    actions8_to_q9,
    droid_gripper_to_width_m,
    q9_width_m,
    state8_from_q9,
)
from motion_server_grasp import (
    DEFAULT_GRASP_ADVANCE_M,
    DEFAULT_GRASP_FORWARD_TIME_S,
    DEFAULT_GRASP_RETRACT_TIME_S,
    run_grasp_sequence,
    tool_axis_from_euler,
)
from motion_server_molmoact2_debug import MolmoAct2DebugRecorder
from motion_server_policy_gripper import (
    desired_closed_from_q9,
    droid_gripper_is_closed_command,
    physical_gripper_is_closed,
    physical_gripper_is_settled,
    reset_policy_gripper_tracker,
)
from motion_server_timing_log import log_event, log_slow

try:
    from motion_server_cpp_proxy import is_collision_recovery_error
except ImportError:  # pragma: no cover - Isaac-only installs without hardware proxy

    def is_collision_recovery_error(message: str) -> bool:
        return "collision_recovery:" in message and "collision_recovery_failed:" not in message


def _is_unsupported_policy_recover_error(message: str) -> bool:
    msg = str(message).lower()
    return "recoverpolicystream" in msg and "invalid command" in msg


def _is_recoverable_motion_disconnect_error(message: str) -> bool:
    """True when transport drops during streaming likely indicate recoverable contact/fault."""
    msg = str(message).lower()
    return (
        "remote end closed connection without response" in msg
        or "remotedisconnected" in msg
        or "connection reset by peer" in msg
        or "broken pipe" in msg
    )


def _is_transient_motion_transport_error(message: str) -> bool:
    """True when motion server transport is temporarily unavailable and retry should continue."""
    msg = str(message).lower()
    return (
        "connection refused" in msg
        or "timed out" in msg
        or "timeout" in msg
        or "temporary failure" in msg
        or "name or service not known" in msg
        or "network is unreachable" in msg
        or "connection reset by peer" in msg
        or "remote end closed connection" in msg
        or "broken pipe" in msg
        or "urlopen error" in msg
    )

DEFAULT_MOLMOACT2_URL = "http://localhost:8101"


class PolicyRobotBackend(Protocol):
    def get_joint_positions_q9(self) -> np.ndarray: ...

    def apply_policy_joint_targets(
        self, q9: np.ndarray, current_q9: np.ndarray | None = None
    ) -> bool: ...


class PolicyCameraBackend(Protocol):
    def observations_ready(self, external_slot: str = "external_1", external_camera_mode: str = "single") -> bool: ...

    def get_rgb(self, camera_id: str) -> np.ndarray | None: ...

    def capture_policy_observation(
        self, external_slot: str = "external_1", external_camera_mode: str = "single"
    ) -> tuple[np.ndarray | None, np.ndarray | None, np.ndarray | None] | None: ...


DEFAULT_MOLMOACT2_DUAL_URL = "http://localhost:8101"
INFERENCE_TIMEOUT_S = 120.0
# Transient inference failures (request timeouts, dropped connections, HTTP 5xx) are
# retried inside query_molmoact2 with linear backoff before the error surfaces. HTTP 4xx
# is treated as fatal since it will not succeed on resend.
INFERENCE_RETRIES = 2
INFERENCE_RETRY_BACKOFF_S = 0.75
HEALTH_TIMEOUT_S = 5.0
HEALTH_RETRIES = 2
HEALTH_RETRY_BACKOFF_S = 0.5
# How many consecutive failed fetches the control loop tolerates before it stops. Below
# this threshold the arm simply holds its last commanded target and the loop retries on
# the next tick, so a brief inference hiccup no longer aborts the run.
MAX_CONSECUTIVE_FETCH_FAILURES = 5
# Cooldown (s) after a failed fetch before the loop is allowed to start another one. Without
# this the 15 Hz control loop would re-fire inference immediately on every tick and burn
# through MAX_CONSECUTIVE_FETCH_FAILURES (and hammer the GPU server) in well under a second.
FETCH_FAILURE_COOLDOWN_S = 1.0
CONTROL_HZ = 15.0
DEFAULT_CHUNK_HORIZON = 15
MIN_CHUNK_HORIZON = 1
MAX_CHUNK_HORIZON = 32

# Grasp integration: the DROID policy was trained on a Robotiq 2F-85 whose binary close
# grabs differently than a stock Franka Hand. When the chunk's gripper command transitions
# open -> close, the closing action is replaced with the poke-and-grab macro: drive to the
# pose the policy would have closed at, advance the fingertip along the real tool axis by
# GRASP_INTEGRATION_DEFAULT_ADVANCE_M, force-grasp, snap back to that pose, truncate the rest
# of the chunk, then re-observe + re-infer.
GRASP_INTEGRATION_DEFAULT_ADVANCE_M = DEFAULT_GRASP_ADVANCE_M
GRASP_INTEGRATION_FORWARD_TIME_S = DEFAULT_GRASP_FORWARD_TIME_S
GRASP_INTEGRATION_RETRACT_TIME_S = DEFAULT_GRASP_RETRACT_TIME_S
# Time (s) for the final approach move onto the policy's close pose before poking forward.
GRASP_INTEGRATION_APPROACH_TIME_S = 1.0
MAX_GRASP_INTEGRATION_ADVANCE_M = 0.2
# Height gate (m, base-frame fingertip Z): the poke-and-grab macro only replaces an open->close
# transition when the tip is at/below this height (i.e. near the table / grasp region). Above it,
# open->close transitions keep the pure policy close so transit moves are not hijacked.
DEFAULT_GRASP_INTEGRATION_MAX_Z_M = 0.12

# Execution modes.
#   async (default): open-loop chunk — observe, infer, execute the full chunk (up to
#                    chunk_horizon) with arm+gripper settle between steps, then observe + infer
#                    again. No overlapping inference.
#   sync:            horizon-1 closed loop — capture one observation, run inference, apply ONLY
#                    the first action of the chunk, wait for the arm AND gripper to reach it, then
#                    observe + infer again. Nothing runs in parallel; the rest of the chunk is
#                    discarded.
#   auto:            height-gated hybrid — open-loop async while the gripper tip is high, switch to
#                    step-by-step (sync) once the tip descends at/below ``sync_below_z`` (e.g. near
#                    the table / grasp region where precision matters), then back to async on lift.
EXECUTION_MODE_ASYNC = "async"
EXECUTION_MODE_SYNC = "sync"
EXECUTION_MODE_AUTO = "auto"
VALID_EXECUTION_MODES = (EXECUTION_MODE_ASYNC, EXECUTION_MODE_SYNC, EXECUTION_MODE_AUTO)
DEFAULT_EXECUTION_MODE = EXECUTION_MODE_ASYNC
# auto mode: gripper-tip base-frame Z (m) at/below which the loop runs step-by-step (sync).
DEFAULT_SYNC_BELOW_Z_M = 0.15
# Hysteresis band (m) so the loop does not thrash between async/sync right at the threshold:
# once in sync it stays sync until the tip rises this far above ``sync_below_z``.
AUTO_MODE_Z_HYSTERESIS_M = 0.02
# Sync/async step settle tolerances: a step is "done" once every arm joint is within this many
# radians of the commanded target and the gripper matches the binarized open/closed target.
SYNC_JOINT_SETTLE_TOL_RAD = 0.02
# Safety cap so a step that can never settle (e.g. the gripper stalls on a grasped object whose
# width never reaches the commanded target) still advances and re-observes instead of hanging.
SYNC_STEP_TIMEOUT_S = 5.0
# After a Franka reflex/contact during policy streaming, wait this long before restarting
# the libfranka velocity servo so the arm can finish automaticErrorRecovery and settle.
COLLISION_BACKOFF_S = 2.5
# After collision recovery, automatically continue inference from a fresh observation.
COLLISION_AUTO_RESUME = True
# Small retreat opposite the current tool axis to de-embed from touched geometry.
COLLISION_BACKOUT_DISTANCE_M = 0.03
COLLISION_BACKOUT_TIME_S = 0.8
# Retry delay for transient recoverPolicyStream transport failures (e.g., connection refused
# while motion_server is restarting after contact).
COLLISION_RECOVERY_RETRY_BACKOFF_S = 1.5
# If a commanded async step remains above this arm-joint error and shows no meaningful
# improvement for a sustained number of policy ticks, treat it as likely contact/stall and
# trigger collision recovery/backoff instead of waiting the full timeout.
ASYNC_STALL_ERR_RAD = 0.03
ASYNC_STALL_IMPROVEMENT_EPS_RAD = 0.001
ASYNC_STALL_TICKS = 8

# MolmoAct2-DROID training / HF model card camera order:
#   [exterior_1, exterior_2, wrist]
# HTTP API field mapping (start_molmoact2_3090.md):
#   external_cam     ← sim external_1 (left ZED 2)
#   external_cam_2   ← sim external_2 (front ZED 2)
#   wrist_cam        ← sim wrist (RealSense D435)
# Single /act uses one exterior in external_cam + wrist_cam (2-view path).
# Duplicate /act_dual sends [ext, ext, wrist] per HF workaround.

TASK_INSTRUCTIONS: dict[str, str] = {
    "apple_on_plate": "Pick up the apple and place it on the plate",
    "pipette_in_tray": "Place the pipette in the tray",
    "red_cube_in_tape_roll": "Place the red cube in the center of the tape roll",
    "knife_in_box": "Put the knife in the box",
    "objects_in_bowl": "Move the objects into the bowl",
}

# Named configure presets (Fix 12). Applied before any explicit kwargs so callers can still
# override individual fields in the same request. ``ee_floor`` is intentionally left untouched so
# an operator's calibrated floor survives a preset switch.
MOLMOACT2_PRESETS: dict[str, dict[str, Any]] = {
    # Hardware static pick-and-place baseline: tight feedback near contact, no macro hijack.
    "hardware_pnp": {
        "execution_mode": EXECUTION_MODE_AUTO,
        "chunk_horizon": 4,
        "grasp_integration_enabled": False,
    },
}


def _numpy_json_default(obj: Any) -> Any:
    """json-numpy compatible encoder (Crimson-Crow/json-numpy format)."""
    if isinstance(obj, np.ndarray):
        arr = np.ascontiguousarray(obj)
        return {
            "__numpy__": base64.b64encode(arr.tobytes()).decode("ascii"),
            "dtype": dtype_to_descr(arr.dtype),
            "shape": list(arr.shape),
        }
    if isinstance(obj, np.generic):
        return obj.item()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def _numpy_json_object_hook(dct: dict[str, Any]) -> Any:
    if "__numpy__" in dct:
        buf = base64.b64decode(dct["__numpy__"])
        arr = np.frombuffer(buf, dtype=descr_to_dtype(dct["dtype"]))
        shape = dct.get("shape")
        return arr.reshape(shape) if shape else arr[0]
    return dct


def _json_dumps(payload: dict[str, Any]) -> bytes:
    try:
        import json_numpy

        json_numpy.patch()
        return json_numpy.dumps(payload).encode("utf-8")
    except ImportError:
        return json.dumps(payload, default=_numpy_json_default).encode("utf-8")


def _json_loads(data: bytes) -> dict[str, Any]:
    try:
        import json_numpy

        json_numpy.patch()
        return json_numpy.loads(data)
    except ImportError:
        return json.loads(data.decode("utf-8"), object_hook=_numpy_json_object_hook)


def prepare_molmoact2_state(state8: np.ndarray) -> np.ndarray:
    """Normalize robot state to ``(8,) float32`` C-contiguous per API spec."""
    return np.ascontiguousarray(np.asarray(state8, dtype=np.float32).reshape(8))


def _prepare_payload_image(image: np.ndarray) -> np.ndarray:
    """Policy image: strict ``(180, 320, 3) uint8`` RGB layout for json_numpy wire encoding."""
    return prepare_molmoact2_image(image, expected_shape=MOLMOACT2_POLICY_SHAPE)


def build_molmoact2_request(
    external_camera_mode: str,
    ext_rgb: np.ndarray,
    wrist_rgb: np.ndarray,
    state8: np.ndarray,
    instruction: str,
    ext2_rgb: np.ndarray | None = None,
    *,
    chunk_horizon: int = DEFAULT_CHUNK_HORIZON,
) -> tuple[str, dict[str, Any]]:
    """Build endpoint + payload per start_molmoact2_3090.md / molmoact2_server_droid.py.

    ``chunk_horizon`` is used only for client-side truncation after the response arrives;
    it is not sent to the inference server.

    Camera slot order must match MolmoAct2-DROID training:
      dual:       external_cam=external_1, external_cam_2=external_2, wrist_cam=wrist
      duplicate:  external_cam=external_cam_2=chosen exterior, wrist_cam=wrist
      single:     external_cam=chosen exterior, wrist_cam=wrist

    - ``single`` → ``POST /act`` with ``external_cam`` + ``wrist_cam`` (port 8012)
    - ``dual`` / ``duplicate`` → ``POST /act_dual`` with three image fields (port 8101)

    Image layout (all camera fields): ``(H, W, 3)`` = ``(180, 320, 3)`` ``uint8`` RGB, C-contiguous.
    """
    state8 = prepare_molmoact2_state(state8)
    wrist_rgb = _prepare_payload_image(wrist_rgb)

    if external_camera_mode == "dual":
        if ext2_rgb is None:
            raise ValueError("dual mode requires external_cam and external_cam_2")
        payload = {
            "external_cam": _prepare_payload_image(ext_rgb),
            "external_cam_2": _prepare_payload_image(ext2_rgb),
            "wrist_cam": wrist_rgb,
            "instruction": instruction,
            "state": state8,
        }
        return "/act_dual", payload

    if external_camera_mode == "duplicate":
        ext = _prepare_payload_image(ext_rgb)
        payload = {
            "external_cam": ext,
            "external_cam_2": np.ascontiguousarray(ext),
            "wrist_cam": wrist_rgb,
            "instruction": instruction,
            "state": state8,
        }
        return "/act_dual", payload

    payload = {
        "external_cam": _prepare_payload_image(ext_rgb),
        "wrist_cam": wrist_rgb,
        "instruction": instruction,
        "state": state8,
    }
    return "/act", payload


def query_molmoact2(
    url: str,
    endpoint: str,
    payload: dict[str, Any],
    timeout: float = INFERENCE_TIMEOUT_S,
    retries: int = INFERENCE_RETRIES,
    backoff_s: float = INFERENCE_RETRY_BACKOFF_S,
) -> tuple[np.ndarray, float | None]:
    """POST json_numpy payload to MolmoAct2; returns ((N, 8) actions, dt_ms).

    Transient failures — request timeouts, dropped/refused connections, and HTTP 5xx
    from the GPU server — are retried up to ``retries`` times with linear backoff.
    HTTP 4xx (client) errors fail immediately because they will not succeed on resend.
    """
    import socket
    import urllib.error
    import urllib.request

    body = _json_dumps(payload)
    target = f"{url.rstrip('/')}{endpoint}"
    attempts = max(1, retries + 1)
    last_exc: RuntimeError | None = None

    for attempt in range(attempts):
        req = urllib.request.Request(
            target,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                out = _json_loads(resp.read())
            if "actions" not in out:
                raise RuntimeError(
                    f"MolmoAct2 {endpoint} response missing 'actions' key: keys={list(out)[:8]}"
                )
            actions = np.asarray(out["actions"], dtype=np.float32)
            if actions.ndim == 1:
                actions = actions[None, :]
            if actions.ndim != 2 or actions.shape[1] < 8:
                raise RuntimeError(
                    f"MolmoAct2 {endpoint} returned unexpected action shape {actions.shape}; "
                    "expected (N, 8) [7 joint targets + gripper]"
                )
            dt_ms = out.get("dt_ms")
            return actions, None if dt_ms is None else float(dt_ms)
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            last_exc = RuntimeError(f"MolmoAct2 {endpoint} HTTP {exc.code}: {detail}")
            if exc.code < 500:
                raise last_exc from exc
        except (urllib.error.URLError, socket.timeout, TimeoutError) as exc:
            reason = getattr(exc, "reason", exc)
            last_exc = RuntimeError(f"MolmoAct2 {endpoint} unreachable: {reason}")

        if attempt + 1 < attempts:
            time.sleep(backoff_s * (attempt + 1))

    raise last_exc if last_exc is not None else RuntimeError(f"MolmoAct2 {endpoint} failed")


def query_molmoact2_observation(
    url: str,
    external_camera_mode: str,
    ext_rgb: np.ndarray,
    wrist_rgb: np.ndarray,
    state8: np.ndarray,
    instruction: str,
    ext2_rgb: np.ndarray | None = None,
    timeout: float = INFERENCE_TIMEOUT_S,
) -> tuple[np.ndarray, float | None, str]:
    """Build request from observation tensors and POST to the correct inference endpoint."""
    endpoint, payload = build_molmoact2_request(
        external_camera_mode, ext_rgb, wrist_rgb, state8, instruction, ext2_rgb=ext2_rgb
    )
    actions, dt_ms = query_molmoact2(url, endpoint, payload, timeout=timeout)
    return actions, dt_ms, endpoint


def check_molmoact2_health(
    url: str,
    timeout: float = HEALTH_TIMEOUT_S,
    retries: int = HEALTH_RETRIES,
    backoff_s: float = HEALTH_RETRY_BACKOFF_S,
) -> dict[str, Any]:
    """GET /healthz — expect ``{"status": "ok"}`` per start_molmoact2_3090.md.

    Retries transient timeouts/connection errors so a momentary blip (e.g. the GPU
    server still finishing warmup) does not report the server as unhealthy.
    """
    import urllib.error
    import urllib.request

    health_url = f"{url.rstrip('/')}/healthz"
    attempts = max(1, retries + 1)
    result: dict[str, Any] = {"ok": False, "status": 0, "body": ""}

    for attempt in range(attempts):
        try:
            with urllib.request.urlopen(health_url, timeout=timeout) as resp:
                body = resp.read().decode("utf-8", errors="replace")
                ok = False
                if resp.status == 200:
                    try:
                        ok = json.loads(body).get("status") == "ok"
                    except json.JSONDecodeError:
                        ok = False
                result = {"ok": ok, "status": resp.status, "body": body}
        except urllib.error.HTTPError as exc:
            result = {"ok": False, "status": exc.code, "body": exc.read().decode("utf-8", errors="replace")}
        except Exception as exc:
            result = {"ok": False, "status": 0, "body": str(exc)}

        if result["ok"]:
            return result
        if attempt + 1 < attempts:
            time.sleep(backoff_s * (attempt + 1))

    return result


@dataclass
class MolmoAct2Status:
    running: bool = False
    server_url: str = DEFAULT_MOLMOACT2_URL
    instruction: str = ""
    external_slot: str = "external_1"
    external_camera_mode: str = "single"
    execution_mode: str = DEFAULT_EXECUTION_MODE
    sync_below_z: float = DEFAULT_SYNC_BELOW_Z_M
    auto_active_mode: str = ""
    control_hz: float = CONTROL_HZ
    chunk_horizon: int = DEFAULT_CHUNK_HORIZON
    action_idx: int = 0
    chunk_size: int = 0
    chunks_fetched: int = 0
    steps_applied: int = 0
    fetching: bool = False
    last_error: str = ""
    paused_contact: bool = False
    recoverable: bool = False
    collision_backoff_remaining_s: float = 0.0
    consecutive_fetch_failures: int = 0
    last_endpoint: str = ""
    last_dt_ms: float | None = None
    last_fetch_s: float | None = None
    inference_healthy: bool | None = None
    inference_health_body: str = ""
    debug_mode: bool = False
    debug_session_dir: str = ""
    debug_chunks_logged: int = 0
    debug_last_chunk_dir: str = ""
    debug_recent: list[dict[str, Any]] | None = None
    offset_x: float = DEFAULT_ACTION_OFFSET_XYZ[0]
    offset_y: float = DEFAULT_ACTION_OFFSET_XYZ[1]
    offset_z: float = DEFAULT_ACTION_OFFSET_XYZ[2]
    offset_mode: str = DEFAULT_OFFSET_MODE
    offset_reference: str = DEFAULT_OFFSET_REFERENCE
    offset_final_moves: int = 0
    ee_floor_enabled: bool = DEFAULT_EE_FLOOR_ENABLED
    ee_floor_z: float = DEFAULT_EE_FLOOR_Z_M
    gripper_tip_offset_m: float = DEFAULT_GRIPPER_TIP_OFFSET_M
    ee_floor_clips: int = 0
    ee_floor_last_tip_z: float | None = None
    grasp_integration_enabled: bool = False
    grasp_integration_max_z: float = DEFAULT_GRASP_INTEGRATION_MAX_Z_M
    grasp_advance_m: float = GRASP_INTEGRATION_DEFAULT_ADVANCE_M
    grasp_sequences: int = 0
    # Observation/tracking freshness diagnostics (Fix 11). Updated per inference / settle.
    last_obs_frame_age_ms: float | None = None
    last_obs_state_skew_ms: float | None = None
    last_max_joint_tracking_err_rad: float | None = None
    wrist_pan_x: float = DEFAULT_WRIST_PAN_X
    wrist_pan_y: float = DEFAULT_WRIST_PAN_Y
    wrist_zoom: float = DEFAULT_WRIST_ZOOM


class MolmoAct2Controller:
    """Runs MolmoAct2 policy inference on the Isaac Sim main loop thread."""

    def __init__(
        self,
        handler: PolicyRobotBackend,
        camera_manager: PolicyCameraBackend,
    ) -> None:
        self._handler = handler
        self._cameras = camera_manager
        self._lock = threading.Lock()
        self._status = MolmoAct2Status()
        self._action_chunk: np.ndarray | None = None
        self._action_idx = 0
        # Index within the loaded chunk where the gripper command transitions open -> close; the
        # close action is replaced by the poke-and-grab macro and the rest of the chunk truncated.
        self._grasp_at_idx: int | None = None
        self._control_accum = 0.0
        self._fetch_thread: threading.Thread | None = None
        self._fetch_worker_active = False
        self._fetch_seq = 0
        self._fetch_error: str | None = None
        # Monotonic time before which no new fetch may start (set after a transient failure).
        self._fetch_cooldown_until = 0.0
        self._pending_chunk: np.ndarray | None = None
        self._pending_dt_ms: float | None = None
        # Monotonic count of applied control steps.
        self._exec_step = 0
        # Sync (step-by-step) execution state: the in-flight single-step target and whether we
        # are currently waiting for the arm + gripper to reach it.
        self._sync_awaiting_settle = False
        self._sync_target_q9: np.ndarray | None = None
        self._sync_settle_deadline = 0.0
        # Async open-loop: wait for arm+gripper settle after each chunk step before advancing.
        self._async_awaiting_settle = False
        self._async_target_q9: np.ndarray | None = None
        self._async_settle_deadline = 0.0
        self._async_stall_ticks = 0
        self._async_stall_best_err = float("inf")
        # True once a poke-and-grab grasp has closed on an object. A force-grasped object holds
        # the jaws apart by its own width, so a large object (> ~4 cm) reads as "not closed" by
        # jaw width alone; without this latch the grasp-edge detector would see a spurious
        # open->close edge on the next chunk and re-run the macro, whose approach re-opens the
        # gripper and DROPS the held object (small objects close past 4 cm so never tripped this).
        # Cleared once the jaws are observed fully open again (object released).
        self._grasp_holding = False
        # auto mode: the sub-mode currently in effect, with Z-hysteresis to avoid thrashing.
        self._auto_mode_state = EXECUTION_MODE_ASYNC
        # Effective mode driving the current tick (async/sync); equals execution_mode unless auto.
        self._effective_execution_mode = EXECUTION_MODE_ASYNC
        self._health_thread: threading.Thread | None = None
        self._debug = MolmoAct2DebugRecorder()
        self._diag_cam_wait_ticks = 0
        self._diag_gripper_wait_ticks = 0
        self._diag_await_chunk_ticks = 0
        self._diag_async_settle_ticks = 0
        self._diag_last_policy_close_cmd: bool | None = None
        self._collision_recovery_pending = False
        self._collision_recovery_attempted = False
        self._collision_recovery_until = 0.0
        self._collision_recovery_message = ""
        self._collision_recovery_retry_count = 0
        self._sync_wrist_perception_tuner()

    def _wrist_perception_config(self) -> WristPerceptionConfig:
        with self._lock:
            return WristPerceptionConfig(
                pan_x=self._status.wrist_pan_x,
                pan_y=self._status.wrist_pan_y,
                zoom=self._status.wrist_zoom,
            )

    def tune_wrist_rgb(self, rgb: np.ndarray) -> np.ndarray:
        """Apply live wrist crop/zoom for policy input and web preview."""
        return apply_wrist_perception_tune(rgb, self._wrist_perception_config())

    def _sync_wrist_perception_tuner(self) -> None:
        sync = getattr(self._cameras, "set_wrist_perception_tuner", None)
        if callable(sync):
            sync(self.tune_wrist_rgb)

    def _chunk_has_remaining_steps(self) -> bool:
        chunk = self._action_chunk
        if chunk is None or len(chunk) == 0:
            return False
        return self._action_idx < len(chunk)

    def _inference_in_flight(self) -> bool:
        if self._fetch_worker_active:
            return True
        thread = self._fetch_thread
        return thread is not None and thread.is_alive()

    @property
    def is_running(self) -> bool:
        with self._lock:
            return self._status.running

    def configure(
        self,
        *,
        preset: str | None = None,
        server_url: str | None = None,
        instruction: str | None = None,
        external_slot: str | None = None,
        external_camera_mode: str | None = None,
        execution_mode: str | None = None,
        sync_below_z: float | None = None,
        chunk_horizon: int | None = None,
        debug_mode: bool | None = None,
        offset_x: float | None = None,
        offset_y: float | None = None,
        offset_z: float | None = None,
        offset_mode: str | None = None,
    offset_reference: str | None = None,
        reset_offsets: bool = False,
        ee_floor_enabled: bool | None = None,
        ee_floor_z: float | None = None,
        gripper_tip_offset_m: float | None = None,
        reset_ee_floor: bool = False,
        grasp_integration_enabled: bool | None = None,
        grasp_advance_m: float | None = None,
        grasp_integration_max_z: float | None = None,
        wrist_pan_x: float | None = None,
        wrist_pan_y: float | None = None,
        wrist_zoom: float | None = None,
        reset_wrist_perception: bool = False,
    ) -> MolmoAct2Status:
        with self._lock:
            if preset is not None:
                key = str(preset).strip().lower()
                if key not in MOLMOACT2_PRESETS:
                    raise ValueError(
                        f"preset must be one of {tuple(MOLMOACT2_PRESETS)}"
                    )
                # Preset fields are applied first; explicit kwargs below still override them.
                for field_name, value in MOLMOACT2_PRESETS[key].items():
                    setattr(self._status, field_name, value)
            if server_url is not None:
                self._status.server_url = server_url.rstrip("/")
            if instruction is not None:
                self._status.instruction = instruction
            if external_slot is not None:
                if external_slot not in ("external_1", "external_2"):
                    raise ValueError("external_slot must be external_1 or external_2")
                self._status.external_slot = external_slot
            if external_camera_mode is not None:
                if external_camera_mode not in ("single", "dual", "duplicate"):
                    raise ValueError("external_camera_mode must be single, dual, or duplicate")
                self._status.external_camera_mode = external_camera_mode
            if execution_mode is not None:
                mode = str(execution_mode).strip().lower()
                if mode not in VALID_EXECUTION_MODES:
                    raise ValueError(f"execution_mode must be one of {VALID_EXECUTION_MODES}")
                self._status.execution_mode = mode
            if sync_below_z is not None:
                self._status.sync_below_z = float(sync_below_z)
            if chunk_horizon is not None:
                h = int(chunk_horizon)
                if h < MIN_CHUNK_HORIZON or h > MAX_CHUNK_HORIZON:
                    raise ValueError(
                        f"chunk_horizon must be between {MIN_CHUNK_HORIZON} and {MAX_CHUNK_HORIZON}"
                    )
                self._status.chunk_horizon = h
            if debug_mode is not None:
                self._status.debug_mode = bool(debug_mode)
            if reset_offsets:
                self._status.offset_x, self._status.offset_y, self._status.offset_z = DEFAULT_ACTION_OFFSET_XYZ
                self._status.offset_mode = DEFAULT_OFFSET_MODE
                self._status.offset_reference = DEFAULT_OFFSET_REFERENCE
            else:
                if offset_x is not None:
                    self._status.offset_x = float(offset_x)
                if offset_y is not None:
                    self._status.offset_y = float(offset_y)
                if offset_z is not None:
                    self._status.offset_z = float(offset_z)
                if offset_mode is not None:
                    mode = str(offset_mode).strip().lower()
                    if mode not in VALID_OFFSET_MODES:
                        raise ValueError(
                            f"offset_mode must be one of {VALID_OFFSET_MODES}"
                        )
                    self._status.offset_mode = mode
                if offset_reference is not None:
                    self._status.offset_reference = parse_offset_reference(offset_reference)
            if reset_ee_floor:
                self._status.ee_floor_enabled = DEFAULT_EE_FLOOR_ENABLED
                self._status.ee_floor_z = DEFAULT_EE_FLOOR_Z_M
                self._status.gripper_tip_offset_m = DEFAULT_GRIPPER_TIP_OFFSET_M
                self._status.ee_floor_clips = 0
            else:
                if ee_floor_enabled is not None:
                    self._status.ee_floor_enabled = bool(ee_floor_enabled)
                if ee_floor_z is not None:
                    self._status.ee_floor_z = float(ee_floor_z)
                if gripper_tip_offset_m is not None:
                    self._status.gripper_tip_offset_m = max(0.0, float(gripper_tip_offset_m))
            if grasp_integration_enabled is not None:
                self._status.grasp_integration_enabled = bool(grasp_integration_enabled)
            if grasp_advance_m is not None:
                self._status.grasp_advance_m = float(
                    min(MAX_GRASP_INTEGRATION_ADVANCE_M, max(0.0, float(grasp_advance_m)))
                )
            if grasp_integration_max_z is not None:
                self._status.grasp_integration_max_z = float(grasp_integration_max_z)
            if reset_wrist_perception:
                self._status.wrist_pan_x = DEFAULT_WRIST_PAN_X
                self._status.wrist_pan_y = DEFAULT_WRIST_PAN_Y
                self._status.wrist_zoom = DEFAULT_WRIST_ZOOM
            else:
                wrist_cfg = parse_wrist_perception_config(
                    pan_x=wrist_pan_x if wrist_pan_x is not None else self._status.wrist_pan_x,
                    pan_y=wrist_pan_y if wrist_pan_y is not None else self._status.wrist_pan_y,
                    zoom=wrist_zoom if wrist_zoom is not None else self._status.wrist_zoom,
                )
                if wrist_pan_x is not None:
                    self._status.wrist_pan_x = wrist_cfg.pan_x
                if wrist_pan_y is not None:
                    self._status.wrist_pan_y = wrist_cfg.pan_y
                if wrist_zoom is not None:
                    self._status.wrist_zoom = wrist_cfg.zoom
            self._sync_debug_status()
            self._sync_handler_floor_config()
            self._sync_wrist_perception_tuner()
            return MolmoAct2Status(**vars(self._status))

    def _sync_handler_floor_config(self) -> None:
        """Push floor settings to hardware handler (caller must hold ``self._lock``)."""
        sync = getattr(self._handler, "set_ee_floor_config", None)
        if not callable(sync):
            return
        sync(
            self._status.ee_floor_enabled,
            self._status.ee_floor_z,
            self._status.gripper_tip_offset_m,
        )

    def _action_offset_xyz(self) -> np.ndarray:
        with self._lock:
            return np.array(
                [self._status.offset_x, self._status.offset_y, self._status.offset_z],
                dtype=np.float64,
            )

    def _apply_action_postprocess_to_q9(
        self, q9: np.ndarray, *, current_q9: np.ndarray | None = None
    ) -> np.ndarray:
        q = np.asarray(q9, dtype=np.float64).reshape(9).copy()
        offset = self._action_offset_xyz()
        with self._lock:
            offset_mode = self._status.offset_mode
            offset_reference = self._status.offset_reference
        # In "final" mode the live trajectory is left untouched; the offset is applied once to
        # the final pose in stop(). Only "continuous" mode shifts every commanded step here.
        if offset_mode != OFFSET_MODE_FINAL and not np.allclose(offset, 0.0):
            with self._lock:
                tip_offset = self._status.gripper_tip_offset_m
            q[:7] = apply_cartesian_offset_to_joints(
                q[:7],
                offset,
                gripper_tip_offset_m=tip_offset,
                offset_reference=offset_reference,
            )
        with self._lock:
            floor_enabled = self._status.ee_floor_enabled
            floor_z = self._status.ee_floor_z
            tip_offset = self._status.gripper_tip_offset_m
        # Hardware clips the rate-limited command from current q — skip model-target clip there.
        uses_handler_clips = callable(getattr(self._handler, "consume_ee_floor_clips", None))
        if floor_enabled and not uses_handler_clips:
            clearance_fn = getattr(self._handler, "tip_clearance_z", None)
            q_ref = None if current_q9 is None else np.asarray(current_q9, dtype=np.float64).reshape(9)[:7]
            q[:7], clipped = clip_joints_to_ee_floor(
                q[:7],
                floor_z,
                q_reference=q_ref,
                gripper_tip_offset_m=tip_offset,
                clearance_fn=clearance_fn if callable(clearance_fn) else None,
            )
            tip_z = (
                clearance_fn(q[:7])
                if callable(clearance_fn)
                else effective_ee_tip_z(q[:7], gripper_tip_offset_m=tip_offset)
            )
            with self._lock:
                self._status.ee_floor_last_tip_z = float(tip_z)
                if clipped:
                    self._status.ee_floor_clips += 1
            if clipped:
                log_event(
                    "molmoact2",
                    f"ee_floor clip (tip_z={float(tip_z):.4f} m floor={float(floor_z):.4f} m)",
                )
        elif floor_enabled and uses_handler_clips and current_q9 is not None:
            clearance_fn = getattr(self._handler, "tip_clearance_z", None)
            tip_z = (
                clearance_fn(q[:7])
                if callable(clearance_fn)
                else effective_ee_tip_z(q[:7], gripper_tip_offset_m=tip_offset)
            )
            with self._lock:
                self._status.ee_floor_last_tip_z = float(tip_z)
        return q

    def start(self) -> MolmoAct2Status:
        if self._fetch_thread is not None and self._fetch_thread.is_alive():
            self._fetch_thread.join(timeout=0.5)
        with self._lock:
            if not self._status.instruction.strip():
                raise RuntimeError("Instruction is empty.")
            self._status.running = True
            self._status.last_error = ""
            self._status.paused_contact = False
            self._status.recoverable = False
            self._status.collision_backoff_remaining_s = 0.0
            self._collision_recovery_pending = False
            self._collision_recovery_attempted = False
            self._collision_recovery_until = 0.0
            self._collision_recovery_message = ""
            self._action_chunk = None
            self._action_idx = 0
            self._grasp_at_idx = None
            self._control_accum = 0.0
            self._fetch_error = None
            self._fetch_cooldown_until = 0.0
            self._status.consecutive_fetch_failures = 0
            self._pending_chunk = None
            self._pending_dt_ms = None
            self._fetch_worker_active = False
            self._fetch_seq = 0
            self._exec_step = 0
            self._sync_awaiting_settle = False
            self._sync_target_q9 = None
            self._sync_settle_deadline = 0.0
            self._async_awaiting_settle = False
            self._async_target_q9 = None
            self._async_settle_deadline = 0.0
            self._async_stall_ticks = 0
            self._async_stall_best_err = float("inf")
            self._diag_last_policy_close_cmd = None
            self._grasp_holding = False
            self._auto_mode_state = EXECUTION_MODE_ASYNC
            self._effective_execution_mode = (
                EXECUTION_MODE_ASYNC
                if self._status.execution_mode == EXECUTION_MODE_AUTO
                else self._status.execution_mode
            )
            self._status.auto_active_mode = (
                EXECUTION_MODE_ASYNC if self._status.execution_mode == EXECUTION_MODE_AUTO else ""
            )
            self._status.chunks_fetched = 0
            self._status.steps_applied = 0
            self._status.last_endpoint = ""
            self._status.last_fetch_s = None
            self._status.last_dt_ms = None
            self._status.ee_floor_clips = 0
            self._status.offset_final_moves = 0
            consume_clips = getattr(self._handler, "consume_ee_floor_clips", None)
            if callable(consume_clips):
                consume_clips()
            self._sync_handler_floor_config()
            reset_policy_gripper_tracker(self._handler)
            if self._status.debug_mode:
                session_dir = self._debug.start_session(
                    instruction=self._status.instruction,
                    server_url=self._status.server_url,
                    external_camera_mode=self._status.external_camera_mode,
                    external_slot=self._status.external_slot,
                )
                print(f"[molmoact2 debug] session → {session_dir}")
            else:
                self._debug.clear_session()
            self._sync_debug_status()
            log_event(
                "molmoact2",
                "start → running "
                f"server={self._status.server_url} "
                f"mode={self._status.execution_mode} "
                f"horizon={self._status.chunk_horizon} "
                f"cameras={self._status.external_camera_mode}",
            )
            self._diag_cam_wait_ticks = 0
            self._diag_gripper_wait_ticks = 0
            self._diag_await_chunk_ticks = 0
            self._diag_async_settle_ticks = 0
        # Health is checked by the web UI before start; avoid a second blocking
        # round-trip here so the HTTP handler returns immediately.
        self.refresh_health(async_ok=True)
        return self.get_status()

    def stop(self) -> MolmoAct2Status:
        with self._lock:
            steps = self._status.steps_applied
            chunks = self._status.chunks_fetched
            self._status.running = False
            self._status.fetching = False
            self._status.paused_contact = False
            self._status.recoverable = False
            self._status.collision_backoff_remaining_s = 0.0
        self._collision_recovery_pending = False
        self._collision_recovery_attempted = False
        self._collision_recovery_until = 0.0
        self._collision_recovery_message = ""
        log_event("molmoact2", f"stop (steps_applied={steps} chunks_fetched={chunks})")
        if self._fetch_thread is not None and self._fetch_thread.is_alive():
            self._fetch_thread.join(timeout=1.0)
        with self._lock:
            self._fetch_worker_active = False
            self._pending_chunk = None
            self._pending_dt_ms = None
            self._action_chunk = None
            self._action_idx = 0
            self._grasp_at_idx = None
            self._diag_last_policy_close_cmd = None
        # Settle the policy stream first so the current pose we read for the final-offset move
        # comes from a stationary arm (libfranka readOnce) rather than a live servo target.
        stop_policy = getattr(self._handler, "stop_policy_stream", None)
        if callable(stop_policy):
            try:
                stop_policy()
            except Exception as exc:
                print(f"MolmoAct2 stop_policy_stream: {exc}")
        try:
            self._apply_final_offset_move()
        except Exception as exc:
            message = f"final offset move failed: {exc}"
            print(f"MolmoAct2 {message}")
            with self._lock:
                self._status.last_error = message
        return self.get_status()

    def resume_after_contact(self) -> MolmoAct2Status:
        """Resume inference after a recoverable contact pause (fresh observation)."""
        with self._lock:
            if not self._status.recoverable:
                raise RuntimeError("Not paused after contact.")
            if self._collision_recovery_pending:
                remaining = max(0.0, self._collision_recovery_until - time.monotonic())
                raise RuntimeError(
                    f"Still recovering from contact ({remaining:.1f}s backoff remaining)."
                )
        return self.start()

    def _poll_policy_fault(self) -> str | None:
        get_status = getattr(self._handler, "get_policy_stream_status", None)
        if not callable(get_status):
            return None
        try:
            status = get_status()
        except Exception:
            return None
        if status.get("fault"):
            return str(status.get("message") or "policy stream fault")
        return None

    def _discard_active_motion(self) -> None:
        if self._fetch_thread is not None and self._fetch_thread.is_alive():
            self._fetch_thread.join(timeout=0.5)
        with self._lock:
            self._fetch_worker_active = False
            self._pending_chunk = None
            self._pending_dt_ms = None
            self._action_chunk = None
            self._action_idx = 0
            self._grasp_at_idx = None
            self._status.fetching = False
        self._sync_awaiting_settle = False
        self._sync_target_q9 = None
        self._sync_settle_deadline = 0.0
        self._async_awaiting_settle = False
        self._async_target_q9 = None
        self._async_settle_deadline = 0.0
        self._async_stall_ticks = 0
        self._async_stall_best_err = float("inf")

    def _begin_collision_recovery(self, message: str) -> None:
        if self._collision_recovery_pending:
            return
        log_event("molmoact2", f"contact detected — pausing inference: {message}")
        self._discard_active_motion()
        stop_policy = getattr(self._handler, "stop_policy_stream", None)
        if callable(stop_policy):
            try:
                stop_policy()
            except Exception as exc:
                print(f"MolmoAct2 stop_policy_stream after contact: {exc}")
        self._collision_recovery_message = message
        self._collision_recovery_pending = True
        self._collision_recovery_attempted = False
        self._collision_recovery_retry_count = 0
        self._collision_recovery_until = time.monotonic() + COLLISION_BACKOFF_S
        with self._lock:
            self._status.running = False
            self._status.paused_contact = True
            self._status.recoverable = True
            self._status.last_error = (
                f"Contact detected — waiting {COLLISION_BACKOFF_S:.1f}s before robot recovery. "
                f"{message}"
            )
            self._status.collision_backoff_remaining_s = COLLISION_BACKOFF_S

    def _tick_collision_recovery(self) -> None:
        fault = self._poll_policy_fault()
        if fault and not self._collision_recovery_pending:
            should_recover = False
            with self._lock:
                should_recover = self._status.running
            if should_recover:
                self._begin_collision_recovery(fault)
            return

        if not self._collision_recovery_pending:
            with self._lock:
                self._status.collision_backoff_remaining_s = 0.0
            return

        remaining = max(0.0, self._collision_recovery_until - time.monotonic())
        with self._lock:
            self._status.collision_backoff_remaining_s = remaining
            if remaining > 0.0:
                self._status.last_error = (
                    f"Contact detected — backoff {remaining:.1f}s remaining. "
                    f"{self._collision_recovery_message}"
                )
                return

        if self._collision_recovery_attempted:
            return

        recovered = False

        recover = getattr(self._handler, "recover_policy_stream", None)
        if callable(recover):
            try:
                recover()
                log_event(
                    "molmoact2",
                    f"policy stream recovered after {COLLISION_BACKOFF_S:.1f}s backoff",
                )
                with self._lock:
                    self._status.last_error = (
                        "Contact recovery complete — click Resume after contact to re-observe "
                        "and continue."
                    )
                recovered = True
            except Exception as exc:
                if _is_unsupported_policy_recover_error(str(exc)):
                    log_event(
                        "molmoact2",
                        "policy stream backend does not support recoverPolicyStream; "
                        "continuing with manual resume path",
                    )
                    clear_fault = getattr(self._handler, "clear_policy_fault", None)
                    if callable(clear_fault):
                        try:
                            clear_fault()
                        except Exception as clear_exc:
                            log_event(
                                "molmoact2",
                                f"clearPolicyFault best-effort fallback failed: {clear_exc}",
                            )
                    with self._lock:
                        self._status.last_error = (
                            "Contact backoff complete — backend has no recoverPolicyStream; "
                            "click Resume after contact to re-observe and continue."
                        )
                    recovered = True
                else:
                    if _is_transient_motion_transport_error(str(exc)):
                        self._collision_recovery_retry_count += 1
                        self._collision_recovery_until = (
                            time.monotonic() + COLLISION_RECOVERY_RETRY_BACKOFF_S
                        )
                        log_event(
                            "molmoact2",
                            "policy stream recovery transient failure "
                            f"(attempt={self._collision_recovery_retry_count}): {exc}",
                        )
                        with self._lock:
                            self._status.last_error = (
                                "Contact recovery retrying after transport error "
                                f"(attempt {self._collision_recovery_retry_count}): {exc}"
                            )
                            self._status.collision_backoff_remaining_s = (
                                COLLISION_RECOVERY_RETRY_BACKOFF_S
                            )
                        return

                    log_event("molmoact2", f"policy stream recovery failed: {exc}")
                    with self._lock:
                        self._status.recoverable = False
                        self._status.last_error = f"Contact recovery failed: {exc}"
                    self._collision_recovery_pending = False
                    return
        else:
            with self._lock:
                self._status.last_error = (
                    "Contact detected — click Resume after contact to re-observe and continue."
                )
            recovered = True

        if recovered:
            self._perform_collision_backout()

        self._collision_recovery_attempted = True
        self._collision_recovery_pending = False
        self._collision_recovery_retry_count = 0
        with self._lock:
            if COLLISION_AUTO_RESUME:
                self._status.running = True
                self._status.paused_contact = False
                self._status.recoverable = False
                self._status.last_error = (
                    "Contact recovery complete — resumed with fresh observation after small backout."
                )
            self._status.collision_backoff_remaining_s = 0.0

    def _perform_collision_backout(self) -> None:
        """Best-effort short retreat opposite tool axis after collision recovery."""
        distance = float(COLLISION_BACKOUT_DISTANCE_M)
        if distance <= 0.0:
            return
        read_state = getattr(self._handler, "read_state", None)
        move_to_cart = getattr(self._handler, "move_to_cartesian", None)
        if not callable(read_state) or not callable(move_to_cart):
            return
        try:
            state = read_state()
            if not isinstance(state, list) or len(state) < 6:
                raise RuntimeError(f"unexpected read_state payload: {state}")
            x0, y0, z0 = float(state[0]), float(state[1]), float(state[2])
            axis = tool_axis_from_euler(float(state[3]), float(state[4]), float(state[5]))
            target = [
                x0 - distance * float(axis[0]),
                y0 - distance * float(axis[1]),
                z0 - distance * float(axis[2]),
                float(COLLISION_BACKOUT_TIME_S),
            ]
            move_to_cart(target)
            log_event(
                "molmoact2",
                "collision recovery backout complete "
                f"(distance={distance:.3f}m time={COLLISION_BACKOUT_TIME_S:.2f}s)",
            )
        except Exception as exc:
            log_event("molmoact2", f"collision recovery backout skipped/failed: {exc}")

    def _handle_motion_error(self, exc: BaseException) -> None:
        message = str(exc)
        if (
            is_collision_recovery_error(message)
            or _is_recoverable_motion_disconnect_error(message)
            or self._poll_policy_fault()
        ):
            self._begin_collision_recovery(message)
            return
        self._stop_with_error(message)

    def _apply_final_offset_move(self) -> None:
        """Apply the XYZ offset once to the final pose (gripper orientation held).

        Used by "final" offset mode: the live trajectory runs unshifted, then on stop we read
        the current pose from the standard motion server / libfranka (``get_joint_positions_q9``,
        which maps to ``readJointState`` / ``readOnce`` on hardware), translate the fingertip in
        the base frame while holding orientation, optionally clip to the floor, and command a
        single smooth ``moveToJointPose`` cubic trajectory to that adjusted pose.
        """
        with self._lock:
            offset_mode = self._status.offset_mode
            offset = np.array(
                [self._status.offset_x, self._status.offset_y, self._status.offset_z],
                dtype=np.float64,
            )
            offset_reference = self._status.offset_reference
            tip_offset = self._status.gripper_tip_offset_m
            floor_enabled = self._status.ee_floor_enabled
            floor_z = self._status.ee_floor_z
        if offset_mode != OFFSET_MODE_FINAL or np.allclose(offset, 0.0):
            return

        move_fn = getattr(self._handler, "move_to_joint_pose", None)
        if not callable(move_fn):
            raise RuntimeError(
                "handler has no move_to_joint_pose; cannot apply final-pose offset"
            )

        current_q9 = self._handler.get_joint_positions_q9()
        q7 = np.asarray(current_q9, dtype=np.float64).reshape(9)[:7]
        adjusted = apply_cartesian_offset_to_joints(
            q7,
            offset,
            gripper_tip_offset_m=tip_offset,
            offset_reference=offset_reference,
        )
        if floor_enabled:
            clearance_fn = getattr(self._handler, "tip_clearance_z", None)
            adjusted, _clipped = clip_joints_to_ee_floor(
                adjusted,
                floor_z,
                gripper_tip_offset_m=tip_offset,
                clearance_fn=clearance_fn if callable(clearance_fn) else None,
            )

        cmd = list(np.asarray(adjusted, dtype=np.float64).reshape(7).tolist())
        cmd.append(float(DEFAULT_FINAL_OFFSET_MOVE_TIME_S))
        move_fn(cmd)
        with self._lock:
            self._status.offset_final_moves += 1
        print(
            "[molmoact2] applied final-pose offset "
            f"XYZ=({offset[0]:.4f}, {offset[1]:.4f}, {offset[2]:.4f}) m"
        )

    def refresh_health(self, async_ok: bool = True) -> dict[str, Any]:
        url = self.get_status().server_url

        def _worker() -> None:
            result = check_molmoact2_health(url)
            with self._lock:
                self._status.inference_healthy = result["ok"]
                self._status.inference_health_body = result.get("body", "")

        if async_ok:
            self._health_thread = threading.Thread(target=_worker, daemon=True)
            self._health_thread.start()
            return {"started": True}
        result = check_molmoact2_health(url)
        with self._lock:
            self._status.inference_healthy = result["ok"]
            self._status.inference_health_body = result.get("body", "")
        return result

    def get_status(self) -> MolmoAct2Status:
        with self._lock:
            self._sync_debug_status()
            status = MolmoAct2Status(**vars(self._status))
            status.action_idx = self._action_idx
            status.chunk_size = 0 if self._action_chunk is None else int(self._action_chunk.shape[0])
            status.fetching = self._inference_in_flight()
            if self._fetch_error:
                status.last_error = self._fetch_error
            return status

    def _sync_debug_status(self) -> None:
        self._status.debug_session_dir = self._debug.session_dir
        self._status.debug_chunks_logged = self._debug.chunks_logged
        self._status.debug_last_chunk_dir = self._debug.last_chunk_dir
        self._status.debug_recent = self._debug.recent_entries()

    def _stop_with_error(self, message: str) -> None:
        """Stop the policy loop without taking down the host process."""
        print(f"MolmoAct2 motion error: {message}")
        with self._lock:
            self._status.running = False
            self._status.last_error = message

    def tick(self, sim_dt: float) -> None:
        self._tick_collision_recovery()
        tick_t0 = time.perf_counter()
        with self._lock:
            if not self._status.running:
                return
            external_slot = self._status.external_slot
            external_camera_mode = self._status.external_camera_mode
            instruction = self._status.instruction
            server_url = self._status.server_url
            execution_mode = self._status.execution_mode

        if not self._cameras.observations_ready(external_slot, external_camera_mode):
            self._diag_cam_wait_ticks += 1
            if self._diag_cam_wait_ticks in (1, 30, 120):
                log_event(
                    "molmoact2",
                    f"waiting for camera frames ({self._diag_cam_wait_ticks} policy ticks, "
                    f"slot={external_slot} mode={external_camera_mode})",
                )
            return
        if self._diag_cam_wait_ticks:
            log_event("molmoact2", f"cameras ready after {self._diag_cam_wait_ticks} wait ticks")
        self._diag_cam_wait_ticks = 0

        self._control_accum += sim_dt
        period = 1.0 / CONTROL_HZ
        if self._control_accum < period:
            return
        self._control_accum -= period

        if self._fetch_error:
            with self._lock:
                self._status.running = False
                self._status.last_error = self._fetch_error
            return

        if execution_mode == EXECUTION_MODE_AUTO:
            effective_mode = self._resolve_auto_mode()
        else:
            effective_mode = execution_mode
        self._effective_execution_mode = effective_mode

        self._consume_pending_chunk()

        if effective_mode == EXECUTION_MODE_SYNC:
            self._tick_sync(external_slot, external_camera_mode, instruction, server_url)
            return

        # Open-loop async: execute the full chunk (up to chunk_horizon) with settle between
        # steps, then take a fresh observation and start the next GPU fetch — no overlapping
        # inference.
        if self._chunk_has_remaining_steps() or self._async_awaiting_settle:
            self._tick_async_open_loop(tick_t0)
            return

        if self._inference_in_flight() or self._pending_chunk is not None:
            if self._inference_in_flight():
                self._diag_await_chunk_ticks += 1
                if self._diag_await_chunk_ticks in (1, 30, 60, 120):
                    log_event(
                        "molmoact2",
                        f"awaiting GPU chunk ({self._diag_await_chunk_ticks} policy ticks, fetch in flight)",
                    )
            return
        self._diag_await_chunk_ticks = 0

        self._observe_and_fetch(external_slot, external_camera_mode, instruction, server_url)

    def _tick_async_open_loop(self, tick_t0: float) -> None:
        """Open-loop chunk execution with arm+gripper settle before each step advance."""
        if self._async_awaiting_settle:
            target_q9 = self._async_target_q9
            # Read the actual joint state once and reuse it for both anti-windup pursuit and the
            # settle check, so the two see a consistent snapshot of the arm.
            try:
                q9 = self._handler.get_joint_positions_q9()
            except Exception as exc:
                self._handle_motion_error(exc)
                return
            if target_q9 is not None:
                try:
                    if not self._pursue_policy_target(target_q9, current_q9=q9):
                        self._diag_gripper_wait_ticks += 1
                        if self._diag_gripper_wait_ticks in (1, 15, 60, 120):
                            log_event(
                                "molmoact2",
                                f"gripper not settled ({self._diag_gripper_wait_ticks} ticks, "
                                f"action_idx={self._action_idx})",
                            )
                        log_slow(
                            "molmoact2",
                            "tick (gripper wait)",
                            time.perf_counter() - tick_t0,
                            action_idx=self._action_idx,
                        )
                        return
                except Exception as exc:
                    self._handle_motion_error(exc)
                    return
            if self._diag_gripper_wait_ticks:
                log_event(
                    "molmoact2",
                    f"gripper settled after {self._diag_gripper_wait_ticks} wait ticks",
                )
            self._diag_gripper_wait_ticks = 0
            settled = self._sync_step_settled(q9, target_q9)
            timed_out = time.monotonic() >= self._async_settle_deadline
            if not settled and not timed_out:
                self._diag_async_settle_ticks += 1
                err = self._joint_settle_error_rad(q9, target_q9)
                if err + ASYNC_STALL_IMPROVEMENT_EPS_RAD < self._async_stall_best_err:
                    self._async_stall_best_err = err
                    self._async_stall_ticks = 0
                elif err >= ASYNC_STALL_ERR_RAD:
                    self._async_stall_ticks += 1
                else:
                    self._async_stall_ticks = 0
                    self._async_stall_best_err = err

                if self._async_stall_ticks >= ASYNC_STALL_TICKS:
                    self._begin_collision_recovery(
                        "possible contact/stall during async step "
                        f"(action_idx={self._action_idx}, max_joint_err={err:.3f} rad, "
                        f"ticks={self._async_stall_ticks})"
                    )
                    return

                if self._diag_async_settle_ticks in (1, 15, 60, 120):
                    log_event(
                        "molmoact2",
                        f"async step pursuing target ({self._diag_async_settle_ticks} ticks, "
                        f"action_idx={self._action_idx}, max_joint_err={err:.3f} rad)",
                    )
                log_slow(
                    "molmoact2",
                    "tick (async settle wait)",
                    time.perf_counter() - tick_t0,
                    action_idx=self._action_idx,
                )
                return
            if timed_out and not settled:
                err = self._joint_settle_error_rad(q9, target_q9)
                with self._lock:
                    self._status.last_max_joint_tracking_err_rad = err
                if err > SYNC_JOINT_SETTLE_TOL_RAD * 3:
                    # Too far from the commanded target to trust an open-loop advance (the policy
                    # would otherwise act as if this step completed). Abandon the chunk and
                    # re-observe so the next inference corrects from the real arm state.
                    log_event(
                        "molmoact2",
                        f"async step abandoned (max_joint_err={err:.3f} rad > "
                        f"{SYNC_JOINT_SETTLE_TOL_RAD * 3:.3f} rad) — re-observing "
                        f"(action_idx={self._action_idx})",
                    )
                    self._diag_async_settle_ticks = 0
                    self._async_awaiting_settle = False
                    self._async_target_q9 = None
                    self._async_stall_ticks = 0
                    self._async_stall_best_err = float("inf")
                    self._consume_handler_floor_clips()
                    self._action_chunk = None
                    self._action_idx = 0
                    return
                log_event(
                    "molmoact2",
                    f"async step soft timeout ({SYNC_STEP_TIMEOUT_S:.1f}s, "
                    f"max_joint_err={err:.3f} rad ≤ {SYNC_JOINT_SETTLE_TOL_RAD * 3:.3f} rad) "
                    f"— advancing action_idx={self._action_idx}",
                )
            else:
                with self._lock:
                    self._status.last_max_joint_tracking_err_rad = (
                        self._joint_settle_error_rad(q9, target_q9)
                    )
                if self._diag_async_settle_ticks:
                    log_event(
                        "molmoact2",
                        f"async step settled after {self._diag_async_settle_ticks} wait ticks",
                    )
            self._diag_async_settle_ticks = 0
            self._async_awaiting_settle = False
            self._async_target_q9 = None
            self._async_stall_ticks = 0
            self._async_stall_best_err = float("inf")
            self._consume_handler_floor_clips()
            self._action_idx += 1
            self._exec_step += 1
            with self._lock:
                self._status.steps_applied += 1
            chunk = self._action_chunk
            if chunk is not None and self._action_idx >= len(chunk):
                chunk_len = len(chunk)
                log_event(
                    "molmoact2",
                    f"chunk complete ({chunk_len}/{chunk_len} steps settled) — next tick re-observes",
                )
                self._action_chunk = None
                self._action_idx = 0
            return

        try:
            q9 = self._handler.get_joint_positions_q9()
        except Exception as exc:
            self._handle_motion_error(exc)
            return

        chunk = self._action_chunk
        if chunk is None or self._action_idx >= len(chunk):
            return

        if self._grasp_at_idx is not None and self._action_idx == self._grasp_at_idx:
            if self._grasp_macro_allowed_here(q9):
                self._run_chunk_grasp(
                    chunk[self._action_idx], q9, truncate_after_grasp=True
                )
                return
            # Above grasp height — drop the marker and apply the policy close as a normal step.
            self._grasp_at_idx = None

        self._log_policy_gripper_intent(chunk[self._action_idx], phase="async")
        target_q9 = actions8_to_q9(chunk[self._action_idx], q9)
        target_q9 = self._apply_action_postprocess_to_q9(target_q9, current_q9=q9)
        try:
            applied = self._handler.apply_policy_joint_targets(target_q9, current_q9=q9)
        except Exception as exc:
            self._handle_motion_error(exc)
            return
        if not applied:
            self._diag_gripper_wait_ticks += 1
            if self._diag_gripper_wait_ticks in (1, 15, 60, 120):
                log_event(
                    "molmoact2",
                    f"gripper not settled ({self._diag_gripper_wait_ticks} ticks, "
                    f"action_idx={self._action_idx})",
                )
            log_slow(
                "molmoact2",
                "tick (gripper wait)",
                time.perf_counter() - tick_t0,
                action_idx=self._action_idx,
            )
            return
        if self._diag_gripper_wait_ticks:
            log_event(
                "molmoact2",
                f"gripper settled after {self._diag_gripper_wait_ticks} wait ticks",
            )
        self._diag_gripper_wait_ticks = 0
        steps_before = 0
        with self._lock:
            steps_before = self._status.steps_applied
        self._consume_handler_floor_clips()
        if steps_before == 0:
            log_event(
                "molmoact2",
                "first action applied (policy stream should start on next setJointPose)",
            )
        self._async_target_q9 = target_q9
        self._async_awaiting_settle = True
        self._async_settle_deadline = time.monotonic() + SYNC_STEP_TIMEOUT_S
        self._async_stall_ticks = 0
        self._async_stall_best_err = float("inf")
        log_slow(
            "molmoact2",
            "tick (async apply)",
            time.perf_counter() - tick_t0,
            action_idx=self._action_idx,
        )

    def _tick_sync(
        self,
        external_slot: str,
        external_camera_mode: str,
        instruction: str,
        server_url: str,
    ) -> None:
        """Step-by-step (horizon-1) control: observe → infer → apply ONLY the first action,
        wait for the arm + gripper to reach it, then drop the chunk and observe again.

        Nothing overlaps here: inference is only started while no chunk is loaded, and the next
        observation is not taken until the single commanded step has settled (or timed out).
        """
        # Phase 1 — a chunk is loaded: command / settle its first action only.
        if self._action_chunk is not None and len(self._action_chunk) > 0:
            try:
                q9 = self._handler.get_joint_positions_q9()
            except Exception as exc:
                self._handle_motion_error(exc)
                return

            if not self._sync_awaiting_settle:
                if self._grasp_at_idx == 0:
                    if self._grasp_macro_allowed_here(q9):
                        self._run_chunk_grasp(
                            self._action_chunk[0], q9, truncate_after_grasp=True
                        )
                        return
                    # Above grasp height — keep the policy close as a normal step.
                    self._grasp_at_idx = None
                self._log_policy_gripper_intent(self._action_chunk[0], phase="sync")
                target_q9 = actions8_to_q9(self._action_chunk[0], q9)
                target_q9 = self._apply_action_postprocess_to_q9(target_q9, current_q9=q9)
                if not self._pursue_policy_target(target_q9, current_q9=q9):
                    return
                self._consume_handler_floor_clips()
                self._sync_target_q9 = target_q9
                self._sync_awaiting_settle = True
                self._sync_settle_deadline = time.monotonic() + SYNC_STEP_TIMEOUT_S
                return

            target_q9 = self._sync_target_q9
            if target_q9 is not None:
                try:
                    if not self._pursue_policy_target(target_q9, current_q9=q9):
                        return
                except Exception as exc:
                    self._handle_motion_error(exc)
                    return
            try:
                q9 = self._handler.get_joint_positions_q9()
            except Exception as exc:
                self._handle_motion_error(exc)
                return
            settled = self._sync_step_settled(q9, target_q9)
            timed_out = time.monotonic() >= self._sync_settle_deadline
            if settled or timed_out:
                err = self._joint_settle_error_rad(q9, target_q9)
                with self._lock:
                    self._status.last_max_joint_tracking_err_rad = err
                if timed_out and not settled:
                    log_event(
                        "molmoact2",
                        f"sync step settle timeout ({SYNC_STEP_TIMEOUT_S:.1f}s, "
                        f"max_joint_err={err:.3f} rad) — re-observing",
                    )
                self._consume_handler_floor_clips()
                self._exec_step += 1
                with self._lock:
                    self._status.steps_applied += 1
                # Horizon 1: discard the remaining chunk so the next tick re-observes + re-infers.
                self._action_chunk = None
                self._action_idx = 0
                self._sync_awaiting_settle = False
                self._sync_target_q9 = None
            return

        # Phase 2 — no chunk loaded: take one observation and fire a single inference, then wait
        # for it (consumed on a later tick by _consume_pending_chunk).
        if self._inference_in_flight() or self._pending_chunk is not None:
            return
        self._observe_and_fetch(external_slot, external_camera_mode, instruction, server_url)

    def _joint_settle_error_rad(self, q9_current: np.ndarray, q9_target: np.ndarray | None) -> float:
        if q9_target is None:
            return 0.0
        cur = np.asarray(q9_current, dtype=np.float64).reshape(9)
        tgt = np.asarray(q9_target, dtype=np.float64).reshape(9)
        return float(np.max(np.abs(cur[:7] - tgt[:7])))

    def _log_policy_gripper_intent(self, action8: np.ndarray, *, phase: str) -> None:
        """Log only open/close command edges so mid-air releases can be attributed precisely."""
        action = np.asarray(action8, dtype=np.float64).reshape(-1)
        if action.shape[0] < 8:
            return
        droid_g = float(action[7])
        desired_closed = droid_gripper_is_closed_command(droid_g)
        prev = self._diag_last_policy_close_cmd
        if prev is not None and prev == desired_closed:
            return
        self._diag_last_policy_close_cmd = desired_closed
        verb = "close" if desired_closed else "open"
        target_width_m = droid_gripper_to_width_m(droid_g)
        log_event(
            "molmoact2",
            f"policy gripper intent edge ({phase}) exec_step={self._exec_step} "
            f"action_idx={self._action_idx} droid_g={droid_g:.3f} "
            f"target_width_m={target_width_m:.3f} => {verb} "
            f"(grasp_at_idx={self._grasp_at_idx}, holding={self._grasp_holding})",
        )

    def _sync_step_settled(self, q9_current: np.ndarray, q9_target: np.ndarray | None) -> bool:
        """True once every arm joint and the gripper width are within the settle tolerances."""
        if q9_target is None:
            return True
        joint_err = self._joint_settle_error_rad(q9_current, q9_target)
        desired_closed = desired_closed_from_q9(np.asarray(q9_target, dtype=np.float64).reshape(9))
        grip_ok = physical_gripper_is_settled(
            q9_width_m(np.asarray(q9_current, dtype=np.float64).reshape(9)),
            desired_closed,
        )
        return joint_err <= SYNC_JOINT_SETTLE_TOL_RAD and grip_ok

    def _pursue_policy_target(
        self, target_q9: np.ndarray, current_q9: np.ndarray | None = None
    ) -> bool:
        """Keep streaming toward ``target_q9`` (rate-limited on hardware). Returns False if gripper blocks.

        ``current_q9`` (the freshly-read robot state) is forwarded to the handler for anti-windup
        so the commanded target cannot race ahead of the actual joints during a stall.
        """
        return self._handler.apply_policy_joint_targets(target_q9, current_q9=current_q9)

    def _grasp_macro_allowed_here(self, current_q9: np.ndarray) -> bool:
        """Height gate for the poke-and-grab macro (Fix 7).

        The macro only replaces an open->close transition when the fingertip is at/below
        ``grasp_integration_max_z`` (near the table / grasp region). Above that height the policy's
        own close is kept so transit moves are not hijacked by the macro.
        """
        with self._lock:
            max_z = self._status.grasp_integration_max_z
            tip_offset = self._status.gripper_tip_offset_m
        q7 = np.asarray(current_q9, dtype=np.float64).reshape(9)[:7]
        tip_z = effective_ee_tip_z(q7, gripper_tip_offset_m=tip_offset)
        if tip_z > max_z:
            log_event(
                "molmoact2",
                f"grasp integration: open->close above grasp height "
                f"(tip_z={tip_z:.4f} m > max_z={max_z:.4f} m) — keeping policy close",
            )
            return False
        return True

    def _run_chunk_grasp(
        self,
        close_action8: np.ndarray,
        current_q9: np.ndarray,
        *,
        truncate_after_grasp: bool,
    ) -> None:
        """Replace the policy's open->close action with the poke-and-grab macro.

        The close action's arm target (with the gripper forced open and the usual offset / floor
        post-processing applied) becomes the grasp anchor: the arm drives there, advances the
        fingertip along the real tool axis, force-grasps, then snaps back to that exact pose.
        In async mode we now continue with the remaining chunk actions; in sync mode (horizon-1)
        we keep the original truncate/re-observe behavior.
        """
        action = np.asarray(close_action8, dtype=np.float64).reshape(-1)
        open_action = action.copy()
        if open_action.shape[0] >= 8:
            open_action[7] = 0.0  # hold the gripper open through the approach
        target_q9 = actions8_to_q9(open_action, current_q9)
        target_q9 = self._apply_action_postprocess_to_q9(target_q9, current_q9=current_q9)
        anchor_q7 = np.asarray(target_q9, dtype=np.float64).reshape(9)[:7].tolist()

        with self._lock:
            distance = self._status.grasp_advance_m
            grasp_idx = self._grasp_at_idx

        if distance <= 0.0:
            # Integration is on but advance is zeroed — fall back to a plain commanded close.
            log_event(
                "molmoact2",
                f"grasp integration: advance is 0 at action_idx={grasp_idx}; "
                "applying commanded close instead of poke-and-grab",
            )
            close_q9 = actions8_to_q9(action, current_q9)
            close_q9 = self._apply_action_postprocess_to_q9(close_q9, current_q9=current_q9)
            try:
                self._handler.apply_policy_joint_targets(close_q9, current_q9=current_q9)
            except Exception as exc:
                self._handle_motion_error(exc)
                return
            self._finish_chunk_grasp(truncate_chunk=truncate_after_grasp)
            return

        log_event(
            "molmoact2",
            f"grasp integration: open->close at action_idx={grasp_idx} — poke-and-grab "
            f"(advance={distance:.3f} m), truncating remaining chunk",
        )
        try:
            run_grasp_sequence(
                self._handler,
                distance_m=distance,
                forward_time_s=GRASP_INTEGRATION_FORWARD_TIME_S,
                retract_time_s=GRASP_INTEGRATION_RETRACT_TIME_S,
                approach_q7=anchor_q7,
                approach_time_s=GRASP_INTEGRATION_APPROACH_TIME_S,
                log_channel="molmoact2",
            )
        except Exception as exc:
            self._handle_motion_error(exc)
            return
        self._consume_handler_floor_clips()
        self._finish_chunk_grasp(truncate_chunk=truncate_after_grasp)
        if truncate_after_grasp:
            log_event("molmoact2", "grasp integration: poke-and-grab complete — re-observing")
        else:
            log_event(
                "molmoact2",
                "grasp integration: poke-and-grab complete — continuing remaining chunk actions",
            )

    def _finish_chunk_grasp(self, *, truncate_chunk: bool = True) -> None:
        """Finalize grasp replacement action and reset stream state.

        When ``truncate_chunk`` is True (sync/horizon-1), drop the rest of the chunk and
        re-observe. When False (async), mark the grasp action as completed and continue with the
        subsequent actions in the current chunk.
        """
        # moveToCartesian / moveToJointPose stopped the policy stream server-side; clear the
        # client-side ramp + gripper tracker so the next setJointPose restarts cleanly from rest.
        stop_stream = getattr(self._handler, "stop_policy_stream", None)
        if callable(stop_stream):
            try:
                stop_stream()
            except Exception as exc:
                print(f"MolmoAct2 grasp stop_policy_stream: {exc}")
        reset_policy_gripper_tracker(self._handler)
        chunk = self._action_chunk
        if truncate_chunk:
            self._action_chunk = None
            self._action_idx = 0
        else:
            self._action_idx += 1
            if chunk is None or self._action_idx >= len(chunk):
                self._action_chunk = None
                self._action_idx = 0
        self._grasp_at_idx = None
        self._async_awaiting_settle = False
        self._async_target_q9 = None
        self._sync_awaiting_settle = False
        self._sync_target_q9 = None
        # We are now holding the object: mark it so the next chunk's grasp-edge detector does not
        # mistake a still-closed command for a new open->close edge and re-open/drop a big object.
        self._grasp_holding = True
        self._exec_step += 1
        with self._lock:
            self._status.steps_applied += 1
            self._status.grasp_sequences += 1

    def _consume_handler_floor_clips(self) -> None:
        consume_clips = getattr(self._handler, "consume_ee_floor_clips", None)
        if not callable(consume_clips):
            return
        clip_count = consume_clips()
        if clip_count:
            with self._lock:
                self._status.ee_floor_clips += clip_count

    def _resolve_auto_mode(self) -> str:
        """Pick async open-loop vs sync step-by-step from gripper-tip Z (with hysteresis).

        High tip → async (full chunk, then re-observe); tip at/below ``sync_below_z`` → sync.
        Uses local FK (no extra round-trip) for the band decision; if the robot state can't be read we
        keep the last decided mode.
        """
        with self._lock:
            threshold = self._status.sync_below_z
            tip_offset = self._status.gripper_tip_offset_m
        try:
            q9 = self._handler.get_joint_positions_q9()
        except Exception:
            return self._auto_mode_state
        q7 = np.asarray(q9, dtype=np.float64).reshape(9)[:7]
        tip_z = effective_ee_tip_z(q7, gripper_tip_offset_m=tip_offset)

        prev = self._auto_mode_state
        if prev == EXECUTION_MODE_SYNC:
            new_mode = (
                EXECUTION_MODE_ASYNC
                if tip_z >= threshold + AUTO_MODE_Z_HYSTERESIS_M
                else EXECUTION_MODE_SYNC
            )
        else:
            new_mode = EXECUTION_MODE_SYNC if tip_z <= threshold else EXECUTION_MODE_ASYNC

        if new_mode != prev:
            self._on_auto_mode_switch(prev, new_mode)
            self._auto_mode_state = new_mode
        with self._lock:
            self._status.auto_active_mode = new_mode
            self._status.ee_floor_last_tip_z = float(tip_z)
        return new_mode

    def _on_auto_mode_switch(self, prev: str, new_mode: str) -> None:
        """Drop any in-progress chunk so the new sub-mode starts from a fresh observation.

        Any in-flight inference is left to finish; its chunk is consumed fresh by the new mode.
        """
        self._action_chunk = None
        self._action_idx = 0
        self._grasp_at_idx = None
        self._sync_awaiting_settle = False
        self._sync_target_q9 = None
        self._async_awaiting_settle = False
        self._async_target_q9 = None
        print(f"[molmoact2] auto execution mode: {prev} -> {new_mode}")

    def _capture_policy_snapshot(
        self, external_slot: str, external_camera_mode: str
    ) -> tuple[np.ndarray | None, np.ndarray | None, np.ndarray | None] | None:
        """Fresh multi-view RGB from one capture pass, then paired with joint state."""
        capture = getattr(self._cameras, "capture_policy_observation", None)
        if callable(capture):
            return capture(external_slot, external_camera_mode)
        ext_rgb, ext2_rgb = self._resolve_external_images(external_slot, external_camera_mode)
        wrist_rgb = self._cameras.get_rgb("wrist")
        if ext_rgb is None or wrist_rgb is None:
            return None
        if external_camera_mode == "dual" and ext2_rgb is None:
            return None
        return ext_rgb, ext2_rgb, wrist_rgb

    def _policy_gripper_closed_hint(self) -> bool:
        """True when the gripper is believed closed/holding, for the policy STATE saturation.

        The Franka Hand reports a big held object's width, which the raw state mapping shows as only
        partly closed; the policy then treats the grasp as "not grasped" and can release it. Treat
        the gripper as closed for the policy's state when either the poke-and-grab holding latch is
        set or the last binary gripper command (tracked by the coordinated apply path) was close.
        This covers both grasp-integration modes and large objects that width alone would miss.
        """
        if getattr(self, "_grasp_holding", False):
            return True
        tracker = getattr(self._handler, "_policy_gripper", None)
        return bool(getattr(tracker, "last_commanded_closed", None))

    def _observe_and_fetch(
        self,
        external_slot: str,
        external_camera_mode: str,
        instruction: str,
        server_url: str,
    ) -> None:
        """Fresh observation paired with the robot state, then start one GPU fetch (Fix 5).

        Captures live images, reads the joint state immediately afterward (so the image batch and
        ``state8`` describe the same instant), records freshness diagnostics (Fix 11), and fires
        inference. Centralizes the capture->state->fetch sequence used by both async and sync ticks.
        """
        t_before = time.monotonic()
        snapshot = self._capture_policy_snapshot(external_slot, external_camera_mode)
        if snapshot is None:
            return
        ext_rgb, ext2_rgb, wrist_rgb = snapshot
        ready = ext_rgb is not None and wrist_rgb is not None
        if ready and external_camera_mode == "dual" and ext2_rgb is None:
            ready = False
        if not ready:
            return
        # Read the robot state right after the images so the two are temporally aligned.
        try:
            q9 = self._handler.get_joint_positions_q9()
        except Exception as exc:
            self._handle_motion_error(exc)
            return
        t_state = time.monotonic()
        state8 = state8_from_q9(q9, gripper_closed_hint=self._policy_gripper_closed_hint())
        capture_fn = getattr(self._cameras, "last_policy_capture_monotonic", None)
        frame_t = capture_fn() if callable(capture_fn) else 0.0
        if not frame_t:
            frame_t = t_before
        state_skew_ms = max(0.0, (t_state - frame_t) * 1000.0)
        frame_age_ms = max(0.0, (time.monotonic() - frame_t) * 1000.0)
        with self._lock:
            self._status.last_obs_frame_age_ms = frame_age_ms
            self._status.last_obs_state_skew_ms = state_skew_ms
        log_event(
            "molmoact2",
            f"obs frame_age_ms={frame_age_ms:.0f} state_skew_ms={state_skew_ms:.0f} "
            f"grip_state={float(state8[7]):.2f}",
        )
        self._maybe_start_fetch(
            ext_rgb, wrist_rgb, state8, instruction, server_url, ext2_rgb=ext2_rgb
        )

    def _resolve_external_images(
        self, external_slot: str, external_camera_mode: str
    ) -> tuple[np.ndarray | None, np.ndarray | None]:
        """Map sim camera IDs to MolmoAct2 exterior slots (see module-level camera order)."""
        if external_camera_mode == "dual":
            return self._cameras.get_rgb("external_1"), self._cameras.get_rgb("external_2")
        primary = self._cameras.get_rgb(external_slot)
        if external_camera_mode == "duplicate" and primary is not None:
            return primary, primary.copy()
        return primary, None

    def _trim_action_chunk(
        self,
        chunk: np.ndarray,
        *,
        horizon: int | None = None,
        log_discard: bool = True,
    ) -> np.ndarray:
        actions = np.asarray(chunk, dtype=np.float32)
        if actions.ndim == 1:
            actions = actions[None, :]
        if horizon is None:
            with self._lock:
                horizon = self._status.chunk_horizon
        raw_n = int(actions.shape[0])
        if raw_n > horizon:
            if log_discard:
                log_event(
                    "molmoact2",
                    f"chunk horizon={horizon}: executing first {horizon} of {raw_n} GPU actions "
                    f"(discarded {raw_n - horizon})",
                )
            actions = actions[:horizon]
        return actions

    def _consume_pending_chunk(self) -> None:
        with self._lock:
            if self._pending_chunk is None:
                return
            if self._action_chunk is not None and (
                self._action_idx < len(self._action_chunk) or self._async_awaiting_settle
            ):
                return
            pending = self._pending_chunk
            horizon = self._status.chunk_horizon
            grasp_enabled = self._status.grasp_integration_enabled
            effective_mode = self._effective_execution_mode

        chunk = self._trim_action_chunk(pending, horizon=horizon, log_discard=False)
        # Find the first open->close gripper transition (robot read) outside the lock so the
        # status mutex is never held across a network round-trip. Only this (tick) thread loads
        # chunks, so the pending slot cannot change underneath us here.
        grasp_idx = self._compute_grasp_index(chunk) if grasp_enabled else None

        with self._lock:
            self._pending_chunk = None
            self._action_chunk = chunk
            self._grasp_at_idx = grasp_idx
            self._action_idx = 0
            if effective_mode == EXECUTION_MODE_SYNC:
                # Horizon-1: always execute the freshly-observed chunk from its first action.
                self._sync_awaiting_settle = False
                self._sync_target_q9 = None
            else:
                # Open-loop: chunk was fetched after the previous chunk finished — start at 0.
                self._async_awaiting_settle = False
                self._async_target_q9 = None
            self._status.chunks_fetched += 1
            if self._pending_dt_ms is not None:
                self._status.last_dt_ms = self._pending_dt_ms
                self._pending_dt_ms = None
            chunk_num = self._status.chunks_fetched
            exec_step = self._exec_step
        self._diag_await_chunk_ticks = 0
        grasp_note = "" if grasp_idx is None else f" grasp_at_idx={grasp_idx}"
        log_event(
            "molmoact2",
            f"chunk #{chunk_num} loaded shape={chunk.shape} "
            f"steps_to_run={chunk.shape[0]} exec_step={exec_step}{grasp_note}",
        )

    def _compute_grasp_index(self, chunk: np.ndarray | None) -> int | None:
        """Index of the first action whose gripper command goes open -> close.

        The pre-chunk state is taken from the physical gripper, then each action's binarized
        gripper command is walked; the first open->close edge is where the poke-and-grab macro
        replaces the policy's close. Returns ``None`` if there is no such transition.

        ``physical_gripper_is_closed`` keys off jaw width (< ~4 cm), but a force-grasped *large*
        object holds the jaws apart by its own width and reads as "open". Without the
        ``_grasp_holding`` latch the detector would see a spurious open->close edge at index 0 on
        the very next chunk and re-run the macro, whose approach re-opens the gripper and drops
        the held object (small objects close past 4 cm so they never tripped this). While holding,
        the start state is treated as closed so a chunk that keeps commanding close yields no new
        edge; the latch self-clears once the jaws are observed fully open again (object released).
        """
        if chunk is None or len(chunk) == 0:
            return None
        try:
            width_m = q9_width_m(self._handler.get_joint_positions_q9())
        except Exception:
            return None
        if physical_gripper_is_settled(width_m, False):
            # Jaws fully open => nothing is held; drop any stale holding latch so a genuine
            # next grasp (e.g. after placing an object) is still detected.
            self._grasp_holding = False
        prev_closed = physical_gripper_is_closed(width_m) or self._grasp_holding
        for i in range(len(chunk)):
            action = np.asarray(chunk[i], dtype=np.float64).reshape(-1)
            if action.shape[0] < 8:
                continue
            cur_closed = droid_gripper_is_closed_command(action[7])
            if cur_closed and not prev_closed:
                return i
            prev_closed = cur_closed
        return None

    def _maybe_start_fetch(
        self,
        ext_rgb: np.ndarray,
        wrist_rgb: np.ndarray,
        state8: np.ndarray,
        instruction: str,
        server_url: str,
        ext2_rgb: np.ndarray | None = None,
    ) -> None:
        with self._lock:
            if self._fetch_worker_active:
                log_event("molmoact2", "GPU fetch skipped: worker already active")
                return
            cooldown_remaining = self._fetch_cooldown_until - time.monotonic()
            if cooldown_remaining > 0.0:
                if self._diag_await_chunk_ticks in (0, 1):
                    log_event(
                        "molmoact2",
                        f"GPU fetch deferred: cooling down after failure "
                        f"({cooldown_remaining:.2f}s left)",
                    )
                return
            if self._fetch_thread is not None and self._fetch_thread.is_alive():
                log_event("molmoact2", "GPU fetch skipped: prior fetch thread still alive")
                return
            if self._pending_chunk is not None:
                log_event("molmoact2", "GPU fetch skipped: chunk already pending")
                return
            if self._action_chunk is not None and self._action_idx < len(self._action_chunk):
                # No overlapping inference: a fresh observation is only taken AFTER the chunk
                # fully completes. MolmoAct2 returns ABSOLUTE joint targets tied to the observation
                # instant, so fetching mid-chunk (e.g. prefetch) would compute the next chunk from
                # a position the arm has already moved past — applying it later snaps the arm back
                # to that older pose (visible "bob"). Always wait for the chunk to finish.
                log_event(
                    "molmoact2",
                    f"GPU fetch skipped: chunk in progress ({self._action_idx}/{len(self._action_chunk)})",
                )
                return
            self._fetch_worker_active = True
            self._fetch_seq += 1
            fetch_seq = self._fetch_seq
            self._status.fetching = True

        ext_copy = ext_rgb.copy()
        ext2_copy = None if ext2_rgb is None else ext2_rgb.copy()
        wrist_copy = wrist_rgb.copy()
        state_copy = state8.copy()
        status_snapshot = self.get_status()
        camera_mode = status_snapshot.external_camera_mode
        debug_mode = status_snapshot.debug_mode
        chunk_horizon = status_snapshot.chunk_horizon

        log_event(
            "molmoact2",
            f"GPU fetch #{fetch_seq} started exec_step={self._exec_step} server={server_url}",
        )

        def _worker() -> None:
            t0 = time.perf_counter()
            endpoint = ""
            try:
                endpoint, payload = build_molmoact2_request(
                    camera_mode,
                    ext_copy,
                    wrist_copy,
                    state_copy,
                    instruction,
                    ext2_rgb=ext2_copy,
                    chunk_horizon=chunk_horizon,
                )
                chunk, dt_ms = query_molmoact2(server_url, endpoint, payload)
                raw_n = int(chunk.shape[0]) if getattr(chunk, "ndim", 0) > 1 else 1
                chunk = self._trim_action_chunk(chunk, horizon=chunk_horizon)
                elapsed = time.perf_counter() - t0
                if debug_mode:
                    self._debug.record_fetch(
                        external_camera_mode=camera_mode,
                        ext_rgb=ext_copy,
                        wrist_rgb=wrist_copy,
                        ext2_rgb=ext2_copy,
                        state8=state_copy,
                        instruction=instruction,
                        server_url=server_url,
                        endpoint=endpoint,
                        actions=chunk,
                        dt_ms=dt_ms,
                        fetch_elapsed_s=elapsed,
                    )
                with self._lock:
                    if not self._status.running:
                        log_event(
                            "molmoact2",
                            f"GPU fetch #{fetch_seq} discarded "
                            f"(raw={raw_n} trimmed={chunk.shape[0]}, inference stopped)",
                        )
                        return
                    self._pending_chunk = chunk
                    self._pending_dt_ms = dt_ms
                    self._status.last_fetch_s = elapsed
                    self._status.last_endpoint = endpoint
                    self._fetch_error = None
                    if self._status.consecutive_fetch_failures:
                        self._status.consecutive_fetch_failures = 0
                        self._status.last_error = ""
                    self._sync_debug_status()
                log_event(
                    "molmoact2",
                    f"GPU fetch #{fetch_seq} done in {elapsed:.2f}s "
                    f"raw={raw_n} executing={chunk.shape[0]} horizon={chunk_horizon} "
                    f"endpoint={endpoint} gpu_dt_ms={dt_ms}",
                )
            except Exception as exc:
                elapsed = time.perf_counter() - t0
                if debug_mode:
                    try:
                        if not endpoint:
                            endpoint, _ = build_molmoact2_request(
                                camera_mode,
                                ext_copy,
                                wrist_copy,
                                state_copy,
                                instruction,
                                ext2_rgb=ext2_copy,
                            )
                        self._debug.record_fetch(
                            external_camera_mode=camera_mode,
                            ext_rgb=ext_copy,
                            wrist_rgb=wrist_copy,
                            ext2_rgb=ext2_copy,
                            state8=state_copy,
                            instruction=instruction,
                            server_url=server_url,
                            endpoint=endpoint,
                            actions=None,
                            dt_ms=None,
                            fetch_elapsed_s=elapsed,
                            error=str(exc),
                        )
                    except Exception as debug_exc:
                        print(f"[molmoact2 debug] failed to record error chunk: {debug_exc}")
                with self._lock:
                    self._status.consecutive_fetch_failures += 1
                    failures = self._status.consecutive_fetch_failures
                    self._fetch_cooldown_until = time.monotonic() + FETCH_FAILURE_COOLDOWN_S
                    if failures >= MAX_CONSECUTIVE_FETCH_FAILURES:
                        # Give up: surface a fatal error so the next tick stops the loop.
                        self._fetch_error = str(exc)
                        print(
                            f"[molmoact2] inference failed {failures} times in a row, "
                            f"stopping loop: {exc}"
                        )
                    else:
                        # Transient: keep the loop alive. The arm holds its last commanded
                        # target and the next tick fires a fresh inference request.
                        self._status.last_error = (
                            f"inference fetch failed "
                            f"({failures}/{MAX_CONSECUTIVE_FETCH_FAILURES}), retrying: {exc}"
                        )
                        print(
                            f"[molmoact2] transient fetch failure "
                            f"{failures}/{MAX_CONSECUTIVE_FETCH_FAILURES}: {exc}"
                        )
                    self._sync_debug_status()
            finally:
                with self._lock:
                    self._fetch_worker_active = False
                    self._status.fetching = False

        self._fetch_thread = threading.Thread(
            target=_worker, daemon=True, name=f"molmoact2-fetch-{fetch_seq}"
        )
        self._fetch_thread.start()
