# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Cartesian post-processing for MolmoAct2 joint-space actions (offsets + EE floor clip)."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable

import numpy as np

# Franka Panda modified (Craig) DH (m, rad). These reproduce libfranka's nominal kinematics:
# FK position + tool axis match ``franka::Model`` to <0.2 mm / 0 deg. Per modified-DH convention
# each link i uses (a_{i-1}, alpha_{i-1}, d_i); the flange is a final fixed transform with a
# -pi/4 z-rotation so the frame matches the robot's reported O_T_EE orientation exactly.
# libfranka (motion_server.cpp ``fkPose`` / ``zeroJacobian``) is the source of truth; this model
# mirrors it for the latency-critical MolmoAct2 loop and for Isaac Sim (no libfranka there).
_FRANKA_A = (0.0, 0.0, 0.0, 0.0825, -0.0825, 0.0, 0.088)  # a_{i-1}
_FRANKA_D = (0.333, 0.0, 0.316, 0.0, 0.384, 0.0, 0.0)  # d_i (flange d handled separately)
_FRANKA_ALPHA = (0.0, -math.pi / 2, math.pi / 2, math.pi / 2, -math.pi / 2, math.pi / 2, math.pi / 2)  # alpha_{i-1}
_FRANKA_FLANGE_D = 0.107  # flange offset along joint-7 z (m)
_FRANKA_FLANGE_RZ = -math.pi / 4  # flange/EE frame z-rotation (matches libfranka O_T_EE)

DEFAULT_ACTION_OFFSET_XYZ = (0.0, 0.0, 0.0)
# Offset application mode for MolmoAct2 action post-processing:
#   "continuous" — apply the base-frame XYZ offset to every action step (whole trajectory shifts).
#   "final"      — leave the live trajectory untouched; apply the offset once to the final pose
#                  (read from the motion server / libfranka) after the movement completes.
OFFSET_MODE_CONTINUOUS = "continuous"
OFFSET_MODE_FINAL = "final"
VALID_OFFSET_MODES = (OFFSET_MODE_CONTINUOUS, OFFSET_MODE_FINAL)
DEFAULT_OFFSET_MODE = OFFSET_MODE_CONTINUOUS
# Offset reference for XYZ action offsets:
#   "tip_flange"  — existing behavior: XYZ are flange-frame axes and move the fingertip.
#   "flange_base" — XYZ are base-frame deltas applied directly to the flange position.
OFFSET_REFERENCE_TIP_FLANGE = "tip_flange"
OFFSET_REFERENCE_FLANGE_BASE = "flange_base"
VALID_OFFSET_REFERENCES = (OFFSET_REFERENCE_TIP_FLANGE, OFFSET_REFERENCE_FLANGE_BASE)
DEFAULT_OFFSET_REFERENCE = OFFSET_REFERENCE_TIP_FLANGE
# Cubic trajectory time (s) for the one-shot final-pose offset move. motion_server.cpp clamps
# moveToJointPose to a 1 s minimum, so match it here for consistent hardware/sim behavior.
DEFAULT_FINAL_OFFSET_MOVE_TIME_S = 1.0
# Minimum gripper-tip height (m) in robot base +Z; set to measured table height on hardware.
DEFAULT_EE_FLOOR_Z_M = 0.05
# Opt-in: the floor guard ships disabled because an uncalibrated ``ee_floor_z`` clips picks on
# real hardware (the arm hovers above the object). Enable it explicitly after measuring the table
# surface Z (see ``calibrate_ee_floor.py`` / runner ``--ee-floor-z``).
DEFAULT_EE_FLOOR_ENABLED = False
# Distance (m) from flange to lowest fingertip along +EE Z (gripper pointing axis). Stock Franka
# Hand TCP is ~0.1034 m from the flange with standard fingers; set LONG_FINGER_TIP_EXTENSION_M
# only if longer fingers are installed (DROID's Robotiq 2F-85 is longer; the stock hand is not).
_STOCK_GRIPPER_TIP_OFFSET_M = 0.1034
LONG_FINGER_TIP_EXTENSION_M = 0.0
DEFAULT_GRIPPER_TIP_OFFSET_M = _STOCK_GRIPPER_TIP_OFFSET_M + LONG_FINGER_TIP_EXTENSION_M

# Single-shot fingertip IK is accurate for small offsets (fast, used in the live control loop);
# larger moves are split into 5 mm base-frame steps to stay on the same IK branch (no wrist flip).
_SMALL_OFFSET_M = 0.035
_CARTESIAN_STEP_M = 0.005
# Orientation tracking weight for the base +Z (tip-height) offset — strong hold avoids wrist twist.
_Z_ORIENTATION_WEIGHT = 40.0
# Max fingertip rise (m) the floor guard applies per control tick. The guard runs every tick,
# so deeper penetrations recover over a few ticks while each tick's motion stays bounded.
_FLOOR_MAX_RAISE_PER_CALL_M = 0.05
# Deadband (m) for the floor guard. Wider than the IK position residual so a pose already at
# the floor is treated as satisfied — avoids re-clipping (and re-solving IK) every tick.
_FLOOR_CLIP_TOL_M = 5e-4

ClearanceFn = Callable[[np.ndarray], float]


@dataclass
class EeFloorConfig:
    enabled: bool = DEFAULT_EE_FLOOR_ENABLED
    floor_z: float = DEFAULT_EE_FLOOR_Z_M
    gripper_tip_offset_m: float = DEFAULT_GRIPPER_TIP_OFFSET_M


def _dh_transform(a: float, alpha: float, d: float, theta: float) -> np.ndarray:
    """Modified (Craig) DH link transform: Rot_x(alpha) Trans_x(a) Rot_z(theta) Trans_z(d)."""
    ct, st = math.cos(theta), math.sin(theta)
    ca, sa = math.cos(alpha), math.sin(alpha)
    return np.array(
        [
            [ct, -st, 0.0, a],
            [st * ca, ct * ca, -sa, -sa * d],
            [st * sa, ct * sa, ca, ca * d],
            [0.0, 0.0, 0.0, 1.0],
        ],
        dtype=np.float64,
    )


def fk_ee_transform(q7: np.ndarray) -> np.ndarray:
    """Flange pose (4x4, column-basis vectors in columns) in robot base frame.

    Matches libfranka ``O_T_EE`` (position + orientation) to <0.2 mm / ~0 deg.
    """
    q = np.asarray(q7, dtype=np.float64).reshape(7)
    transform = np.eye(4, dtype=np.float64)
    for i in range(7):
        transform = transform @ _dh_transform(_FRANKA_A[i], _FRANKA_ALPHA[i], _FRANKA_D[i], q[i])
    transform = transform @ _dh_transform(0.0, 0.0, _FRANKA_FLANGE_D, _FRANKA_FLANGE_RZ)
    return transform


def fk_ee_position(q7: np.ndarray) -> np.ndarray:
    """Flange position (m) in robot base frame for 7 joint angles."""
    return fk_ee_transform(q7)[:3, 3].copy()


def flange_frame_vector_to_base(q7: np.ndarray, vector_flange: np.ndarray | tuple[float, float, float]) -> np.ndarray:
    """Map a flange-frame vector (X/Y/Z along gripper axes) into the robot base frame."""
    vec = np.asarray(vector_flange, dtype=np.float64).reshape(3)
    if np.allclose(vec, 0.0):
        return vec.copy()
    rotation = fk_ee_transform(q7)[:3, :3]
    return rotation @ vec


def fk_tip_position(q7: np.ndarray, *, gripper_tip_offset_m: float = 0.0) -> np.ndarray:
    """Fingertip position (m) in robot base frame.

    Nominal tip = flange origin + ``gripper_tip_offset_m`` along flange +Z.
    """
    transform = fk_ee_transform(q7)
    return (transform[:3, 3] + flange_frame_vector_to_base(q7, (0.0, 0.0, gripper_tip_offset_m))).copy()


def effective_ee_tip_z(q7: np.ndarray, *, gripper_tip_offset_m: float = 0.0) -> float:
    """Lowest fingertip height (m): flange + offset along +EE Z (Franka finger direction)."""
    transform = fk_ee_transform(q7)
    pos = transform[:3, 3]
    ee_z_axis = transform[:3, 2]
    tip = pos + gripper_tip_offset_m * ee_z_axis
    return float(tip[2])


def effective_ee_height_z(q7: np.ndarray, *, gripper_tip_offset_m: float = 0.0) -> float:
    """Alias for :func:`effective_ee_tip_z` (legacy name)."""
    return effective_ee_tip_z(q7, gripper_tip_offset_m=gripper_tip_offset_m)


def make_tip_clearance_fn(
    gripper_tip_offset_m: float,
    clearance_fn: ClearanceFn | None = None,
) -> ClearanceFn:
    """Build a clearance callback; ``clearance_fn`` overrides Python FK (e.g. libfranka via HTTP)."""
    if clearance_fn is not None:
        return clearance_fn
    tip = gripper_tip_offset_m

    def _python_clearance(q7: np.ndarray) -> float:
        return effective_ee_tip_z(q7, gripper_tip_offset_m=tip)

    return _python_clearance


def _position_jacobian(q7: np.ndarray, eps: float = 1e-5) -> np.ndarray:
    q = np.asarray(q7, dtype=np.float64).reshape(7)
    base = fk_ee_position(q)
    jac = np.zeros((3, 7), dtype=np.float64)
    for i in range(7):
        q_plus = q.copy()
        q_plus[i] += eps
        jac[:, i] = (fk_ee_position(q_plus) - base) / eps
    return jac


def _geometric_jacobian(q7: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Base-frame flange Jacobian (6x7: [linear; angular]) and flange transform.

    Built by finite-differencing :func:`fk_ee_transform` (position + axis-angle orientation) so it
    stays consistent with the corrected modified-DH FK regardless of DH convention. Matches
    libfranka ``zeroJacobian`` to ~1e-4.
    """
    q = np.asarray(q7, dtype=np.float64).reshape(7)
    jac = np.zeros((6, 7), dtype=np.float64)
    jac[:3, :] = _position_jacobian(q)
    jac[3:, :] = _orientation_jacobian(q)
    return jac, fk_ee_transform(q)


def _rotation_matrix_to_rotvec(rotation: np.ndarray) -> np.ndarray:
    """Axis-angle vector (rad) for a 3x3 rotation matrix."""
    rot = np.asarray(rotation, dtype=np.float64).reshape(3, 3)
    trace = float(np.trace(rot))
    cos_angle = max(-1.0, min(1.0, (trace - 1.0) / 2.0))
    angle = math.acos(cos_angle)
    if angle < 1e-8:
        return np.zeros(3, dtype=np.float64)
    axis = np.array(
        [rot[2, 1] - rot[1, 2], rot[0, 2] - rot[2, 0], rot[1, 0] - rot[0, 1]],
        dtype=np.float64,
    )
    denom = 2.0 * math.sin(angle)
    if abs(denom) < 1e-12:
        return np.zeros(3, dtype=np.float64)
    return axis * angle / denom


def _orientation_jacobian(q7: np.ndarray, eps: float = 1e-5) -> np.ndarray:
    """Jacobian of flange orientation (axis-angle) w.r.t. joint angles."""
    q = np.asarray(q7, dtype=np.float64).reshape(7)
    rotation_ref = fk_ee_transform(q)[:3, :3]
    jac = np.zeros((3, 7), dtype=np.float64)
    for i in range(7):
        q_plus = q.copy()
        q_plus[i] += eps
        rotation_plus = fk_ee_transform(q_plus)[:3, :3]
        delta_rotation = rotation_plus @ rotation_ref.T
        jac[:, i] = _rotation_matrix_to_rotvec(delta_rotation) / eps
    return jac


def _tip_position_jacobian(q7: np.ndarray, tip_m: float, eps: float = 1e-5) -> np.ndarray:
    """Jacobian of fingertip position (base frame) w.r.t. joint angles."""
    q = np.asarray(q7, dtype=np.float64).reshape(7)
    base = fk_tip_position(q, gripper_tip_offset_m=tip_m)
    jac = np.zeros((3, 7), dtype=np.float64)
    for i in range(7):
        q_plus = q.copy()
        q_plus[i] += eps
        jac[:, i] = (fk_tip_position(q_plus, gripper_tip_offset_m=tip_m) - base) / eps
    return jac


def _ik_tip_position_delta(
    q7: np.ndarray,
    delta_xyz: np.ndarray | tuple[float, float, float],
    *,
    gripper_tip_offset_m: float,
    q_prior: np.ndarray | None = None,
    max_iters: int = 32,
    damping: float = 0.05,
    null_gain: float = 0.0,
) -> np.ndarray:
    """Move the fingertip by ``delta_xyz`` in the robot base frame (damped least squares)."""
    delta = np.asarray(delta_xyz, dtype=np.float64).reshape(3)
    if np.allclose(delta, 0.0):
        return np.asarray(q7, dtype=np.float64).reshape(7).copy()

    q = np.asarray(q7, dtype=np.float64).reshape(7).copy()
    prior = q if q_prior is None else np.asarray(q_prior, dtype=np.float64).reshape(7)
    tip_m = float(gripper_tip_offset_m)
    target_tip = fk_tip_position(q, gripper_tip_offset_m=tip_m) + delta
    lam = damping**2
    eye7 = np.eye(7, dtype=np.float64)
    for _ in range(max_iters):
        tip_pos = fk_tip_position(q, gripper_tip_offset_m=tip_m)
        err = target_tip - tip_pos
        if float(np.linalg.norm(err)) < 1e-7:
            break
        jac = _tip_position_jacobian(q, tip_m)
        jj = jac @ jac.T + lam * np.eye(3, dtype=np.float64)
        dq_task = jac.T @ np.linalg.solve(jj, err)
        if null_gain > 0.0:
            null_proj = eye7 - jac.T @ np.linalg.solve(jj, jac)
            dq = dq_task + null_gain * (null_proj @ (prior - q))
        else:
            dq = dq_task
        q = q + dq
    return q


def _ik_stepped_tip_delta(
    q7: np.ndarray,
    delta_xyz: np.ndarray | tuple[float, float, float],
    *,
    gripper_tip_offset_m: float,
    max_step: float = _CARTESIAN_STEP_M,
    max_iters: int = 32,
    damping: float = 0.05,
) -> np.ndarray:
    """Apply fingertip deltas in small base-frame steps (avoids wrist flip on large moves)."""
    delta = np.asarray(delta_xyz, dtype=np.float64).reshape(3)
    if np.allclose(delta, 0.0):
        return np.asarray(q7, dtype=np.float64).reshape(7).copy()

    q = np.asarray(q7, dtype=np.float64).reshape(7).copy()
    tip_m = float(gripper_tip_offset_m)
    step_m = max(0.001, float(max_step))
    for axis in range(3):
        remaining = float(delta[axis])
        if abs(remaining) < 1e-12:
            continue
        sign = 1.0 if remaining >= 0.0 else -1.0
        while abs(remaining) > 1e-9:
            step = sign * min(step_m, abs(remaining))
            move = np.zeros(3, dtype=np.float64)
            move[axis] = step
            q = _ik_tip_position_delta(
                q,
                move,
                gripper_tip_offset_m=tip_m,
                q_prior=q,
                max_iters=max_iters,
                damping=damping,
                null_gain=0.0,
            )
            remaining -= step
    return q


def _ik_position_delta(
    q7: np.ndarray,
    delta_xyz: np.ndarray | tuple[float, float, float],
    *,
    q_prior: np.ndarray | None = None,
    max_iters: int = 16,
    damping: float = 0.05,
    null_gain: float = 0.15,
    orientation_weight: float = 1.0,
) -> np.ndarray:
    """Translate flange in base XYZ while holding orientation and staying near ``q_prior``."""
    delta = np.asarray(delta_xyz, dtype=np.float64).reshape(3)
    if np.allclose(delta, 0.0):
        return np.asarray(q7, dtype=np.float64).reshape(7).copy()

    q = np.asarray(q7, dtype=np.float64).reshape(7).copy()
    prior = q if q_prior is None else np.asarray(q_prior, dtype=np.float64).reshape(7)
    transform0 = fk_ee_transform(q)
    target_rotation = transform0[:3, :3].copy()
    target_pos = transform0[:3, 3] + delta
    lam = damping**2
    ow = max(1.0, float(orientation_weight))
    row_w = np.array([1.0, 1.0, 1.0, ow, ow, ow], dtype=np.float64)
    eye6 = np.eye(6, dtype=np.float64)
    eye7 = np.eye(7, dtype=np.float64)
    for _ in range(max_iters):
        base_jac, transform = _geometric_jacobian(q)
        pos_err = target_pos - transform[:3, 3]
        ori_err = _rotation_matrix_to_rotvec(target_rotation @ transform[:3, :3].T)
        err = np.concatenate([pos_err, ori_err])
        if float(np.linalg.norm(err)) < 1e-7:
            break
        werr = row_w * err
        jac = base_jac * row_w[:, None]
        jj = jac @ jac.T + lam * eye6
        dq_task = jac.T @ np.linalg.solve(jj, werr)
        if null_gain > 0.0:
            null_proj = eye7 - jac.T @ np.linalg.solve(jj, jac)
            dq = dq_task + null_gain * (null_proj @ (prior - q))
        else:
            dq = dq_task
        q = q + dq
    return q


def _ik_stepped_cartesian_delta(
    q7: np.ndarray,
    delta_xyz: np.ndarray | tuple[float, float, float],
    *,
    max_step: float = _CARTESIAN_STEP_M,
    max_iters: int = 16,
    damping: float = 0.05,
    orientation_weight: float = 1.0,
) -> np.ndarray:
    """Apply base-frame flange deltas in small steps so IK stays on one branch (no wrist flip).

    Each step is a fully-converged single-shot solve (``null_gain=0``); the small step size —
    not a joint-space prior pull — is what keeps the solution on a single continuous branch.
    """
    delta = np.asarray(delta_xyz, dtype=np.float64).reshape(3)
    if np.allclose(delta, 0.0):
        return np.asarray(q7, dtype=np.float64).reshape(7).copy()

    q = np.asarray(q7, dtype=np.float64).reshape(7).copy()
    step_m = max(0.001, float(max_step))
    for axis in range(3):
        remaining = float(delta[axis])
        if abs(remaining) < 1e-12:
            continue
        sign = 1.0 if remaining >= 0.0 else -1.0
        while abs(remaining) > 1e-9:
            step = sign * min(step_m, abs(remaining))
            move = np.zeros(3, dtype=np.float64)
            move[axis] = step
            q = _ik_position_delta(
                q,
                move,
                q_prior=q,
                max_iters=max_iters,
                damping=damping,
                null_gain=0.0,
                orientation_weight=orientation_weight,
            )
            remaining -= step
    return q


def apply_cartesian_offset_to_joints(
    q7: np.ndarray,
    offset_xyz: np.ndarray | tuple[float, float, float],
    *,
    gripper_tip_offset_m: float = DEFAULT_GRIPPER_TIP_OFFSET_M,
    offset_reference: str = DEFAULT_OFFSET_REFERENCE,
    max_iters: int = 16,
    damping: float = 0.05,
    null_gain: float = 0.0,
) -> np.ndarray:
    """Shift joint targets by cartesian XYZ with selectable reference / target.

    ``offset_reference``:
      - ``tip_flange``  (default): ``offset_xyz`` is in flange/gripper axes and moves the
        fingertip target.
      - ``flange_base``: ``offset_xyz`` is in robot base axes and moves flange position while
        holding flange orientation.

    Small offsets use one solve; larger offsets are split into 5 mm base-frame steps.
    """
    offset = np.asarray(offset_xyz, dtype=np.float64).reshape(3)
    q = np.asarray(q7, dtype=np.float64).reshape(7)
    if np.allclose(offset, 0.0):
        return q.copy()

    reference = parse_offset_reference(offset_reference)

    if reference == OFFSET_REFERENCE_FLANGE_BASE:
        delta_base = offset
        if np.linalg.norm(delta_base) <= _SMALL_OFFSET_M:
            return _ik_position_delta(
                q,
                delta_base,
                q_prior=q,
                max_iters=max_iters,
                damping=damping,
                null_gain=0.0,
                orientation_weight=1.0,
            )
        return _ik_stepped_cartesian_delta(
            q,
            delta_base,
            max_iters=max_iters,
            damping=damping,
            orientation_weight=1.0,
        )

    tip_m = float(gripper_tip_offset_m)
    delta_base = flange_frame_vector_to_base(q, offset)
    if np.linalg.norm(delta_base) <= _SMALL_OFFSET_M:
        return _ik_tip_position_delta(
            q,
            delta_base,
            gripper_tip_offset_m=tip_m,
            q_prior=q,
            max_iters=max_iters,
            damping=damping,
            null_gain=null_gain,
        )
    return _ik_stepped_tip_delta(
        q,
        delta_base,
        gripper_tip_offset_m=tip_m,
        max_iters=max_iters,
        damping=damping,
    )


def clip_joints_to_ee_floor(
    q7: np.ndarray,
    floor_z: float,
    *,
    q_reference: np.ndarray | None = None,
    gripper_tip_offset_m: float = DEFAULT_GRIPPER_TIP_OFFSET_M,
    clearance_fn: ClearanceFn | None = None,
    z_margin_m: float = 0.001,
    max_raise_m: float = _FLOOR_MAX_RAISE_PER_CALL_M,
    max_iters: int = 16,
) -> tuple[np.ndarray, bool]:
    """Clamp the fingertip to ``floor_z`` (m) by raising it in base +Z, holding orientation.

    Lifting the flange in base +Z (orientation held) raises the fingertip by the same amount
    while preserving its X/Y, so horizontal reaching is kept and the gripper does not tilt.
    The rise is capped at ``max_raise_m`` per call; since the guard runs every control tick,
    deeper penetrations recover over a few ticks with bounded per-tick joint motion.

    ``q_reference`` is accepted for backward compatibility and is no longer needed — the raise
    is a small local move from the target, so it stays on the target's IK branch.
    """
    del q_reference  # retained for API compatibility
    q_target = np.asarray(q7, dtype=np.float64).reshape(7).copy()
    clearance = make_tip_clearance_fn(gripper_tip_offset_m, clearance_fn)
    min_z = floor_z + z_margin_m

    tip_z = clearance(q_target)
    if tip_z >= min_z - _FLOOR_CLIP_TOL_M:
        return q_target, False

    # Raise at most ``max_raise_m`` this tick (but never past the floor). Iterate so the
    # measured clearance converges even when ``clearance_fn`` (e.g. libfranka FK) differs
    # slightly from the Python FK used to drive the joints.
    target_z = min(tip_z + max(0.0, float(max_raise_m)), min_z)
    q_clip = q_target
    for _ in range(4):
        z = clearance(q_clip)
        if z >= target_z - _FLOOR_CLIP_TOL_M:
            break
        q_clip = _ik_position_delta(
            q_clip,
            (0.0, 0.0, target_z - z),
            q_prior=q_clip,
            max_iters=max_iters,
            null_gain=0.0,
            orientation_weight=_Z_ORIENTATION_WEIGHT,
        )

    clipped = not np.allclose(q_clip, q_target, atol=1e-5, rtol=0.0)
    return q_clip, clipped


def parse_offset_xyz(
    offset_x: float | None = None,
    offset_y: float | None = None,
    offset_z: float | None = None,
) -> tuple[float, float, float]:
    ox = 0.0 if offset_x is None else float(offset_x)
    oy = 0.0 if offset_y is None else float(offset_y)
    oz = 0.0 if offset_z is None else float(offset_z)
    return ox, oy, oz


def parse_offset_reference(offset_reference: str | None = None) -> str:
    ref = DEFAULT_OFFSET_REFERENCE if offset_reference is None else str(offset_reference).strip().lower()
    if ref not in VALID_OFFSET_REFERENCES:
        raise ValueError(f"offset_reference must be one of {VALID_OFFSET_REFERENCES}")
    return ref
