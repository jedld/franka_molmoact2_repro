# MolmoAct2 Control Findings for Real Franka

This document summarizes control-path issues in `motion_server_molmoact2.py` and related hardware execution code that can cause incorrect robot behavior on a **real Franka** (via `motion_server.cpp` + HTTP proxy), even when the MolmoAct2 inference API is healthy.

Scope:
- Real robot path (`hardware_molmoact2_runner.py` + `motion_server_cpp_proxy.py`)
- MolmoAct2-DROID policy integration (`/act` and `/act_dual`)
- Behavior-affecting execution semantics after inference (not model quality itself)

Out of scope:
- Full camera extrinsic calibration procedure
- Fine-tuning/adaptation of MolmoAct2 checkpoints

---

## Executive Summary

The inference request/response wiring is mostly correct for MolmoAct2-DROID, but several execution-layer behaviors can materially degrade real-robot performance:

1. Arm motion is gated by binary gripper settling, which breaks coordinated arm+gripper motion.
2. Gripper commands are binarized and threshold handling is inconsistent with C++ comments/UI expectations.
3. Grasp integration (enabled by default) replaces policy close actions with a long blocking macro.
4. Floor clipping and per-tick rate-limiting alter action trajectories from policy intent.
5. USB camera snapshots on hardware can be stale and not temporally aligned with state.
6. Default open-loop chunk execution amplifies drift on hardware.

The largest practical risk on real Franka is not HTTP/API formatting; it is mismatch between policy intent and downstream control semantics.

---

## System Context (Real Franka Path)

Control flow on hardware:
1. USB camera manager provides policy images.
2. Current 9-DOF robot state is read (`q1..q7 + finger widths`).
3. State is converted to 8-D DROID format (`q1..q7 + normalized gripper`).
4. Inference request is sent to MolmoAct2 server.
5. Returned 8-D actions are converted to 9-DOF hardware targets.
6. `motion_server_cpp_proxy.py` ramps/limits arm targets and publishes gripper commands.

Key consequence: most behavior differences from DROID deployment arise in steps 5-6.

---

## Findings (Prioritized for Real Franka)

## 1) Arm Motion Is Blocked Until Gripper Is Settled

**Severity:** Critical  
**Where:** `motion_server_policy_gripper.py`, used by both proxy and controller path

The arm target is only applied when gripper state is considered "ready." On close/open transitions the system first publishes a binary gripper command and returns `False`, delaying arm movement.

Impact on real Franka:
- Breaks policy’s intended coordinated arm+gripper timing.
- Causes visible pauses/hiccups near grasp events.
- Increases miss rates when object approach and finger closure must overlap.

Why this matters on hardware:
- Real gripper latency and contact variability are significant.
- Gating can hold arm motion for many ticks (~3 s by default on close-assume path).

---

## 2) Continuous Policy Gripper Is Collapsed to Binary Commands

**Severity:** High  
**Where:** `motion_server_droid_units.py` (`actions8_to_q9`)

Policy gripper output is binarized using `GRIPPER_CLOSE_THRESHOLD = 0.4`, then mapped to fully open/closed width.

Impact on real Franka:
- Any nuanced intermediate gripper command from policy is discarded.
- Near-threshold jitter produces unstable open/close behavior.
- Combined with gating, this can create stop-go arm motion.

Additional inconsistency:
- C++ side `syncPolicyGripper` close threshold logic uses `> 0.5`.
- UI/help text references `> 0.5` semantics.
- Python policy path uses `0.4`.

This mismatch increases debugging ambiguity and can cause inconsistent close/open decisions across code paths.

---

## 3) Default Grasp Integration Replaces Policy Close with Blocking Macro

**Severity:** High  
**Where:** `motion_server_molmoact2.py` (`_run_chunk_grasp`), `motion_server_grasp.py`

When an open->close edge is detected in a chunk, the controller may run a "poke-and-grab" macro:
- move to approach pose,
- advance along tool axis,
- force close,
- retract,
- truncate remaining chunk and re-observe.

Impact on real Franka:
- Substitutes policy behavior with a hand-crafted sequence.
- Adds multi-second blocking actions and resets stream context.
- Can improve gripping with stock Franka hand in some cases, but often harms trajectory continuity and timing.

Operational risk:
- If camera/state timing is already degraded, this macro can compound error by acting on stale scene assumptions.

---

## 4) Hardware Rate Limiting and Anti-Windup Distort Absolute Action Tracking

**Severity:** High  
**Where:** `motion_server_cpp_proxy.py` (`_MAX_JOINT_STEP_RAD`, `_MAX_TARGET_LEAD_RAD`)

On hardware, each policy step is rate-limited/ramped toward target. This is a safety/stability choice, but it means returned absolute actions are not followed exactly in one tick.

Impact on real Franka:
- Action chunk can be consumed while robot remains behind commanded targets.
- In async mode this lag accumulates before re-observation.
- Real robot diverges from what policy "expects" happened during chunk rollout.

This effect is stronger on hardware than Isaac sim due to physical dynamics and stream timing.

---

## 5) Floor Clipping (Enabled by Default) Alters Table-Region Behavior

**Severity:** Medium-High  
**Where:** `motion_server_molmoact2.py` + handler/proxy floor clip path

EE floor guard is enabled by default with static Z threshold. If not calibrated to real table/scene geometry, commanded approach poses can be clipped.

Impact on real Franka:
- Robot hovers above grasp point or fails to descend enough.
- Perceived as "policy refuses to pick" even with good vision.
- Can trigger stall heuristics and contact-recovery behaviors.

---

## 6) Hardware USB Observations Can Be Stale / Not Synchronized

**Severity:** Medium-High  
**Where:** `motion_server_usb_cameras.py` (`capture_policy_observation`)

Hardware snapshots are taken from latest background caches (non-blocking by design). This avoids server stalls, but:
- camera views may be from slightly different capture instants,
- image timestamp may not match current robot state read used for inference,
- during motion, policy can infer from stale visual context.

Impact on real Franka:
- Regrasp/release oscillations,
- delayed corrections,
- missed contact alignment.

---

## 7) Open-Loop Chunk Defaults Are Aggressive for Real Robot

**Severity:** Medium  
**Where:** `motion_server_molmoact2.py` (`execution_mode=async`, `chunk_horizon=15`)

Default behavior executes long action chunks open-loop with settle logic, then re-observes. This is fragile on real hardware with gripper delays, rate limits, and scene changes.

Impact on real Franka:
- Drift grows before correction.
- Chunk steps can advance on timeout even if not truly settled.
- Performance degrades most near contact-rich manipulation.

---

## Why This Looks Fine in Sim but Fails on Hardware

Common reasons:
- Sim path has different actuation/latency profile than libfranka stream.
- Hardware gripper dynamics are slower and more variable than simulated finger closure.
- Camera timing and calibration differences are much larger on USB + real scene.
- Policy was trained with DROID assumptions (camera geometry + gripper embodiment), while deployment here adds several control-layer substitutions.

---

## Recommended Mitigation Order (Real Franka)

1. **Stabilize semantics first**
   - Use one gripper threshold convention everywhere (pick 0.4 or 0.5 and unify).
   - Document policy-to-hardware gripper mapping explicitly in UI and API docs.

2. **Reduce intervention**
   - Temporarily disable grasp integration and floor clipping during baseline tests.
   - Validate pure policy behavior first, then re-enable one feature at a time.

3. **Prefer tighter feedback**
   - Use `sync` mode or `auto` with conservative threshold near table.
   - Reduce `chunk_horizon` (e.g., 3-5) for hardware trials.

4. **Improve observation/state coherence**
   - Add per-inference timestamps for image batch + robot state read.
   - Track and alert on stale frame age in control status.

5. **Instrument for diagnosis**
   - Keep debug recording on during trials.
   - Correlate failures with: gripper transition events, clip counts, settle timeouts, and fetch latency.

---

## Suggested Acceptance Checks (Before Task Benchmarking)

Run these checks on real Franka before evaluating task success:

1. **Gripper transition consistency:** repeated open/close commands produce consistent arm behavior (no prolonged arm freeze).
2. **Approach depth:** robot can reach grasp height without unintended floor clips.
3. **State/image freshness:** measured latency from capture to command stays within target budget.
4. **Chunk tracking:** max joint error remains bounded under chosen mode/horizon.
5. **Recovery stability:** contact recovery does not loop or silently resume into stale context.

---

## Bottom Line

For real Franka deployment, the major failure drivers are control-layer semantics after inference (gripper gating, action post-processing, chunk execution strategy, and observation timing), not the MolmoAct2 HTTP contract itself. Addressing these execution mismatches should yield larger gains than model-side tuning alone in the current integration.

---

## Significance for Static Pick-and-Place

A **static environment** (fixed table, fixed cameras, non-moving objects) reduces sensitivity to moving obstacles and scene change, but does **not** remove contact, timing, or execution-semantics issues.

| Phase | Static scene helps? | Control issues that still bite |
|-------|---------------------|--------------------------------|
| Reach above table | Somewhat | Rate limit, chunk length |
| Descend to object | No | Floor clip, gripper gating, rate limit |
| Close / grasp | No | Gating, binary gripper, grasp macro |
| Lift | Somewhat | Stale cam (wrist), stall detection |
| Transit to place | Somewhat | Open-loop drift |
| Place / open | No | Gating, binary gripper |

**Severity for static table PnP:**

| Rank | Issue | Significance |
|------|--------|--------------|
| 1 | Floor clipping miscalibrated | Critical — blocks pick entirely |
| 2 | Gripper gating at close/open | High — directly affects grasp and release |
| 3 | Open-loop async + long horizon | High — misalignment at grasp/place |
| 4 | Grasp integration (default on) | High impact, mixed sign — test on/off |
| 5 | Rate limiting / tracking lag | Medium–High near contact |
| 6 | Stale USB observations | Medium — worse during motion than at rest |
| 7 | Binary gripper / threshold 0.4 vs 0.5 | Low–Medium |

Coarse motion may look reasonable while pick/place still fails intermittently unless floor height, execution mode/horizon, and grasp-phase behavior are tuned.

---

## Concrete Fix Plan

Prioritized by impact vs effort for **real Franka static pick-and-place**. Each item names files, the change, and how to validate.

### Phase 0 — No Code (Immediate Trial Settings)

Run hardware with a PnP preset before changing code:

```bash
python3 hardware_molmoact2_runner.py \
  --instruction "Pick up the apple and place it on the plate" \
  --execution-mode auto \
  --sync-below-z 0.18 \
  --chunk-horizon 4 \
  --external-camera-mode duplicate \
  --molmoact2-url http://localhost:8101
```

Also configure via HTTP before start:

```json
{
  "ee_floor_enabled": true,
  "ee_floor_z": 0.0,
  "gripper_tip_offset_m": 0.1034,
  "grasp_integration_enabled": false,
  "execution_mode": "auto",
  "chunk_horizon": 4
}
```

Set `ee_floor_z` to the **measured table surface Z in base frame** (not the default `0.05` guess).

**Validate:** Arm reaches object height; no hover-above-table; re-infer every 1–2 steps near contact.

---

### Phase 1 — High Impact, Small Diffs

#### Fix 1: Parallel Arm + Gripper (Stop Blocking Arm on Gripper Settle)

**Problem:** `apply_policy_joint_targets_binary` refuses arm commands until gripper settles.

**Change:** Add a coordinated apply path in `motion_server_policy_gripper.py`:

```python
def apply_policy_joint_targets_coordinated(
    handler: Any,
    q9: np.ndarray,
    tracker: PolicyGripperTracker,
) -> bool:
    """Always stream arm; publish gripper when binarized target changes."""
    desired_closed = desired_closed_from_q9(q9)
    if tracker.last_commanded_closed != desired_closed:
        _publish_binary_gripper(handler, desired_closed, q9[:7])
        tracker.last_commanded_closed = desired_closed
        tracker.unsettled_ticks = 0
    apply_policy_arm_targets(handler, q9)
    return True  # never block arm ticks
```

Use this in `motion_server_cpp_proxy.py` and `motion_server_http_robot.py` instead of `apply_policy_joint_targets_binary`.

Keep settle checks in `motion_server_molmoact2.py` (`_sync_step_settled`) for **when to advance the chunk**, not for **whether to send arm commands**.

**Validate:** No 1–3 s arm freeze at close; wrist cam shows continuous descent during close.

---

#### Fix 2: Unify Gripper Threshold to 0.5

**Problem:** Python uses `0.4`, C++ `syncPolicyGripper` and UI use `0.5`.

**Changes:**

1. `motion_server_droid_units.py`: `GRIPPER_CLOSE_THRESHOLD = 0.5`
2. `motion_server_policy_gripper.py`: remove duplicate `droid_gripper_binary_value`; import from `motion_server_droid_units`
3. `motion_server.cpp` line ~1180: keep `> 0.5` (already aligned)

**Validate:** Same open/close decision from policy action, Python path, and C++ gripper sync.

---

#### Fix 3: Use Continuous Gripper Width in Action Conversion

**Problem:** `actions8_to_q9` binarizes before width mapping, discarding policy gradations.

**Change in** `motion_server_droid_units.py`:

```python
# Before (binary):
width_m = droid_gripper_to_width_m(droid_gripper_binary_value(float(a[7])))

# After (continuous command, binarize only for settle classification):
width_m = droid_gripper_to_width_m(float(a[7]))
```

Keep binarization only in `desired_closed_from_q9` / settle logic (threshold 0.5).

**Validate:** Gripper partially closes on intermediate policy values; fewer open↔close flips near threshold.

---

#### Fix 4: Hardware-Friendly Defaults in `hardware_molmoact2_runner.py`

**Change defaults:**

| Flag | Current | Proposed |
|------|---------|----------|
| `--execution-mode` | `async` | `auto` |
| `--chunk-horizon` | `15` | `4` |
| `--sync-below-z` | `0.15` | `0.18` |
| `--external-camera-mode` | `single` | `duplicate` |

Add CLI flags:

```bash
--grasp-integration / --no-grasp-integration   # default: off
--ee-floor-z FLOAT                             # required for floor guard
--no-ee-floor                                  # disable clip entirely
```

On startup, if `ee_floor_enabled` and `ee_floor_z` is still default `0.05`, print a warning.

**Validate:** New users get PnP-safer defaults without reading this document.

---

#### Fix 5: Fresh USB Capture at Inference Time

**Problem:** `capture_policy_observation` reads stale background cache.

**Change in** `motion_server_usb_cameras.py`:

```python
def capture_policy_observation(...):
    with self._capture_lock:
        batch_id = self._capture_once(flush_buffered=True)
    if batch_id is None:
        return None
    # ... existing pack_policy_images logic using fresh cache ...
```

**Change in** `motion_server_molmoact2.py` (tick or fetch worker): capture images, then immediately read `q9` and build `state8` in one snapshot function:

```python
def capture_policy_observation_with_state(handler, ...):
    obs = cameras.capture_policy_observation(...)
    q9 = handler.get_joint_positions_q9()  # ms after images
    return obs, state8_from_q9(q9)
```

**Validate:** Log `frame_age_ms` and `state_capture_delta_ms`; both should be `< 100 ms` at inference start.

---

### Phase 2 — Medium Effort, Strong PnP Gains

#### Fix 6: Disable Floor Clip Until Calibrated (Hardware-Only)

**Problem:** `DEFAULT_EE_FLOOR_ENABLED = True` with wrong Z blocks picks.

**Option A — global default:**

```python
# motion_server_action_offset.py
DEFAULT_EE_FLOOR_ENABLED = False  # opt-in after calibration
```

**Option B — split sim vs hardware defaults** in `motion_server_molmoact2.py` / `hardware_molmoact2_runner.py`.

Add a one-shot calibration helper (new script `calibrate_ee_floor.py`):

1. Jog arm until fingertip touches table
2. Read `readState()` Z (or FK tip Z)
3. Print recommended `ee_floor_z = tip_z - 0.002` (2 mm clearance)

**Validate:** Without calibration, robot reaches table; with calibration, no table collision.

---

#### Fix 7: Grasp Integration — Opt-In + Height Gate

**Problem:** Default macro hijacks every open→close transition.

**Changes:**

1. `MolmoAct2Status.grasp_integration_enabled: bool = False` (default off)
2. Only run `_run_chunk_grasp` when **both**:
   - open→close edge detected, and
   - `effective_ee_tip_z(q7) <= grasp_integration_max_z` (new config, default `0.12` m)

Above-table transits keep pure policy; near-table picks use macro if enabled.

**Validate:** A/B test pick success with macro off (baseline) vs on (small objects only).

---

#### Fix 8: Do Not Advance Async Steps on Settle Timeout Unless Close Enough

**Problem:** After 5 s timeout, chunk advances even with large joint error → open-loop drift.

**Change in** `_tick_async_open_loop` (`motion_server_molmoact2.py`):

```python
if timed_out and not settled:
    err = self._joint_settle_error_rad(q9, target_q9)
    if err > SYNC_JOINT_SETTLE_TOL_RAD * 3:  # e.g. > 0.06 rad
        self._action_chunk = None
        self._action_idx = 0
        log_event("molmoact2", f"async step abandoned (err={err:.3f}) — re-observing")
        return
    # else: soft timeout, advance
```

**Validate:** Fewer “close in wrong place” failures; more frequent re-inference near contact.

---

#### Fix 9: Rate Limit Aligned with libfranka Servo

**Problem:** `_MAX_JOINT_STEP_RAD = 0.08` at 15 Hz implies 1.2 rad/s; C++ servo caps ~0.5 rad/s.

**Change in** `motion_server_cpp_proxy.py`:

```python
CONTROL_HZ = 15.0
SERVO_MAX_VEL_RAD_S = 0.5
_MAX_JOINT_STEP_RAD = SERVO_MAX_VEL_RAD_S / CONTROL_HZ  # ~0.033
```

**Validate:** Commanded vs measured joint error stops growing monotonically through a chunk in async mode.

---

### Phase 3 — Optional Polish

#### Fix 10: Prefetch Next Chunk During Last N Async Steps

When `action_idx >= len(chunk) - 2`, start GPU fetch in background while finishing settle on last steps. Cuts dead time between chunks without overlapping execution on stale observations.

**Where:** `motion_server_molmoact2.py` — extend `_maybe_start_fetch` guard to allow fetch when `remaining_steps <= 2` and arm is settled.

> ⚠️ **Reverted — do not implement.** MolmoAct2-DROID returns **absolute** joint targets tied to
> the observation instant. Prefetching at `len(chunk) - 2` observes the scene two steps early; by
> the time that chunk is loaded the arm has moved two steps further, so its first absolute target
> pulls the arm **back** to the older pose — a visible "bob back up" during descent. There is no
> safe prefetch for an absolute-action policy (it would require relative/delta actions). Inference
> must only start **after** the current chunk fully completes. The guard in `_maybe_start_fetch`
> enforces this and `test_molmoact2_fixes.py::AsyncNoMidChunkPrefetch` locks it in.

---

#### Fix 11: Expose Staleness in Status API

Add to `MolmoAct2Status`:

- `last_obs_frame_age_ms`
- `last_obs_state_skew_ms`
- `last_max_joint_tracking_err_rad`

Surface in web UI so operators see why picks fail.

---

#### Fix 12: `hardware_pnp` Preset in Configure API

```json
POST /api/molmoact2/configure
{ "preset": "hardware_pnp" }
```

Applies: `auto`, `chunk_horizon=4`, `grasp_integration=false`, `ee_floor` unchanged unless set.

---

### Recommended Implementation Order

| Order | Fix | Effort | PnP impact |
|-------|-----|--------|------------|
| 1 | Parallel arm+gripper (Fix 1) | ~50 lines | Critical |
| 2 | Hardware defaults + CLI (Fix 4) | ~30 lines | High |
| 3 | Fresh USB capture + state pairing (Fix 5) | ~40 lines | High |
| 4 | Threshold 0.5 + continuous width (Fix 2–3) | ~20 lines | Medium |
| 5 | Floor opt-in + cal script (Fix 6) | ~80 lines | High |
| 6 | Grasp opt-in + height gate (Fix 7) | ~30 lines | Medium |
| 7 | Async abandon on large error (Fix 8) | ~15 lines | Medium |
| 8 | Rate limit tune (Fix 9) | ~5 lines | Low–Medium |

Fixes **1, 4, 5, and 6** alone should address most static PnP failures without retraining the policy.

---

### Acceptance Tests After Fixes

1. **Approach test:** Open gripper, descend toward object — arm never freezes > 200 ms.
2. **Pick test:** 10 trials, small rigid object — ≥7/10 successful lifts with grasp integration off.
3. **Place test:** Open at place, retreat — no 3 s stall after release.
4. **Tracking test:** Log max joint error during sync phase — stays below 0.04 rad before close.
5. **Freshness test:** `frame_age_ms < 80` at every inference.

---

## Diagnostic Logging Guide

How to use existing logging, what to add for deeper diagnosis, and how to interpret output against the findings above. Focus: **real Franka + `hardware_molmoact2_runner.py`**.

### Quick start (no code changes)

Run the hardware loop with timing logs enabled (default on) and capture stdout:

```bash
export MOLMO_TIMING_LOG=1          # default; set 0 to silence
export MOLMO_SLOW_S=0.15           # log ticks slower than 150 ms (default 0.25)
export MOLMOACT2_DEBUG_DIR=/tmp/franka_molmoact2/molmoact2_debug

python3 hardware_molmoact2_runner.py \
  --instruction "Pick up the apple and place it on the plate" \
  ... 2>&1 | tee molmoact2_run_$(date +%Y%m%d_%H%M%S).log
```

Enable **debug mode** so every GPU fetch writes images + state + actions to disk:

**Web UI:** MolmoAct2 panel → check **Debug mode** → Configure → Start.

**HTTP API:**

```bash
curl -s -X POST http://127.0.0.1:34568/api/molmoact2/configure \
  -H 'Content-Type: application/json' \
  -d '{
    "debug_mode": true,
    "execution_mode": "auto",
    "chunk_horizon": 4,
    "grasp_integration_enabled": false
  }'
```

Poll status during a run:

```bash
watch -n 0.5 'curl -s http://127.0.0.1:34568/api/molmoact2/status | python3 -m json.tool'
```

---

### Built-in logging surfaces

| Surface | Module | What it records |
|---------|--------|-----------------|
| `[molmoact2]` events | `motion_server_timing_log.py` | Lifecycle, fetch, settle, grasp, contact |
| `[molmoact2] slow …` | same | Policy ticks > `MOLMO_SLOW_S` |
| `[cpp_proxy] slow …` | `motion_server_cpp_proxy.py` | HTTP round-trips to `motion_server.cpp` |
| `[molmoact2 debug]` | `motion_server_molmoact2_debug.py` | Per-chunk folder path on disk |
| `GET /api/molmoact2/status` | `motion_server_api.py` | Live counters, errors, offset/floor config |

**Debug session layout** (`MOLMOACT2_DEBUG_DIR/session_*/chunk_NNNN/`):

| File | Contents |
|------|----------|
| `input_external_cam.png` | Exterior RGB sent to model |
| `input_wrist_cam.png` | Wrist RGB sent to model |
| `input_external_cam_2.png` | Second exterior (dual/duplicate only) |
| `input_state.txt` | `state8` at fetch time (joints + DROID gripper) |
| `meta.json` | Endpoint, `fetch_elapsed_s`, `dt_ms`, errors |
| `response_actions.csv` | Full action chunk (15×8 or trimmed) |
| `response.json` | Parsed model response |

Use debug folders to answer: *What did the policy see? What did it command?* Compare `chunk_N` images to the physical scene at that moment.

---

### Status fields to watch

Key fields from `GET /api/molmoact2/status` and how to read them:

| Field | Healthy pattern | Concerning pattern |
|-------|-----------------|-------------------|
| `running` | `true` during trial | `false` with `last_error` set |
| `execution_mode` / `auto_active_mode` | `auto` + `sync` near table | Stuck in `async` while tip is low |
| `action_idx` / `chunk_size` | Advances, resets after chunk | `action_idx` stuck; `chunk_size` > 0 but no motion |
| `fetching` | Brief `true` during GPU call | `true` for many seconds (GPU hang) |
| `consecutive_fetch_failures` | `0` | ≥ 1 — check inference server / network |
| `last_fetch_s` | Stable after warmup | Very large every tick → inference bottleneck |
| `last_dt_ms` | GPU inference only | N/A |
| `ee_floor_clips` | Low or 0 during approach | Rising rapidly near table → floor too high or wrong `gripper_tip_offset_m` |
| `ee_floor_last_tip_z` | Above object, drops near grasp | Stays above object while policy commands descend → need calibration or offset |
| `grasp_sequences` | 0 if macro disabled | Increments at every pick attempt → macro is hijacking closes |
| `offset_x/y/z`, `offset_mode` | Document what you tuned | Large offsets (> 2–3 cm) → systematic calibration gap |
| `paused_contact` / `recoverable` | `false` during normal run | `true` → contact/stall recovery fired |
| `debug_session_dir` | Path when debug on | Empty → debug not enabled |
| `last_error` | Empty | Read first — usually points to root cause |

---

### Interpreting `[molmoact2]` log lines by finding

#### Finding 1 — Gripper gating blocks arm

**Look for:**

```
[molmoact2] gripper not settled (N ticks, action_idx=K)
[molmoact2] slow tick (gripper wait) ...
[molmoact2] gripper settled after N wait ticks
[molmoact2] gripper grasp assumed after N ticks (width=0.0XXX m) — continuing arm
```

| Pattern | Interpretation |
|---------|----------------|
| Many `gripper not settled` lines at same `action_idx` | Arm frozen while fingers move — classic gating issue |
| `grasp assumed after 45 ticks` | Close command timed out; arm continued without full close — may grasp air or slip |
| `gripper wait` + slow tick > 1 s | Pick phase dominated by gripper, not policy motion |

**Correlate with debug chunk:** At that `action_idx`, check `response_actions.csv` column `gripper` — if arm joints change but robot doesn’t move until gripper column flips, gating is the bottleneck.

---

#### Finding 2 — Binary gripper / threshold

**Look for:** Rapid alternation of open/close at one `action_idx`, or gripper column in CSV hovering around `0.4–0.6`.

**Check:** `input_state.txt` gripper value vs commanded `gripper` in first rows of `response_actions.csv`. Large jumps (0.1 → 0.9) in one step are normal after binarization; values stuck near 0.45 mean threshold ambiguity.

---

#### Finding 3 — Grasp integration macro

**Look for:**

```
[molmoact2] grasp integration: open->close at action_idx=K — poke-and-grab (advance=0.0XX m)
[molmoact2] grasp integration: poke-and-grab complete — re-observing
[molmoact2] grasp integration: advance is 0 at action_idx=K; applying commanded close instead
```

| Pattern | Interpretation |
|---------|----------------|
| Macro fires every trial | `grasp_integration_enabled=true` — policy close replaced |
| Long gap between macro start and `complete` | 5+ s blocking; watch for object shift / stale scene |
| `grasp_sequences` increments in status | Count macro invocations per session |

---

#### Finding 4 — Rate limiting / tracking lag

**Look for:**

```
[molmoact2] async step pursuing target (N ticks, action_idx=K, max_joint_err=0.XXX rad)
[molmoact2] async step settle timeout (5.0s, max_joint_err=0.XXX rad) — advancing action_idx=K
[cpp_proxy] slow setJointPose: ...
```

| `max_joint_err` | Interpretation |
|-----------------|----------------|
| < 0.02 rad | On target — good |
| 0.03–0.08 rad | Lagging — rate limit or contact |
| > 0.10 rad at timeout | Step advanced anyway — open-loop drift; policy state no longer matches robot |

**Diagnosis:** Compare `response_actions.csv` row `K` joint values to `readJointState` after the step (manual query or add logging). Large delta → need shorter horizon or sync mode.

---

#### Finding 5 — Floor clipping

**Look for:** `ee_floor_clips` increasing in status (poll with `watch`).

No dedicated log line today — **infer from:**

- `ee_floor_last_tip_z` not decreasing when policy commands lower poses
- Arm hovers; exterior debug image shows gripper above object
- You needed **negative Z offset** to reach object → floor or tip offset miscalibrated

**Add (recommended) one log in `_apply_action_postprocess_to_q9` when `clipped` is true:

```python
log_event("molmoact2", f"ee_floor clip (tip_z={tip_z:.4f} floor={floor_z:.4f})")
```

---

#### Finding 6 — Stale USB observations

**Look for:**

```
[molmoact2] waiting for camera frames (N policy ticks, slot=... mode=...)
[molmoact2] cameras ready after N wait ticks
```

| Pattern | Interpretation |
|---------|----------------|
| Long camera wait at start | USB cameras not streaming |
| No wait, but picks miss | Stale cache — images old while arm moved (no freshness metric yet) |

**Workaround today:** Compare consecutive `input_*.png` in debug session — if background/object alignment drifts across chunks while the scene is static, observation timing is wrong.

**Add (Fix 5):** Log at fetch start:

```python
log_event("molmoact2", f"obs frame_age_ms={age_ms:.0f} state_skew_ms={skew_ms:.0f}")
```

---

#### Finding 7 — Open-loop chunk / async defaults

**Look for:**

```
[molmoact2] chunk #N loaded shape=(15, 8) steps_to_run=15 ...
[molmoact2] chunk horizon=15: executing first 15 of N GPU actions (discarded ...)
[molmoact2] chunk complete (15/15 steps settled) — next tick re-observes
[molmoact2] awaiting GPU chunk (N policy ticks, fetch in flight)
```

| Pattern | Interpretation |
|---------|----------------|
| `steps_to_run=15` on hardware | Long open-loop — high drift risk |
| Long `awaiting GPU chunk` | Dead time between chunks; arm holds last target |
| `GPU fetch skipped: chunk in progress` | Expected during chunk — no overlapping inference |

**Mitigation visible in logs:** After switching to `chunk_horizon=4` or `auto`+`sync`, you should see `steps_to_run=4` and more frequent `GPU fetch #N started`.

---

#### Offset tuning (your X/Y/Z workaround)

When manual offsets are required, log the active config at **start**:

```
[molmoact2] start → running server=... mode=... horizon=... cameras=...
```

Plus status fields `offset_x/y/z`, `offset_mode`, `offset_reference`.

| Symptom | Likely cause | What to check in debug artifacts |
|---------|--------------|----------------------------------|
| Need negative Z only | Floor clip or tip offset | `ee_floor_clips`, `ee_floor_last_tip_z`, approach images |
| Need X/Y constant | Camera extrinsics / viewpoint | Compare `input_external_cam.png` to physical layout |
| Offsets work in `continuous` but not `final` | Error is per-step, not final-pose only | `response_actions.csv` — drift grows through chunk |
| Offsets large (> 2 cm) | Embodiment gap (Robotiq vs Franka Hand) | Expect some residual even after control fixes |

Record offset values in the trial log filename or a sidecar `trial_config.json` so debug sessions are comparable.

---

### Useful grep patterns on captured logs

```bash
# Gripper / arm stalls
rg 'gripper not settled|gripper wait|grasp assumed' molmoact2_run.log

# Tracking / drift
rg 'max_joint_err|settle timeout|async step pursuing' molmoact2_run.log

# Grasp macro
rg 'grasp integration' molmoact2_run.log

# Inference / cameras
rg 'GPU fetch|awaiting GPU|camera frames|fetch failed' molmoact2_run.log

# Contact / recovery
rg 'contact detected|collision recovery|policy stream' molmoact2_run.log

# Slow HTTP to robot
rg '\[cpp_proxy\] slow' molmoact2_run.log
```

---

### Recommended additional logging (Fix 11)

Not all metrics exist in status yet. Highest-value additions for this document’s findings:

| Metric | Where to log | Maps to finding |
|--------|--------------|-----------------|
| `max_joint_err_rad` per step | `_tick_async_open_loop` / `_tick_sync` on settle | 4, 7 |
| `gripper_width_m`, `desired_closed`, `arm_applied` | `apply_policy_joint_targets_*` return path | 1, 2 |
| `ee_floor clip` with tip Z | `_apply_action_postprocess_to_q9` | 5 |
| `frame_age_ms`, `rgb_batch_id` | `_maybe_start_fetch` worker start | 6 |
| `effective_execution_mode` on mode switch | `_on_auto_mode_switch` (already prints) | 7 |
| `grasp_at_idx` when chunk loads | `_consume_pending_chunk` (partial — in chunk loaded line) | 3 |

Example structured one-liner to add after each applied step:

```python
log_event(
    "molmoact2",
    f"step action_idx={self._action_idx} mode={self._effective_execution_mode} "
    f"joint_err={err:.4f} gripper_w={width_m:.4f} "
    f"tip_z={tip_z:.4f} floor_clips={self._status.ee_floor_clips}",
)
```

Expose rolling maxima on `MolmoAct2Status` for the web UI.

---

### Diagnostic workflow (one failed pick)

1. **Reproduce with debug on** — one failed pick, then stop.
2. **Read `last_error`** in status — inference vs motion vs contact.
3. **Open last `chunk_NNNN/`** — do images show the object? Is gripper above/beside it?
4. **Read `response_actions.csv`** — find first row where `gripper` crosses ~0.5; note joint row.
5. **Grep the log** around `grasp integration`, `gripper not settled`, `max_joint_err`, `settle timeout`.
6. **Check status counters** — `ee_floor_clips`, `grasp_sequences`, `steps_applied` vs `chunks_fetched`.
7. **Classify root cause:**

| Evidence | Likely finding |
|----------|----------------|
| Many gripper wait lines before close | #1 Gripper gating |
| `max_joint_err` high at timeout | #4 Rate limit / #7 open-loop |
| `ee_floor_clips` rising, tip above object | #5 Floor calibration |
| Images misaligned with scene | #6 Stale cam / # extrinsics (offsets) |
| Grasp macro in log, odd motion at pick | #3 Grasp integration |
| Steady XY error in images, fixed offset fixes it | Camera layout / calibration (offsets) |

8. **Change one variable** (mode, horizon, floor Z, grasp off, offset) and re-run with a new debug session for comparison.
