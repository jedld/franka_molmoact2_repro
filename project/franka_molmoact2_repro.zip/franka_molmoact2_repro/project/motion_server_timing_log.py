# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Lightweight timing / lifecycle logging for hardware MolmoAct2 diagnostics."""

from __future__ import annotations

import os
import threading

ENABLED = os.environ.get("MOLMO_TIMING_LOG", "1").lower() not in ("0", "false", "no")
SLOW_S = float(os.environ.get("MOLMO_SLOW_S", "0.25"))


def log_event(tag: str, message: str) -> None:
    if ENABLED:
        print(f"[{tag}] {message}", flush=True)


def log_slow(tag: str, label: str, elapsed_s: float, **extra: object) -> None:
    if not ENABLED or elapsed_s < SLOW_S:
        return
    parts = [f"[{tag}] slow {label}: {elapsed_s:.3f}s"]
    for key, value in extra.items():
        parts.append(f"{key}={value}")
    parts.append(f"thread={threading.current_thread().name}")
    print(" ".join(parts), flush=True)
