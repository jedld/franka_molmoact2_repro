# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Shared camera constants and image helpers (Isaac Sim + USB hardware paths)."""

from __future__ import annotations

import io
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Callable

import numpy as np

WristTuneFn = Callable[[np.ndarray], np.ndarray] | None

CAMERA_WIDTH = 320
CAMERA_HEIGHT = 180

# MolmoAct2-DROID wire format (start_molmoact2_3090.md): (H, W, 3) uint8 RGB, C-contiguous.
MOLMOACT2_POLICY_SHAPE = (CAMERA_HEIGHT, CAMERA_WIDTH, 3)

# MolmoAct2 / DROID policy observation rate — only this path runs on the sim thread.
POLICY_CAPTURE_HZ = 15.0

# Web UI JPEGs are encoded lazily on HTTP worker threads (never on the sim thread).
PREVIEW_JPEG_QUALITY = 68


def _to_numpy_cpu(image) -> np.ndarray:
    """Copy annotator output (numpy, warp, torch) to a host ``np.ndarray``."""
    if isinstance(image, np.ndarray):
        return np.asarray(image)
    if hasattr(image, "detach") and hasattr(image, "cpu") and hasattr(image, "numpy"):
        return np.asarray(image.detach().cpu().numpy())
    if hasattr(image, "numpy") and callable(image.numpy):
        return np.asarray(image.numpy())
    try:
        import warp as wp

        if isinstance(image, wp.array):
            return wp.to_numpy(image)
    except ImportError:
        pass
    return np.asarray(image)


def apply_camera_flip(rgb: np.ndarray, flip: str | Iterable[str] | None) -> np.ndarray:
    """Apply optional capture-time flip(s) before policy resize (DROID wrist often needs 180°).

    ``flip`` accepts either:

    * a single mode string (``"rotate_180"``, ``"flip_horizontal"``, ``"flip_vertical"``,
      or one of their aliases listed in :data:`_FLIP_ALIASES`),
    * a chain joined by ``+``, ``,`` or whitespace
      (``"rotate_180+flip_horizontal"`` — apply 180° rotation, then mirror left/right), or
    * an iterable of mode strings.

    Modes are applied in the order given, so a wrist camera that's mounted upside-down *and*
    mirrored can use ``"rotate_180+flip_horizontal"``.
    """
    tokens = _split_flip_tokens(flip)
    if not tokens:
        return rgb
    out = rgb
    changed = False
    for token in tokens:
        canonical = _FLIP_ALIASES.get(token)
        if canonical is None:
            raise ValueError(f"Unknown camera flip mode: {token!r}")
        if canonical == "none":
            continue
        if canonical == "rotate_180":
            out = out[::-1, ::-1, :]
        elif canonical == "flip_vertical":
            out = out[::-1, :, :]
        elif canonical == "flip_horizontal":
            out = out[:, ::-1, :]
        changed = True
    return np.ascontiguousarray(out) if changed else rgb


# Lower-cased flip aliases → canonical mode name. ``"none"`` is a no-op (skipped).
_FLIP_ALIASES: dict[str, str] = {
    "rotate_180": "rotate_180",
    "180": "rotate_180",
    "flip_both": "rotate_180",
    "flip_vertical": "flip_vertical",
    "vertical": "flip_vertical",
    "v": "flip_vertical",
    "flip_horizontal": "flip_horizontal",
    "horizontal": "flip_horizontal",
    "h": "flip_horizontal",
    "none": "none",
    "off": "none",
}


def _split_flip_tokens(flip: str | Iterable[str] | None) -> list[str]:
    """Normalize a flip spec to a list of lowercase mode tokens (``+``/``,``/whitespace separated)."""
    if flip is None:
        return []
    if isinstance(flip, str):
        items: Iterable[str] = (flip,)
    else:
        items = flip
    tokens: list[str] = []
    for item in items:
        if item is None:
            continue
        text = str(item).replace("+", " ").replace(",", " ")
        tokens.extend(tok.lower() for tok in text.split())
    return tokens


def normalize_camera_flip_spec(flip: str | Iterable[str] | None) -> str:
    """Validate ``flip`` and return its canonical ``+``-joined string form (``""`` when no-op).

    Raises :class:`ValueError` for unknown tokens. Useful when loading config files so typos
    fail fast at startup rather than on the first captured frame.
    """
    canonical: list[str] = []
    for token in _split_flip_tokens(flip):
        mode = _FLIP_ALIASES.get(token)
        if mode is None:
            raise ValueError(f"Unknown camera flip mode: {token!r}")
        if mode != "none":
            canonical.append(mode)
    return "+".join(canonical)


def prepare_molmoact2_image(
    image,
    *,
    expected_shape: tuple[int, int, int] | None = MOLMOACT2_POLICY_SHAPE,
) -> np.ndarray:
    """Normalize a frame to MolmoAct2-DROID wire format: C-contiguous ``(H, W, 3) uint8`` RGB."""
    arr = _to_numpy_cpu(image)

    if arr.ndim == 3 and arr.shape[0] == 3 and arr.shape[-1] != 3:
        arr = np.transpose(arr, (1, 2, 0))

    if arr.ndim != 3:
        raise ValueError(f"MolmoAct2 image must be HxWx3, got ndim={arr.ndim} shape={getattr(arr, 'shape', '?')}")

    if arr.shape[-1] == 4:
        arr = arr[:, :, :3]
    elif arr.shape[-1] != 3:
        raise ValueError(f"MolmoAct2 image requires 3 RGB channels, got shape={arr.shape}")

    if np.issubdtype(arr.dtype, np.floating):
        peak = float(np.nanmax(arr)) if arr.size else 0.0
        if peak <= 1.0:
            arr = arr * 255.0
        rgb = np.clip(arr, 0, 255).astype(np.uint8)
    else:
        rgb = np.clip(arr, 0, 255).astype(np.uint8)

    rgb = np.ascontiguousarray(rgb, dtype=np.uint8)

    if expected_shape is not None and rgb.shape != expected_shape:
        raise ValueError(
            f"MolmoAct2 image shape {rgb.shape} != expected {expected_shape} "
            f"(height={expected_shape[0]}, width={expected_shape[1]}, RGB)"
        )
    return rgb


def ensure_uint8_rgb(image: np.ndarray) -> np.ndarray:
    """Convert a camera frame to HxWx3 uint8 RGB (any resolution, for web preview)."""
    return prepare_molmoact2_image(image, expected_shape=None)


# Virtual wrist-camera framing before MolmoAct2 resize (crop pan + zoom on source RGB).
DEFAULT_WRIST_PAN_X = 0.0
DEFAULT_WRIST_PAN_Y = 0.0
DEFAULT_WRIST_ZOOM = 1.0
WRIST_ZOOM_MIN = 1.0
WRIST_ZOOM_MAX = 3.0


@dataclass
class WristPerceptionConfig:
    """Crop/zoom tuning applied to wrist RGB before policy input and web preview."""

    pan_x: float = DEFAULT_WRIST_PAN_X
    pan_y: float = DEFAULT_WRIST_PAN_Y
    zoom: float = DEFAULT_WRIST_ZOOM


def parse_wrist_perception_config(
    *,
    pan_x: float | None = None,
    pan_y: float | None = None,
    zoom: float | None = None,
) -> WristPerceptionConfig:
    zx = DEFAULT_WRIST_PAN_X if pan_x is None else float(pan_x)
    zy = DEFAULT_WRIST_PAN_Y if pan_y is None else float(pan_y)
    zz = DEFAULT_WRIST_ZOOM if zoom is None else float(zoom)
    return WristPerceptionConfig(
        pan_x=max(-1.0, min(1.0, zx)),
        pan_y=max(-1.0, min(1.0, zy)),
        zoom=max(WRIST_ZOOM_MIN, min(WRIST_ZOOM_MAX, zz)),
    )


def apply_wrist_perception_tune(
    rgb: np.ndarray,
    config: WristPerceptionConfig,
    *,
    output_shape: tuple[int, int, int] = MOLMOACT2_POLICY_SHAPE,
) -> np.ndarray:
    """Crop (pan + zoom) wrist source RGB, then resize to MolmoAct2 policy shape.

    ``pan_x`` / ``pan_y`` are normalized in [-1, 1] (shift the crop window).
    ``zoom`` > 1 narrows the field of view (magnify center region).
    """
    src = ensure_uint8_rgb(rgb)
    h, w = src.shape[:2]
    out_h, out_w = output_shape[0], output_shape[1]
    zoom = max(WRIST_ZOOM_MIN, min(WRIST_ZOOM_MAX, float(config.zoom)))
    pan_x = max(-1.0, min(1.0, float(config.pan_x)))
    pan_y = max(-1.0, min(1.0, float(config.pan_y)))

    crop_w = max(1, min(w, int(round(w / zoom))))
    crop_h = max(1, min(h, int(round(h / zoom))))
    max_dx = max(0, (w - crop_w) // 2)
    max_dy = max(0, (h - crop_h) // 2)
    cx = w // 2 + int(round(pan_x * max_dx))
    cy = h // 2 + int(round(pan_y * max_dy))
    x0 = max(0, min(cx - crop_w // 2, w - crop_w))
    y0 = max(0, min(cy - crop_h // 2, h - crop_h))
    cropped = src[y0 : y0 + crop_h, x0 : x0 + crop_w]

    try:
        import cv2

        resized = cv2.resize(cropped, (out_w, out_h), interpolation=cv2.INTER_AREA)
    except ImportError:
        from PIL import Image

        resized = np.asarray(
            Image.fromarray(cropped).resize((out_w, out_h), Image.Resampling.LANCZOS),
            dtype=np.uint8,
        )

    return prepare_molmoact2_image(resized, expected_shape=output_shape)


def resolve_wrist_policy_rgb(
    *,
    wrist_source: np.ndarray | None,
    wrist_cache: np.ndarray | None,
    tune_fn: WristTuneFn,
) -> np.ndarray | None:
    """Return wrist RGB for policy / preview (tuned when a source frame is available)."""
    if wrist_source is not None and tune_fn is not None:
        return tune_fn(wrist_source)
    if wrist_cache is not None:
        return wrist_cache.copy()
    return None


@dataclass(frozen=True)
class CameraSpec:
    camera_id: str
    label: str
    prim_path: str


def policy_camera_ids(external_slot: str, external_camera_mode: str) -> tuple[str, ...]:
    """Camera slots required for a MolmoAct2 policy observation."""
    if external_camera_mode == "dual":
        return ("external_1", "external_2", "wrist")
    return (external_slot, "wrist")


def pack_policy_images(
    frames: dict[str, np.ndarray],
    external_slot: str,
    external_camera_mode: str,
) -> tuple[np.ndarray | None, np.ndarray | None, np.ndarray | None]:
    """Map a same-batch camera dict to MolmoAct2 (ext, ext2, wrist) tensors."""
    wrist = frames.get("wrist")
    if external_camera_mode == "dual":
        return frames.get("external_1"), frames.get("external_2"), wrist
    primary = frames.get(external_slot)
    if external_camera_mode == "duplicate" and primary is not None:
        return primary, primary.copy(), wrist
    return primary, None, wrist


def _encode_jpeg(rgb: np.ndarray, quality: int = PREVIEW_JPEG_QUALITY) -> bytes:
    rgb_u8 = np.ascontiguousarray(rgb[:, :, :3], dtype=np.uint8)
    try:
        import cv2

        bgr = cv2.cvtColor(rgb_u8, cv2.COLOR_RGB2BGR)
        ok, buf = cv2.imencode(".jpg", bgr, [int(cv2.IMWRITE_JPEG_QUALITY), int(quality)])
        if ok:
            return buf.tobytes()
    except ImportError:
        pass

    from PIL import Image

    bio = io.BytesIO()
    Image.fromarray(rgb_u8).save(bio, format="JPEG", quality=quality)
    return bio.getvalue()
