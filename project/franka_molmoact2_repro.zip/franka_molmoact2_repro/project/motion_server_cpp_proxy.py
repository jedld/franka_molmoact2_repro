# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Proxy ``motion_server.cpp`` over HTTP for :class:`MotionRestServer` / MolmoAct2."""

from __future__ import annotations

import json
import socket
import threading
import time
import urllib.error
import urllib.request
from typing import Any

import numpy as np

from motion_server_timing_log import log_event, log_slow

from motion_server_action_offset import (
    DEFAULT_EE_FLOOR_ENABLED,
    DEFAULT_EE_FLOOR_Z_M,
    DEFAULT_GRIPPER_TIP_OFFSET_M,
    clip_joints_to_ee_floor,
)
from motion_server_policy_gripper import (
    PolicyGripperTracker,
    apply_policy_joint_targets_coordinated,
)


# Control loop rate (Hz) — matches MolmoAct2Controller.CONTROL_HZ.
CONTROL_HZ = 15.0
# The C++ libfranka velocity servo saturates at ~0.5 rad/s (motion_server.cpp ``max_vel``). Cap the
# per-tick ramp so the commanded target advances no faster than the servo can physically follow;
# otherwise the command races ahead of the measured joints and snaps back when a stall clears.
SERVO_MAX_VEL_RAD_S = 0.5
# Per-tick ramp of the commanded joint target toward the model goal (rad / 15 Hz tick) ≈ 0.033.
_MAX_JOINT_STEP_RAD = SERVO_MAX_VEL_RAD_S / CONTROL_HZ
# Anti-windup bound: the ramped command target may lead the *actual* measured joints by at
# most this much. The C++ velocity servo saturates at ~0.5 rad/s, so a sustained fast move
# would otherwise let the command race arbitrarily far ahead of reality and snap back when a
# stall (contact, gripper grasp, floor clip) clears. 0.6 rad > the servo's steady-state
# tracking lag, so normal moves run at full speed while pathological windup is bounded.
_MAX_TARGET_LEAD_RAD = 0.6


def is_collision_recovery_error(message: str) -> bool:
    """True for recoverable Franka reflex/contact errors from motion_server.cpp."""
    return "collision_recovery:" in message and "collision_recovery_failed:" not in message


class CppMotionServerHandler:
    """Drive a real Franka via ``motion_server.cpp`` using the Isaac handler interface."""

    def __init__(self, base_url: str = "http://127.0.0.1:34569", timeout_s: float = 60.0) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout_s = timeout_s
        self._io_lock = threading.Lock()
        self._policy_timeout_s = 5.0
        self._last_gripper_width = 0.04
        self._last_q9: np.ndarray | None = None
        self._ee_floor_enabled = DEFAULT_EE_FLOOR_ENABLED
        self._ee_floor_z = DEFAULT_EE_FLOOR_Z_M
        self._gripper_tip_offset_m = DEFAULT_GRIPPER_TIP_OFFSET_M
        self._ee_floor_clips = 0
        self._fk_clearance_available: bool | None = None
        self._policy_gripper = PolicyGripperTracker()

    def _post(
        self,
        payload: dict[str, list[float]],
        *,
        timeout_s: float | None = None,
        serialize: bool = True,
    ) -> dict:
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self._base_url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        deadline = timeout_s if timeout_s is not None else self._timeout_s
        keys = "+".join(sorted(payload.keys()))
        t0 = time.perf_counter()
        lock_wait_s = 0.0
        if serialize:
            if not self._io_lock.acquire(timeout=max(0.0, deadline)):
                waited = time.perf_counter() - t0
                raise TimeoutError(
                    f"timed out waiting for motion_server I/O lock after {waited:.3f}s ({keys})"
                )
            lock_wait_s = time.perf_counter() - t0
        try:
            http_t0 = time.perf_counter()
            try:
                with urllib.request.urlopen(req, timeout=deadline) as resp:
                    result = json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                detail = exc.read().decode("utf-8", errors="replace").strip().strip('"')
                if is_collision_recovery_error(detail):
                    raise RuntimeError(detail) from exc
                raise RuntimeError(f"motion_server HTTP {exc.code}: {detail}") from exc
            except urllib.error.URLError as exc:
                if isinstance(exc.reason, socket.timeout):
                    raise TimeoutError("timed out") from exc
                raise RuntimeError(f"motion_server URL error: {exc.reason}") from exc
            http_s = time.perf_counter() - http_t0
        finally:
            if serialize:
                self._io_lock.release()
        total_s = time.perf_counter() - t0
        log_slow(
            "cpp_proxy",
            keys,
            total_s,
            lock_wait=f"{lock_wait_s:.3f}s",
            http=f"{http_s:.3f}s",
            timeout=f"{deadline:.1f}s",
        )
        return result

    def set_ee_floor_config(
        self,
        enabled: bool,
        floor_z: float,
        gripper_tip_offset_m: float,
    ) -> None:
        self._ee_floor_enabled = bool(enabled)
        self._ee_floor_z = float(floor_z)
        self._gripper_tip_offset_m = max(0.0, float(gripper_tip_offset_m))

    def consume_ee_floor_clips(self) -> int:
        count = self._ee_floor_clips
        self._ee_floor_clips = 0
        return count

    def tip_clearance_z(self, q7: np.ndarray) -> float:
        """Fingertip height (m) via libfranka FK when available, else Python FK."""
        q = np.asarray(q7, dtype=np.float64).reshape(7)
        # During MolmoAct2 policy streaming, avoid extra round-trips to motion_server.cpp
        # (the main loop must stay responsive for process_pending / Ctrl+C).
        if self._last_q9 is not None:
            from motion_server_action_offset import effective_ee_tip_z

            return effective_ee_tip_z(q, gripper_tip_offset_m=self._gripper_tip_offset_m)
        payload = list(q.tolist()) + [self._gripper_tip_offset_m]
        if self._fk_clearance_available is not False:
            try:
                result = self._post({"fkClearance": payload})
                tip_z = result.get("fkClearance")
                if isinstance(tip_z, list) and len(tip_z) >= 2:
                    self._fk_clearance_available = True
                    return float(tip_z[1])
            except RuntimeError:
                self._fk_clearance_available = False
        from motion_server_action_offset import effective_ee_tip_z

        return effective_ee_tip_z(q, gripper_tip_offset_m=self._gripper_tip_offset_m)

    def initialize(self, skip_home: bool = False) -> None:
        """No-op — ``motion_server.cpp`` homes on its own startup."""

    def move_to_cartesian(self, numbers: list[float]) -> list[float]:
        payload = self._post({"moveToCartesian": numbers})
        result = payload.get("moveToCartesian")
        if not isinstance(result, list):
            raise RuntimeError(f"moveToCartesian failed: {payload}")
        return [float(x) for x in result]

    def move_to_joint_pose(self, numbers: list[float]) -> list[float]:
        payload = self._post({"moveToJointPose": numbers})
        result = payload.get("moveToJointPose")
        if not isinstance(result, list):
            raise RuntimeError(f"moveToJointPose failed: {payload}")
        return [float(x) for x in result]

    def close_gripper(self, numbers: list[float]) -> str:
        log_event("cpp_proxy", "closeGripper API call")
        payload = self._post({"closeGripper": numbers})
        return str(payload.get("closeGripper", ""))

    def open_gripper(self, numbers: list[float]) -> str:
        log_event("cpp_proxy", "openGripper API call")
        payload = self._post({"openGripper": numbers})
        return str(payload.get("openGripper", ""))

    def publish_binary_gripper(self, closed: bool) -> None:
        width = 0.0 if closed else 0.08
        log_event(
            "cpp_proxy",
            f"publish_binary_gripper edge => {'close' if closed else 'open'} width={width:.3f}",
        )
        if self._last_q9 is None:
            self._last_q9 = self.get_joint_positions_q9()
        cmd = self._last_q9[:7].tolist() + [width]
        self.set_joint_pose(cmd)

    def sync_policy_gripper(self, closed: bool) -> None:
        self.publish_binary_gripper(closed)

    def read_state(self) -> list[float]:
        payload = self._post({"readState": []}, serialize=False)
        result = payload.get("readState")
        if not isinstance(result, list):
            raise RuntimeError(f"readState failed: {payload}")
        return [float(x) for x in result]

    def read_joint_state(self) -> list[float]:
        payload = self._post({"readJointState": []}, serialize=False)
        result = payload.get("readJointState")
        if not isinstance(result, list):
            raise RuntimeError(f"readJointState failed: {payload}")
        return [float(x) for x in result]

    def read_gripper_state(self) -> list[float]:
        payload = self._post(
            {"readGripperState": []}, timeout_s=self._policy_timeout_s, serialize=False
        )
        result = payload.get("readGripperState")
        if not isinstance(result, list) or not result:
            raise RuntimeError(f"readGripperState failed: {payload}")
        width = float(result[0])
        self._last_gripper_width = width
        return [width]

    def set_joint_pose(self, numbers: list[float]) -> list[float]:
        payload = self._post({"setJointPose": numbers}, timeout_s=self._policy_timeout_s)
        result = payload.get("setJointPose")
        if not isinstance(result, list):
            raise RuntimeError(f"setJointPose failed: {payload}")
        return [float(x) for x in result]

    def get_joint_positions_q9(self) -> np.ndarray:
        payload = self._post(
            {"readJointState": [], "readGripperState": []},
            timeout_s=self._policy_timeout_s,
        )
        q7 = payload.get("readJointState")
        if not q7 or len(q7) < 7:
            raise RuntimeError(f"readJointState failed: {payload}")
        grip = payload.get("readGripperState")
        if grip and len(grip) >= 1:
            width = float(grip[0])
            self._last_gripper_width = width
        else:
            width = self._last_gripper_width
        half = width / 2.0
        return np.array(list(q7[:7]) + [half, half], dtype=np.float64)

    def apply_policy_joint_targets(
        self, q9: np.ndarray, current_q9: np.ndarray | None = None
    ) -> bool:
        q = np.asarray(q9, dtype=np.float64).reshape(9)
        if self._last_q9 is None:
            self._last_q9 = self.get_joint_positions_q9()
        current = self._last_q9
        cmd_q = current[:7].copy()
        delta = q[:7] - current[:7]
        delta = np.clip(delta, -_MAX_JOINT_STEP_RAD, _MAX_JOINT_STEP_RAD)
        cmd_q = cmd_q + delta

        # Anti-windup: never let the ramped command target lead the actual measured joints by
        # more than _MAX_TARGET_LEAD_RAD. The caller passes the freshly-read robot state so this
        # costs no extra round-trip; without it a stalled axis lets the target race ahead.
        if current_q9 is not None:
            actual_q7 = np.asarray(current_q9, dtype=np.float64).reshape(9)[:7]
            cmd_q = np.clip(
                cmd_q, actual_q7 - _MAX_TARGET_LEAD_RAD, actual_q7 + _MAX_TARGET_LEAD_RAD
            )

        if self._ee_floor_enabled:
            cmd_q, clipped = clip_joints_to_ee_floor(
                cmd_q,
                self._ee_floor_z,
                q_reference=current[:7],
                gripper_tip_offset_m=self._gripper_tip_offset_m,
                clearance_fn=self.tip_clearance_z,
            )
            if clipped:
                self._ee_floor_clips += 1

        arm_q9 = np.concatenate([cmd_q, q[7:]])
        applied = apply_policy_joint_targets_coordinated(self, arm_q9, self._policy_gripper)
        if applied:
            half = self._last_gripper_width / 2.0
            self._last_q9 = np.array(list(cmd_q) + [half, half], dtype=np.float64)
        return applied

    def stop_policy_stream(self) -> None:
        log_event("cpp_proxy", "stopPolicyStream")
        self._post({"stopPolicyStream": []})
        self._last_q9 = None
        self._policy_gripper = PolicyGripperTracker()

    def get_policy_stream_status(self) -> dict[str, Any]:
        payload = self._post(
            {"getPolicyStreamStatus": []}, timeout_s=self._policy_timeout_s, serialize=False
        )
        raw = payload.get("getPolicyStreamStatus")
        if not isinstance(raw, str):
            raise RuntimeError(f"getPolicyStreamStatus failed: {payload}")
        return json.loads(raw)

    def clear_policy_fault(self) -> None:
        log_event("cpp_proxy", "clearPolicyFault")
        self._post({"clearPolicyFault": []}, timeout_s=self._policy_timeout_s)

    def recover_policy_stream(self) -> None:
        log_event("cpp_proxy", "recoverPolicyStream")
        payload = self._post({"recoverPolicyStream": []}, timeout_s=self._timeout_s)
        result = payload.get("recoverPolicyStream")
        if result != "ok":
            raise RuntimeError(f"recoverPolicyStream failed: {payload}")
        self._last_q9 = None
        self._policy_gripper = PolicyGripperTracker()
