#!/usr/bin/env python3
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""One-shot EE-floor calibration helper for the real Franka (Fix 6).

The MolmoAct2 floor guard (``ee_floor_z``) blocks fingertip descent below a base-frame Z. Shipping
default is a guess (0.05 m); on hardware an uncalibrated value hovers the arm above the object and
blocks picks. This tool reads the *current* arm pose from ``motion_server.cpp`` and prints the
recommended ``ee_floor_z``.

Procedure:
  1. Hand-guide / jog the arm until the lowest fingertip just touches the table surface.
  2. Run this script (optionally with ``--watch`` to stream live values while jogging).
  3. Use the printed ``ee_floor_z`` value in the runner (``--ee-floor-z``) or the configure API.

Fingertip height is taken from the motion server's libfranka FK (``fkClearance``) when available,
falling back to the libfranka-matched Python FK in ``motion_server_action_offset`` — no new
kinematics are implemented here (see AGENTS.md).

Example:
  python3 calibrate_ee_floor.py --motion-url http://127.0.0.1:34568
  python3 calibrate_ee_floor.py --watch
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

_PROJECT_DIR = Path(__file__).resolve().parent
if str(_PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(_PROJECT_DIR))

import numpy as np

from motion_server_action_offset import (
    DEFAULT_GRIPPER_TIP_OFFSET_M,
    effective_ee_tip_z,
)
from motion_server_http_robot import MotionServerHttpRobot


def _read_tip_z(robot: MotionServerHttpRobot, gripper_tip_offset_m: float) -> tuple[float, np.ndarray]:
    """Return (fingertip base-frame Z in m, q7) using libfranka FK via the motion server."""
    q9 = robot.get_joint_positions_q9()
    q7 = np.asarray(q9, dtype=np.float64).reshape(9)[:7]
    # tip_clearance_z prefers the motion server fkClearance (libfranka) and falls back to the
    # libfranka-matched Python FK; override the tip offset via the local FK path for consistency.
    try:
        tip_z = float(robot.tip_clearance_z(q7))
    except Exception:
        tip_z = effective_ee_tip_z(q7, gripper_tip_offset_m=gripper_tip_offset_m)
    return tip_z, q7


def main() -> int:
    parser = argparse.ArgumentParser(description="Calibrate the MolmoAct2 EE floor (ee_floor_z)")
    parser.add_argument(
        "--motion-url", default="http://127.0.0.1:34568", help="motion_server.cpp base URL"
    )
    parser.add_argument(
        "--clearance",
        type=float,
        default=0.002,
        help="Safety clearance (m) subtracted from the touched tip Z (default: 0.002 = 2 mm)",
    )
    parser.add_argument(
        "--gripper-tip-offset-m",
        type=float,
        default=DEFAULT_GRIPPER_TIP_OFFSET_M,
        help=(
            "Flange→fingertip distance (m) along +EE Z for the Python FK fallback "
            f"(default: {DEFAULT_GRIPPER_TIP_OFFSET_M:.4f}, stock Franka Hand)"
        ),
    )
    parser.add_argument(
        "--watch",
        action="store_true",
        help="Continuously print the live fingertip Z (Ctrl+C to stop) while jogging the arm.",
    )
    parser.add_argument(
        "--hz", type=float, default=5.0, help="Watch-mode poll rate (default: 5 Hz)"
    )
    args = parser.parse_args()

    robot = MotionServerHttpRobot(args.motion_url)

    if args.watch:
        print("Watching live fingertip Z — jog the arm until it touches the table, then Ctrl+C.")
        period = 1.0 / max(args.hz, 0.5)
        try:
            while True:
                try:
                    tip_z, _q7 = _read_tip_z(robot, args.gripper_tip_offset_m)
                except Exception as exc:
                    print(f"  read failed: {exc}")
                    time.sleep(period)
                    continue
                recommended = tip_z - args.clearance
                print(
                    f"  tip_z = {tip_z:+.4f} m   recommended ee_floor_z = {recommended:+.4f} m",
                    flush=True,
                )
                time.sleep(period)
        except KeyboardInterrupt:
            print()

    try:
        tip_z, q7 = _read_tip_z(robot, args.gripper_tip_offset_m)
    except Exception as exc:
        print(f"Error: failed to read robot state from {args.motion_url}: {exc}")
        return 1

    recommended = tip_z - args.clearance
    print("EE floor calibration")
    print("--------------------")
    print(f"  q7 (rad):           {np.array2string(q7, precision=4, floatmode='fixed')}")
    print(f"  fingertip Z (m):    {tip_z:+.4f}")
    print(f"  clearance (m):      {args.clearance:.4f}")
    print(f"  recommended ee_floor_z (m): {recommended:+.4f}")
    print()
    print("Apply with the hardware runner:")
    print(f"  python3 hardware_molmoact2_runner.py --ee-floor-z {recommended:.4f} ...")
    print("or via the configure API:")
    print(
        '  curl -s -X POST http://127.0.0.1:34568/api/molmoact2/configure '
        "-H 'Content-Type: application/json' "
        f'-d \'{{"ee_floor_enabled": true, "ee_floor_z": {recommended:.4f}}}\''
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
