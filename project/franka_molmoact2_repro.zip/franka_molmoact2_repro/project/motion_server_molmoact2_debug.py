# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Disk + status logging for MolmoAct2 inference debug sessions."""

from __future__ import annotations

import json
import os
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np

ACTION_LABELS = ["q1", "q2", "q3", "q4", "q5", "q6", "q7", "gripper"]
JOINT_LABELS = ACTION_LABELS


def _default_debug_root() -> Path:
    return Path(os.environ.get("MOLMOACT2_DEBUG_DIR", "/tmp/franka_molmoact2/molmoact2_debug"))


def _save_rgb_png(path: Path, rgb: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    arr = np.ascontiguousarray(rgb[:, :, :3], dtype=np.uint8)
    try:
        import cv2

        cv2.imwrite(str(path), cv2.cvtColor(arr, cv2.COLOR_RGB2BGR))
        return
    except ImportError:
        pass
    from PIL import Image

    Image.fromarray(arr).save(path)


@dataclass
class MolmoAct2DebugEntry:
    chunk: int
    path: str
    endpoint: str
    timestamp: str
    fetch_elapsed_s: float | None = None
    dt_ms: float | None = None
    error: str = ""


@dataclass
class MolmoAct2DebugRecorder:
    """Write one folder per GPU fetch with images, state, and model response."""

    base_dir: Path = field(default_factory=_default_debug_root)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)
    _session_dir: Path | None = field(default=None, init=False, repr=False)
    _chunk_counter: int = field(default=0, init=False, repr=False)
    _recent: list[MolmoAct2DebugEntry] = field(default_factory=list, init=False, repr=False)

    @property
    def session_dir(self) -> str:
        return "" if self._session_dir is None else str(self._session_dir)

    @property
    def chunks_logged(self) -> int:
        return self._chunk_counter

    @property
    def last_chunk_dir(self) -> str:
        if not self._recent:
            return ""
        return self._recent[-1].path

    def recent_entries(self, limit: int = 12) -> list[dict[str, Any]]:
        with self._lock:
            return [vars(entry) for entry in self._recent[-limit:]]

    def start_session(
        self,
        *,
        instruction: str,
        server_url: str,
        external_camera_mode: str,
        external_slot: str,
    ) -> Path:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        session_dir = self.base_dir / f"session_{stamp}"
        session_dir.mkdir(parents=True, exist_ok=True)
        readme = session_dir / "README.txt"
        readme.write_text(
            "\n".join(
                [
                    "MolmoAct2 debug session",
                    "=======================",
                    "",
                    "Each chunk_NNNN/ folder is one GPU inference call:",
                    "  meta.json           — request metadata + joint state",
                    "  input_*.png         — RGB images sent to the model",
                    "  response.json       — parsed model output (actions, dt_ms)",
                    "  response_actions.csv — tabular view of the action chunk",
                    "",
                    f"instruction: {instruction}",
                    f"server_url: {server_url}",
                    f"camera_mode: {external_camera_mode}",
                    f"external_slot: {external_slot}",
                    "",
                ]
            ),
            encoding="utf-8",
        )
        with self._lock:
            self._session_dir = session_dir
            self._chunk_counter = 0
            self._recent.clear()
        return session_dir

    def clear_session(self) -> None:
        with self._lock:
            self._session_dir = None
            self._chunk_counter = 0

    def record_fetch(
        self,
        *,
        external_camera_mode: str,
        ext_rgb: np.ndarray,
        wrist_rgb: np.ndarray,
        state8: np.ndarray,
        instruction: str,
        server_url: str,
        endpoint: str,
        ext2_rgb: np.ndarray | None = None,
        actions: np.ndarray | None = None,
        dt_ms: float | None = None,
        fetch_elapsed_s: float | None = None,
        error: str = "",
    ) -> str:
        with self._lock:
            if self._session_dir is None:
                self.start_session(
                    instruction=instruction,
                    server_url=server_url,
                    external_camera_mode=external_camera_mode,
                    external_slot="external_1",
                )
            self._chunk_counter += 1
            chunk_id = self._chunk_counter
            chunk_dir = self._session_dir / f"chunk_{chunk_id:04d}"
            chunk_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().isoformat(timespec="milliseconds")
        state_arr = np.asarray(state8, dtype=np.float32).reshape(8)

        _save_rgb_png(chunk_dir / "input_external_cam.png", ext_rgb)
        _save_rgb_png(chunk_dir / "input_wrist_cam.png", wrist_rgb)
        if ext2_rgb is not None and external_camera_mode in ("dual", "duplicate"):
            _save_rgb_png(chunk_dir / "input_external_cam_2.png", ext2_rgb)

        state_lines = [
            f"timestamp: {timestamp}",
            f"instruction: {instruction}",
            f"server_url: {server_url}",
            f"endpoint: {endpoint}",
            f"camera_mode: {external_camera_mode}",
            "",
            "state8 (q1-q7 rad, gripper DROID 0=open 1=closed):",
        ]
        for label, value in zip(JOINT_LABELS, state_arr.tolist()):
            unit = " (droid)" if label == "gripper" else " rad"
            state_lines.append(f"  {label}: {value:.6f}{unit}")
        (chunk_dir / "input_state.txt").write_text("\n".join(state_lines) + "\n", encoding="utf-8")

        meta = {
            "chunk": chunk_id,
            "timestamp": timestamp,
            "instruction": instruction,
            "server_url": server_url,
            "endpoint": endpoint,
            "external_camera_mode": external_camera_mode,
            "state8": state_arr.tolist(),
            "state_labels": JOINT_LABELS,
            "image_files": {
                "external_cam": "input_external_cam.png",
                "wrist_cam": "input_wrist_cam.png",
            },
            "fetch_elapsed_s": fetch_elapsed_s,
            "dt_ms": dt_ms,
            "error": error or None,
        }
        if ext2_rgb is not None and external_camera_mode in ("dual", "duplicate"):
            meta["image_files"]["external_cam_2"] = "input_external_cam_2.png"
        (chunk_dir / "meta.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")

        response_payload: dict[str, Any] = {
            "endpoint": endpoint,
            "dt_ms": dt_ms,
            "fetch_elapsed_s": fetch_elapsed_s,
            "error": error or None,
        }
        if actions is not None:
            actions_arr = np.asarray(actions, dtype=np.float32)
            if actions_arr.ndim == 1:
                actions_arr = actions_arr[None, :]
            response_payload["actions_shape"] = list(actions_arr.shape)
            response_payload["action_labels"] = ACTION_LABELS
            response_payload["actions"] = actions_arr.tolist()
            csv_lines = [",".join(["step"] + ACTION_LABELS)]
            for step_idx, row in enumerate(actions_arr):
                csv_lines.append(",".join([str(step_idx)] + [f"{float(v):.6f}" for v in row]))
            (chunk_dir / "response_actions.csv").write_text("\n".join(csv_lines) + "\n", encoding="utf-8")
        (chunk_dir / "response.json").write_text(json.dumps(response_payload, indent=2) + "\n", encoding="utf-8")

        entry = MolmoAct2DebugEntry(
            chunk=chunk_id,
            path=str(chunk_dir),
            endpoint=endpoint,
            timestamp=timestamp,
            fetch_elapsed_s=fetch_elapsed_s,
            dt_ms=dt_ms,
            error=error,
        )
        with self._lock:
            self._recent.append(entry)
            if len(self._recent) > 50:
                self._recent = self._recent[-50:]

        tag = "ERROR" if error else "ok"
        elapsed_note = f" ({fetch_elapsed_s:.2f}s)" if fetch_elapsed_s is not None else ""
        print(f"[molmoact2 debug] chunk {chunk_id:04d} {tag} → {chunk_dir}{elapsed_note}")
        return str(chunk_dir)
